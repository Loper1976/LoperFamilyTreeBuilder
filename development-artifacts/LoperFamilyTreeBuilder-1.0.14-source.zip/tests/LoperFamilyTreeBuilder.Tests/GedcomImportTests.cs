using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.ImportExport.Gedcom;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class GedcomImportTests
{
    [Fact]
    public void Parser_ReadsIndividualsFamiliesAndExactDates()
    {
        const string gedcom = """
0 HEAD
1 GEDC
2 VERS 5.5.1
0 @I1@ INDI
1 NAME Robert /Loper/
1 GIVN Robert
1 SURN Loper
1 BIRT
2 DATE 30 JUL 1927
1 FAMS @F1@
0 @I2@ INDI
1 NAME Jane /Example/
1 FAMS @F1@
0 @I3@ INDI
1 NAME Child /Loper/
1 FAMC @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
1 CHIL @I3@
0 TRLR
""";

        var doc = new GedcomParser().Parse(gedcom);

        Assert.Empty(doc.Errors);
        Assert.Equal(3, doc.Individuals.Count);
        Assert.Single(doc.Families);
        Assert.Equal(new DateOnly(1927, 7, 30), doc.Individuals[0].BirthDate);
        Assert.Equal("Loper", doc.Individuals[0].Surname);
    }

    [Fact]
    public void Parser_FlagsCustomTagsButDoesNotDiscardFile()
    {
        const string gedcom = """
0 HEAD
0 @I1@ INDI
1 NAME Test /Person/
1 _CUSTOM Value
0 TRLR
""";

        var doc = new GedcomParser().Parse(gedcom);

        Assert.Empty(doc.Errors);
        Assert.Single(doc.UnsupportedTags);
        Assert.Equal("_CUSTOM", doc.UnsupportedTags[0].Tag);
    }

    [Fact]
    public void ImportSession_RequiresApprovalBeforeApply()
    {
        var session = new GedcomImportSession("test.ged", "Imports/test.ged", new string('a', 64), 1, 0, 0, "{}");
        Assert.Throws<InvalidOperationException>(() => session.MarkApplied("backup.bak"));
        session.Approve();
        session.MarkApplied("backup.bak");
        Assert.Equal(GedcomImportStatus.Applied, session.Status);
    }
}
