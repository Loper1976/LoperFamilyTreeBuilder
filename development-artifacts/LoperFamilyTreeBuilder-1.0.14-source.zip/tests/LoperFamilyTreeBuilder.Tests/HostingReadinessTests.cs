using LoperFamilyTreeBuilder.Core.Models;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class HostingReadinessTests
{
    [Fact]
    public void HostingReport_RequiresHostedModeAndRequiredChecks()
    {
        var checks = new[]
        {
            new HostingReadinessCheck("HTTPS", true, "ok", true),
            new HostingReadinessCheck("Monitoring", false, "optional", false)
        };

        var report = new HostingReadinessReport(true, checks.Where(x => x.Required).All(x => x.Passed), "https://loper.family", checks);

        Assert.True(report.IsReady);
        Assert.False(report.Checks.Single(x => x.Name == "Monitoring").Required);
    }
}
