using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class ResearchManagementTests
{
    [Fact]
    public void ResearchTask_DefaultsToNeedsResearch()
    {
        var task = new ResearchTaskRecord("Find the original birth certificate.");

        Assert.Equal(ResearchStatus.NeedsResearch, task.Status);
        Assert.Equal("Find the original birth certificate.", task.ResearchQuestion);
    }

    [Fact]
    public void AiSuggestion_RemainsPendingUntilHumanReview()
    {
        var suggestion = new AiResearchSuggestion(
            AiSuggestionType.SourceGap,
            "Review source coverage.",
            "No citation is linked.",
            "Existing archive");

        Assert.Equal(AiSuggestionStatus.PendingReview, suggestion.Status);

        suggestion.Review(AiSuggestionStatus.Approved, Guid.NewGuid(), "Approved as a research lead only.");

        Assert.Equal(AiSuggestionStatus.Approved, suggestion.Status);
        Assert.NotNull(suggestion.ReviewedUtc);
    }
}
