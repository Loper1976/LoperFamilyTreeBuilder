using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class CollaborationSecurityTests
{
    [Fact]
    public void FamilySubmission_starts_pending_and_requires_review()
    {
        var userId=Guid.NewGuid();var submission=new FamilySubmission(userId,FamilySubmissionType.Correction,"Correct birth place","Family source says Tomball.");
        Assert.Equal(FamilySubmissionStatus.Pending,submission.Status);
        submission.Review(FamilySubmissionStatus.NeedsClarification,Guid.NewGuid(),"Please provide the source image.");
        Assert.Equal(FamilySubmissionStatus.NeedsClarification,submission.Status);
    }

    [Fact]
    public void Protected_legacy_number_policy_remains_unchanged()
    {
        var person=new Person("Test","Person");person.AddLegacyNumber("21314.00");
        Assert.Throws<InvalidOperationException>(()=>person.AddLegacyNumber("999.00"));
    }
}
