using LoperFamilyTreeBuilder.Core.Models;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class BackupManifestTests
{
    [Fact]
    public void BackupManifest_CanRepresentVerifiedArchiveContents()
    {
        var manifest = new BackupManifest
        {
            ApplicationVersion = "1.0.10",
            Reason = BackupReason.BeforeSoftwareUpdate,
            CreatedUtc = DateTimeOffset.UtcNow,
            DatabaseBackupFile = "LoperFamilyTreeBuilder.bak",
            IncludesArchiveFiles = true
        };
        manifest.Entries.Add(new BackupManifestEntry("LoperFamilyTreeBuilder.bak", "Database", 100, new string('a', 64)));

        Assert.True(manifest.IncludesArchiveFiles);
        Assert.Single(manifest.Entries);
        Assert.Equal(BackupReason.BeforeSoftwareUpdate, manifest.Reason);
    }
}
