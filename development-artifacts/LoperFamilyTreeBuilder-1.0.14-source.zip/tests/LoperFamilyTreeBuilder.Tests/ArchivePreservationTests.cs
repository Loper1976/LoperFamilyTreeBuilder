using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class ArchivePreservationTests
{
    [Fact]
    public void ArchiveMediaFile_PreservesOriginalFilenameAndChecksum()
    {
        var media = new ArchiveMediaFile(
            ArchiveMediaType.Photo,
            "IMG_1234.HEIC",
            "Media/Originals/Photos/2026/08/abc/IMG_1234.HEIC",
            "image/heic",
            12345,
            new string('a', 64));

        Assert.Equal("IMG_1234.HEIC", media.OriginalFileName);
        Assert.True(media.IsOriginal);
        Assert.Equal(new string('a', 64), media.Sha256);
    }

    [Fact]
    public void DocumentTranscription_IsSeparateFromOriginalMedia()
    {
        var mediaId = Guid.NewGuid();
        var tx = new DocumentTranscription(mediaId, "Transcribed text", TranscriptionOrigin.Human, "Tester");
        Assert.Equal(mediaId, tx.MediaFileId);
        Assert.Equal("Transcribed text", tx.Text);
        Assert.True(tx.IsApproved);
    }

    [Fact]
    public void Citation_CanPreserveContradictingEvidence()
    {
        var citation = new CitationRecord(Guid.NewGuid(), Guid.NewGuid(), "Birth date", CitationPosition.Contradicting);
        Assert.Equal(CitationPosition.Contradicting, citation.Position);
    }
}
