using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class CoupleRelationshipTests
{
    [Fact]
    public void CoupleRelationship_NormalizesPersonOrder()
    {
        var first = Guid.Parse("11111111-1111-1111-1111-111111111111");
        var second = Guid.Parse("22222222-2222-2222-2222-222222222222");

        var relationship = new CoupleRelationship(
            second,
            first,
            CoupleRelationshipType.Spouse);

        Assert.Equal(first, relationship.PersonAId);
        Assert.Equal(second, relationship.PersonBId);
    }

    [Fact]
    public void CoupleRelationship_RejectsSelfRelationship()
    {
        var personId = Guid.NewGuid();

        Assert.Throws<InvalidOperationException>(() =>
            new CoupleRelationship(
                personId,
                personId,
                CoupleRelationshipType.Spouse));
    }
}
