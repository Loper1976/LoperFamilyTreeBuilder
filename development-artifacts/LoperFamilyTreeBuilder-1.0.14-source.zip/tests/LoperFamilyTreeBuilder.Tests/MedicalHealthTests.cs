using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Tests;

public sealed class MedicalHealthTests
{
    [Fact]
    public void NewCondition_DefaultsToPrivateAndUnknownEvidence()
    {
        var record = new MedicalConditionRecord(Guid.NewGuid(), "Hypertension");

        Assert.Equal(MedicalPrivacyLevel.Private, record.PrivacyLevel);
        Assert.Equal(MedicalEvidenceStatus.Unknown, record.EvidenceStatus);
        Assert.False(record.PotentialHereditaryRelevance);
    }

    [Fact]
    public void HereditaryRelevance_RequiresExplicitFlag()
    {
        var record = new MedicalConditionRecord(Guid.NewGuid(), "Migraine");

        record.Update(null, 2020, null, MedicalConditionStatus.Historical,
            MedicalEvidenceStatus.FamilyReported, "Unknown", false,
            string.Empty, string.Empty, string.Empty, MedicalPrivacyLevel.Private);

        Assert.False(record.PotentialHereditaryRelevance);

        record.Update(null, 2020, null, MedicalConditionStatus.Historical,
            MedicalEvidenceStatus.FamilyReported, "Unknown", true,
            string.Empty, string.Empty, string.Empty, MedicalPrivacyLevel.Private);

        Assert.True(record.PotentialHereditaryRelevance);
    }

    [Fact]
    public void EvidenceStatuses_RemainDistinct()
    {
        Assert.NotEqual(MedicalEvidenceStatus.Confirmed, MedicalEvidenceStatus.Probable);
        Assert.NotEqual(MedicalEvidenceStatus.Probable, MedicalEvidenceStatus.Suspected);
        Assert.NotEqual(MedicalEvidenceStatus.Suspected, MedicalEvidenceStatus.FamilyReported);
        Assert.NotEqual(MedicalEvidenceStatus.FamilyReported, MedicalEvidenceStatus.Unknown);
    }

    [Fact]
    public void CauseOfDeath_DefaultsToPrivate()
    {
        var record = new CauseOfDeathRecord(Guid.NewGuid(), "Recorded cause");

        Assert.Equal(MedicalPrivacyLevel.Private, record.PrivacyLevel);
        Assert.Equal(MedicalEvidenceStatus.Unknown, record.EvidenceStatus);
    }
}
