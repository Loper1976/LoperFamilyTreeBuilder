# Loper Family Tree Builder - Hosted Deployment Readiness

Version 1.0.11 keeps the local Windows installation working while adding a production configuration contract.

The final hosting provider, production database service, storage provider, Cloudflare deployment, email provider, and monitoring provider remain explicit owner decisions.

Required production principles:

- Use HTTPS.
- Use a production SQL connection string, not LocalDB.
- Keep archive storage and backup storage independent.
- Preserve Robert J. Loper Legacy Numbers exactly.
- Enforce living-person, medical, DNA, document, and branch permissions server-side.
- Keep AI proposal-first.
- Maintain verified backups and restore testing.
- Do not make a third-party genealogy service the only authoritative copy.
