using System.Security.Cryptography;
using LoperFamilyTreeBuilder.Infrastructure.Configuration;

namespace LoperFamilyTreeBuilder.Infrastructure.Storage;

public sealed class ArchiveMediaStorageService(ArchiveConfigurationStore configurationStore)
{
    public async Task<StoredArchiveFile> StoreOriginalAsync(
        Stream input,
        string originalFileName,
        string mediaFolder,
        CancellationToken cancellationToken = default)
    {
        var configuration = await configurationStore.LoadAsync(cancellationToken)
            ?? throw new InvalidOperationException("Archive storage has not been configured.");

        if (!configuration.IsComplete)
            throw new InvalidOperationException("Archive storage configuration is incomplete.");

        var safeName = SanitizeFileName(originalFileName);
        var id = Guid.NewGuid();
        var dateFolder = DateTime.UtcNow.ToString("yyyy\\MM");
        var relativeDirectory = Path.Combine("Media", "Originals", mediaFolder, dateFolder, id.ToString("N"));
        var fullDirectory = Path.Combine(configuration.PrimaryArchivePath, relativeDirectory);
        Directory.CreateDirectory(fullDirectory);

        var fullPath = Path.Combine(fullDirectory, safeName);
        await using var output = new FileStream(
            fullPath,
            FileMode.CreateNew,
            FileAccess.Write,
            FileShare.None,
            81920,
            useAsync: true);

        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var buffer = new byte[81920];
        long size = 0;

        while (true)
        {
            var read = await input.ReadAsync(buffer.AsMemory(0, buffer.Length), cancellationToken);
            if (read == 0)
                break;

            hash.AppendData(buffer, 0, read);
            await output.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
            size += read;
        }

        await output.FlushAsync(cancellationToken);

        var checksum = Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();

        return new StoredArchiveFile(
            id,
            relativeDirectory.Replace('\\', '/') + "/" + safeName,
            fullPath,
            size,
            checksum);
    }

    public async Task<string> ResolveFullPathAsync(
        string storedRelativePath,
        CancellationToken cancellationToken = default)
    {
        var configuration = await configurationStore.LoadAsync(cancellationToken)
            ?? throw new InvalidOperationException("Archive storage has not been configured.");

        var root = Path.GetFullPath(configuration.PrimaryArchivePath)
            .TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;

        var relative = storedRelativePath.Replace('/', Path.DirectorySeparatorChar);
        var fullPath = Path.GetFullPath(Path.Combine(root, relative));

        if (!fullPath.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("The stored archive path is invalid.");

        return fullPath;
    }

    public static void DeleteIfExists(string fullPath)
    {
        try
        {
            if (File.Exists(fullPath))
                File.Delete(fullPath);
        }
        catch
        {
            // A duplicate cleanup failure must not delete the authoritative original.
        }
    }

    private static string SanitizeFileName(string fileName)
    {
        var name = Path.GetFileName(fileName);
        foreach (var invalid in Path.GetInvalidFileNameChars())
            name = name.Replace(invalid, '_');

        return string.IsNullOrWhiteSpace(name) ? "archive-file.bin" : name;
    }
}

public sealed record StoredArchiveFile(
    Guid StorageId,
    string StoredRelativePath,
    string FullPath,
    long FileSizeBytes,
    string Sha256);
