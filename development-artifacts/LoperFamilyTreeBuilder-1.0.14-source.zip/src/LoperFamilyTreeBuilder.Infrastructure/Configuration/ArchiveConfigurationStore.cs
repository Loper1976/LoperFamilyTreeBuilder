using System.Text.Json;

namespace LoperFamilyTreeBuilder.Infrastructure.Configuration;

public sealed class ArchiveConfigurationStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    private readonly ApplicationPaths _paths;

    public ArchiveConfigurationStore(ApplicationPaths paths)
    {
        _paths = paths;
    }

    public async Task<ArchiveConfiguration?> LoadAsync(
        CancellationToken cancellationToken = default)
    {
        _paths.EnsureLocalDirectories();

        ArchiveConfiguration? configuration = null;

        if (File.Exists(_paths.ConfigurationFile))
        {
            await using var stream = File.OpenRead(_paths.ConfigurationFile);
            configuration = await JsonSerializer.DeserializeAsync<ArchiveConfiguration>(
                stream,
                JsonOptions,
                cancellationToken);
        }

        var hostedArchive = Environment.GetEnvironmentVariable("LOPER_PRIMARY_ARCHIVE_PATH")?.Trim();
        var hostedBackup = Environment.GetEnvironmentVariable("LOPER_BACKUP_PATH")?.Trim();

        if (configuration is null
            && string.IsNullOrWhiteSpace(hostedArchive)
            && string.IsNullOrWhiteSpace(hostedBackup))
        {
            return null;
        }

        configuration ??= new ArchiveConfiguration();

        if (!string.IsNullOrWhiteSpace(hostedArchive))
            configuration.PrimaryArchivePath = hostedArchive;

        if (!string.IsNullOrWhiteSpace(hostedBackup))
            configuration.BackupPath = hostedBackup;

        return configuration;
    }

    public async Task SaveAsync(
        ArchiveConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(configuration);

        if (!configuration.IsComplete)
        {
            throw new InvalidOperationException(
                "Primary archive and backup locations are both required.");
        }

        _paths.EnsureLocalDirectories();

        var temporaryFile = _paths.ConfigurationFile + ".tmp";

        await using (var stream = File.Create(temporaryFile))
        {
            await JsonSerializer.SerializeAsync(
                stream,
                configuration,
                JsonOptions,
                cancellationToken);

            await stream.FlushAsync(cancellationToken);
        }

        File.Move(
            temporaryFile,
            _paths.ConfigurationFile,
            overwrite: true);
    }
}
