namespace LoperFamilyTreeBuilder.Infrastructure.Configuration;

public sealed class ApplicationPaths
{
    private const string ProductFolderName = "Loper Family Tree Builder";

    public string LocalApplicationRoot =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            ProductFolderName);

    public string ConfigurationDirectory =>
        Path.Combine(LocalApplicationRoot, "Config");

    public string ConfigurationFile =>
        Path.Combine(ConfigurationDirectory, "archive-settings.json");

    public string DatabaseDirectory =>
        Path.Combine(LocalApplicationRoot, "Database");

    public string DatabaseFile =>
        Path.Combine(DatabaseDirectory, "LoperFamilyTreeBuilder.mdf");

    public string DatabaseLogFile =>
        Path.Combine(DatabaseDirectory, "LoperFamilyTreeBuilder_log.ldf");

    public string PendingRestoreRequestFile =>
        Path.Combine(ConfigurationDirectory, "pending-restore.json");

    public string LogDirectory =>
        Path.Combine(LocalApplicationRoot, "Logs");

    public void EnsureLocalDirectories()
    {
        Directory.CreateDirectory(ConfigurationDirectory);
        Directory.CreateDirectory(DatabaseDirectory);
        Directory.CreateDirectory(LogDirectory);
    }
}
