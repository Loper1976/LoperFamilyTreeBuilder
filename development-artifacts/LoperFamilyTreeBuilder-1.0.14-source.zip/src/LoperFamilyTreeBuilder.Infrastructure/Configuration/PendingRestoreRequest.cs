namespace LoperFamilyTreeBuilder.Infrastructure.Configuration;

public sealed class PendingRestoreRequest
{
    public string BackupDirectory { get; set; } = string.Empty;
    public string DatabaseBackupFile { get; set; } = string.Empty;
    public string ConfigurationFile { get; set; } = string.Empty;
    public DateTimeOffset RequestedUtc { get; set; } = DateTimeOffset.UtcNow;
}
