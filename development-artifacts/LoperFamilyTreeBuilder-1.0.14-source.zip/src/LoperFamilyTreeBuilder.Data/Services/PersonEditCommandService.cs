using System.Text.Json;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class PersonEditCommandService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task UpdateAsync(
        UpdatePersonRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var givenName = request.GivenName.Trim();
        var surname = request.Surname.Trim();

        if (string.IsNullOrWhiteSpace(givenName) &&
            string.IsNullOrWhiteSpace(surname))
        {
            throw new InvalidOperationException(
                "A person must have at least a given name or surname.");
        }

        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        var person = await db.People
            .Include(item => item.BranchMemberships)
            .SingleOrDefaultAsync(
                item => item.Id == request.PersonId,
                cancellationToken)
            ?? throw new InvalidOperationException(
                "The person record could not be found.");

        var legacyNumber = await db.PersonIdentifiers
            .AsNoTracking()
            .Where(identifier =>
                identifier.PersonId == person.Id &&
                identifier.IdentifierType ==
                    PersonIdentifierType.LegacyNumber)
            .Select(identifier => identifier.Value)
            .FirstOrDefaultAsync(cancellationToken);

        var before = JsonSerializer.Serialize(new
        {
            person.GivenName,
            person.MiddleName,
            person.Surname,
            person.Suffix,
            person.BirthDate,
            person.DeathDate,
            person.IsLiving,
            LegacyNumber = legacyNumber,
            Branches = person.BranchMemberships.Select(membership => new
            {
                membership.FamilyBranchId,
                membership.IsPrimary
            })
        });

        person.UpdateName(
            givenName,
            request.MiddleName.Trim(),
            surname,
            request.Suffix.Trim());

        person.SetBirthDate(request.BirthDate);

        if (request.DeathDate.HasValue)
        {
            person.SetDeathDate(request.DeathDate);
        }
        else
        {
            person.SetDeathDate(null);
            person.SetLivingStatus(request.IsLiving);
        }

        if (request.PrimaryFamilyBranchId.HasValue)
        {
            var branchExists = await db.FamilyBranches
                .AnyAsync(
                    branch => branch.Id == request.PrimaryFamilyBranchId.Value,
                    cancellationToken);

            if (!branchExists)
            {
                throw new InvalidOperationException(
                    "The selected family branch no longer exists.");
            }

            foreach (var membership in person.BranchMemberships)
            {
                membership.SetPrimary(
                    membership.FamilyBranchId ==
                    request.PrimaryFamilyBranchId.Value);
            }

            if (!person.BranchMemberships.Any(membership =>
                membership.FamilyBranchId ==
                request.PrimaryFamilyBranchId.Value))
            {
                db.BranchMemberships.Add(
                    new BranchMembership(
                        person.Id,
                        request.PrimaryFamilyBranchId.Value,
                        isPrimary: true));
            }
        }

        var after = JsonSerializer.Serialize(new
        {
            person.GivenName,
            person.MiddleName,
            person.Surname,
            person.Suffix,
            person.BirthDate,
            person.DeathDate,
            person.IsLiving,
            LegacyNumber = legacyNumber,
            PrimaryFamilyBranchId = request.PrimaryFamilyBranchId
        });

        db.AuditEvents.Add(
            new AuditEvent(
                action: "Update",
                entityType: nameof(Person),
                entityId: person.Id.ToString(),
                actor: actor,
                summary: $"Updated person record: {person.DisplayName}",
                previousValueJson: before,
                newValueJson: after,
                reason: string.IsNullOrWhiteSpace(request.Reason)
                    ? "Person profile edit"
                    : request.Reason.Trim(),
                source: "Person Profile"));

        await db.SaveChangesAsync(cancellationToken);
    }
}
