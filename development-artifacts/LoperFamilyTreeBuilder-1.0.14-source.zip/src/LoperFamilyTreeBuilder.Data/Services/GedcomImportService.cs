using System.Text.Json;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using LoperFamilyTreeBuilder.ImportExport.Gedcom;
using LoperFamilyTreeBuilder.Infrastructure.Storage;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class GedcomImportService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory,
    ArchiveMediaStorageService storageService,
    DatabaseBackupService backupService)
{
    private readonly GedcomParser _parser = new();
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = false };

    public GedcomValidationReport Validate(string fileName, byte[] content)
    {
        var doc = _parser.Parse(content);
        return new GedcomValidationReport(
            IsValid: doc.Errors.Count == 0,
            FileName: fileName,
            LineCount: doc.LineCount,
            IndividualCount: doc.Individuals.Count,
            FamilyCount: doc.Families.Count,
            SourceCount: doc.Sources.Count,
            Errors: doc.Errors,
            Warnings: doc.Warnings,
            UnsupportedTags: doc.UnsupportedTags
                .Select(x => $"Line {x.LineNumber}: {x.Tag} {x.Value}".Trim())
                .ToList());
    }

    public async Task<Guid> CreatePreviewAsync(
        GedcomPreviewRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (request.Content.Length == 0)
            throw new InvalidOperationException("Select a GEDCOM file before previewing it.");

        var doc = _parser.Parse(request.Content);
        if (doc.Errors.Count > 0)
            throw new InvalidOperationException("The GEDCOM file contains validation errors. Use GEDCOM Validation to review them first.");

        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);

        var plannedPeople = new List<GedcomPlannedPerson>();
        var pointerMap = new Dictionary<string, Guid?>(StringComparer.OrdinalIgnoreCase);
        var issues = new List<(GedcomImportIssueType Type, string Pointer, string Message, string Details)>();

        foreach (var individual in doc.Individuals)
        {
            var externalId = individual.Pointer;
            var externalMatch = await db.PersonIdentifiers
                .AsNoTracking()
                .Where(i => i.IdentifierType == PersonIdentifierType.GedcomExternalId && i.Value == externalId)
                .Select(i => (Guid?)i.PersonId)
                .FirstOrDefaultAsync(cancellationToken);

            Guid? matchedId = externalMatch;
            var reason = string.Empty;

            if (matchedId.HasValue)
            {
                reason = "GEDCOM external ID already exists.";
            }
            else
            {
                var given = individual.GivenName.Trim();
                var surname = individual.Surname.Trim();
                var candidates = db.People.AsNoTracking()
                    .Where(p => p.GivenName == given && p.Surname == surname);

                if (individual.BirthDate.HasValue)
                    candidates = candidates.Where(p => p.BirthDate == individual.BirthDate);

                var matches = await candidates
                    .Select(p => p.Id)
                    .Take(2)
                    .ToListAsync(cancellationToken);

                if (matches.Count == 1)
                {
                    matchedId = matches[0];
                    reason = individual.BirthDate.HasValue
                        ? "Same given name, surname, and birth date."
                        : "Same given name and surname; birth date is not exact in the import.";
                }
                else if (matches.Count > 1)
                {
                    reason = "Multiple existing people match this imported name/date. Manual conflict review is required.";
                }
            }

            var isDuplicate = matchedId.HasValue || !string.IsNullOrWhiteSpace(reason);
            if (isDuplicate)
            {
                issues.Add((
                    matchedId.HasValue ? GedcomImportIssueType.DuplicateCandidate : GedcomImportIssueType.Conflict,
                    individual.Pointer,
                    reason,
                    $"Imported person: {individual.Name}"));
            }

            pointerMap[individual.Pointer] = matchedId;
            plannedPeople.Add(new GedcomPlannedPerson(
                individual.Pointer,
                individual.GivenName,
                individual.Surname,
                string.IsNullOrWhiteSpace(individual.Name)
                    ? string.Join(" ", new[] { individual.GivenName, individual.Surname }.Where(x => !string.IsNullOrWhiteSpace(x)))
                    : individual.Name.Replace("/", string.Empty).Trim(),
                individual.BirthDate,
                individual.DeathDate,
                externalId,
                isDuplicate,
                matchedId,
                reason,
                WillCreate: !isDuplicate));
        }

        var plannedFamilies = doc.Families.Select(family =>
        {
            var refs = new[] { family.HusbandPointer, family.WifePointer }
                .Concat(family.ChildPointers.Cast<string?>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Cast<string>()
                .ToList();
            var missing = refs.Where(x => !doc.Individuals.Any(i => i.Pointer.Equals(x, StringComparison.OrdinalIgnoreCase))).ToList();
            var canApply = missing.Count == 0;
            var note = canApply ? string.Empty : $"Missing individual reference(s): {string.Join(", ", missing)}";
            if (!canApply)
                issues.Add((GedcomImportIssueType.Conflict, family.Pointer, "Family record has missing individual references.", note));

            return new GedcomPlannedFamily(
                family.Pointer,
                family.HusbandPointer,
                family.WifePointer,
                family.ChildPointers,
                family.MarriageDate,
                canApply,
                note);
        }).ToList();

        foreach (var tag in doc.UnsupportedTags)
            issues.Add((GedcomImportIssueType.UnsupportedTag, $"line:{tag.LineNumber}", $"Unsupported tag {tag.Tag}", tag.Value));
        foreach (var warning in doc.Warnings)
            issues.Add((GedcomImportIssueType.ValidationWarning, string.Empty, warning, string.Empty));

        await using var contentStream = new MemoryStream(request.Content, writable: false);
        var stored = await storageService.StoreOriginalAsync(
            contentStream,
            request.OriginalFileName,
            "GedcomImports",
            cancellationToken);

        var plan = new GedcomStoredPlan(plannedPeople, plannedFamilies, doc.Individuals, doc.Families);
        var session = new GedcomImportSession(
            request.OriginalFileName,
            stored.StoredRelativePath,
            stored.Sha256,
            doc.Individuals.Count,
            doc.Families.Count,
            doc.Sources.Count,
            JsonSerializer.Serialize(plan, JsonOptions));

        session.SetIssueCounts(
            doc.UnsupportedTags.Count,
            issues.Count(i => i.Type == GedcomImportIssueType.DuplicateCandidate),
            issues.Count(i => i.Type == GedcomImportIssueType.Conflict));

        db.GedcomImportSessions.Add(session);
        foreach (var issue in issues)
            db.GedcomImportIssues.Add(new GedcomImportIssue(session.Id, issue.Type, issue.Pointer, issue.Message, issue.Details));

        db.AuditEvents.Add(new AuditEvent(
            "GEDCOM Preview",
            nameof(GedcomImportSession),
            session.Id.ToString(),
            actor,
            $"Created read-only GEDCOM import preview for {request.OriginalFileName}."));

        await db.SaveChangesAsync(cancellationToken);
        return session.Id;
    }

    public async Task<IReadOnlyList<GedcomImportSessionListItem>> GetSessionsAsync(
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        return await db.GedcomImportSessions.AsNoTracking()
            .OrderByDescending(x => x.CreatedUtc)
            .Select(x => new GedcomImportSessionListItem(
                x.Id, x.OriginalFileName, x.Status, x.IndividualCount, x.FamilyCount, x.SourceCount,
                x.UnsupportedTagCount, x.DuplicateCandidateCount, x.ConflictCount,
                x.CreatedUtc, x.ApprovedUtc, x.AppliedUtc))
            .Take(100)
            .ToListAsync(cancellationToken);
    }

    public async Task<GedcomImportReviewModel?> GetReviewAsync(Guid sessionId, CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var session = await db.GedcomImportSessions.AsNoTracking().SingleOrDefaultAsync(x => x.Id == sessionId, cancellationToken);
        if (session is null) return null;
        var plan = JsonSerializer.Deserialize<GedcomStoredPlan>(session.ImportPlanJson, JsonOptions)
            ?? new GedcomStoredPlan([], [], [], []);
        var issues = await db.GedcomImportIssues.AsNoTracking()
            .Where(x => x.ImportSessionId == sessionId)
            .OrderBy(x => x.IssueType).ThenBy(x => x.RecordPointer)
            .Select(x => new GedcomImportIssueListItem(x.IssueType, x.RecordPointer, x.Message, x.Details))
            .ToListAsync(cancellationToken);

        return new GedcomImportReviewModel(
            new GedcomImportSessionListItem(session.Id, session.OriginalFileName, session.Status,
                session.IndividualCount, session.FamilyCount, session.SourceCount,
                session.UnsupportedTagCount, session.DuplicateCandidateCount, session.ConflictCount,
                session.CreatedUtc, session.ApprovedUtc, session.AppliedUtc),
            issues, plan.PlannedPeople, plan.PlannedFamilies);
    }

    public async Task ApproveAsync(Guid sessionId, string actor, CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var session = await db.GedcomImportSessions.SingleAsync(x => x.Id == sessionId, cancellationToken);
        session.Approve();
        db.AuditEvents.Add(new AuditEvent("GEDCOM Approve", nameof(GedcomImportSession), session.Id.ToString(), actor,
            $"Approved GEDCOM import plan for {session.OriginalFileName}."));
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task<GedcomApplyResult> ApplyAsync(Guid sessionId, string actor, CancellationToken cancellationToken = default)
    {
        var backupPath = await backupService.CreatePreImportBackupAsync(cancellationToken);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        await using var transaction = await db.Database.BeginTransactionAsync(cancellationToken);
        try
        {
            var session = await db.GedcomImportSessions.SingleAsync(x => x.Id == sessionId, cancellationToken);
            if (session.Status != GedcomImportStatus.Approved)
                throw new InvalidOperationException("The import must be approved before it can be applied.");

            var plan = JsonSerializer.Deserialize<GedcomStoredPlan>(session.ImportPlanJson, JsonOptions)
                ?? throw new InvalidOperationException("The stored import plan could not be read.");

            var pointerToPerson = new Dictionary<string, Guid>(StringComparer.OrdinalIgnoreCase);
            var peopleCreated = 0;
            var skipped = 0;

            foreach (var planned in plan.PlannedPeople)
            {
                if (!planned.WillCreate)
                {
                    skipped++;
                    if (planned.MatchedPersonId.HasValue)
                        pointerToPerson[planned.Pointer] = planned.MatchedPersonId.Value;
                    continue;
                }

                var source = plan.Individuals.Single(i => i.Pointer.Equals(planned.Pointer, StringComparison.OrdinalIgnoreCase));
                var person = new Person(source.GivenName.Trim(), source.Surname.Trim());
                person.SetBirthDate(source.BirthDate);
                if (source.DeathDate.HasValue)
                    person.SetDeathDate(source.DeathDate);
                person.AddIdentifier(PersonIdentifierType.GedcomExternalId, source.Pointer);
                db.People.Add(person);
                pointerToPerson[source.Pointer] = person.Id;
                peopleCreated++;

                db.AuditEvents.Add(new AuditEvent("GEDCOM Create Person", nameof(Person), person.Id.ToString(), actor,
                    $"Created {person.DisplayName} from GEDCOM session {session.Id}."));
            }

            var parentChildCreated = 0;
            var coupleCreated = 0;
            foreach (var family in plan.Families)
            {
                if (family.HusbandPointer is not null && family.WifePointer is not null &&
                    pointerToPerson.TryGetValue(family.HusbandPointer, out var husbandId) &&
                    pointerToPerson.TryGetValue(family.WifePointer, out var wifeId) && husbandId != wifeId)
                {
                    var exists = await db.CoupleRelationships.AnyAsync(x =>
                        (x.PersonAId == husbandId && x.PersonBId == wifeId) ||
                        (x.PersonAId == wifeId && x.PersonBId == husbandId), cancellationToken);
                    if (!exists)
                    {
                        var relationship = new CoupleRelationship(husbandId, wifeId, CoupleRelationshipType.Spouse);
                        relationship.Update(CoupleRelationshipType.Spouse, family.MarriageDate, null, "Imported from GEDCOM");
                        db.CoupleRelationships.Add(relationship);
                        coupleCreated++;
                    }
                }

                var parentPointers = new[] { family.HusbandPointer, family.WifePointer }
                    .Where(x => !string.IsNullOrWhiteSpace(x)).Cast<string>().ToList();
                foreach (var childPointer in family.ChildPointers)
                {
                    if (!pointerToPerson.TryGetValue(childPointer, out var childId)) continue;
                    foreach (var parentPointer in parentPointers)
                    {
                        if (!pointerToPerson.TryGetValue(parentPointer, out var parentId) || parentId == childId) continue;
                        var exists = await db.ParentChildRelationships.AnyAsync(x =>
                            x.ParentPersonId == parentId && x.ChildPersonId == childId, cancellationToken);
                        if (!exists)
                        {
                            db.ParentChildRelationships.Add(new ParentChildRelationship(parentId, childId, ParentChildRelationshipType.Biological));
                            parentChildCreated++;
                        }
                    }
                }
            }

            session.MarkApplied(backupPath);
            db.AuditEvents.Add(new AuditEvent("GEDCOM Apply", nameof(GedcomImportSession), session.Id.ToString(), actor,
                $"Applied GEDCOM import. Created {peopleCreated} people, {parentChildCreated} parent-child relationships, and {coupleCreated} couple relationships. Backup: {backupPath}"));

            await db.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);
            return new GedcomApplyResult(peopleCreated, parentChildCreated, coupleCreated, skipped, backupPath);
        }
        catch
        {
            await transaction.RollbackAsync(cancellationToken);
            throw;
        }
    }

    public sealed record GedcomStoredPlan(
        IReadOnlyList<GedcomPlannedPerson> PlannedPeople,
        IReadOnlyList<GedcomPlannedFamily> PlannedFamilies,
        IReadOnlyList<GedcomIndividual> Individuals,
        IReadOnlyList<GedcomFamily> Families);
}
