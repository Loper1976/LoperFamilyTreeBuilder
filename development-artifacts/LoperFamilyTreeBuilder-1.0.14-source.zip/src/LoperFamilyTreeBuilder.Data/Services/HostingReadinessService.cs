using LoperFamilyTreeBuilder.Core.Models;
using LoperFamilyTreeBuilder.Infrastructure.Configuration;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class HostingReadinessService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory,
    ArchiveConfigurationStore configurationStore,
    LocalDbConnectionStringFactory connectionStringFactory)
{
    public async Task<HostingReadinessReport> GetReportAsync(CancellationToken cancellationToken = default)
    {
        var hostedMode = IsTrue(Environment.GetEnvironmentVariable("LOPER_HOSTED_MODE"));
        var publicBaseUrl = Environment.GetEnvironmentVariable("LOPER_PUBLIC_BASE_URL")?.Trim() ?? string.Empty;
        var checks = new List<HostingReadinessCheck>();

        var httpsUrl = Uri.TryCreate(publicBaseUrl, UriKind.Absolute, out var uri)
            && string.Equals(uri.Scheme, Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase);
        checks.Add(new HostingReadinessCheck(
            "Public HTTPS URL",
            httpsUrl,
            httpsUrl ? "A valid HTTPS public base URL is configured." : "Set LOPER_PUBLIC_BASE_URL to the final HTTPS site URL.",
            true));

        var connectionString = connectionStringFactory.Create();
        var productionDatabase = !connectionString.Contains("(localdb)", StringComparison.OrdinalIgnoreCase);
        checks.Add(new HostingReadinessCheck(
            "Production database",
            productionDatabase,
            productionDatabase ? "A non-LocalDB connection string is configured." : "Hosted deployment must use LOPER_FAMILYTREE_CONNECTION_STRING instead of LocalDB.",
            true));

        var configuration = await configurationStore.LoadAsync(cancellationToken);
        var archiveReady = configuration is not null && configuration.IsComplete
            && Directory.Exists(configuration.PrimaryArchivePath);
        checks.Add(new HostingReadinessCheck(
            "Archive storage",
            archiveReady,
            archiveReady ? "Primary archive storage is reachable." : "Configure reachable primary archive and backup storage for the hosted service account.",
            true));

        var backupReady = configuration is not null && configuration.IsComplete
            && Directory.Exists(configuration.BackupPath);
        checks.Add(new HostingReadinessCheck(
            "Backup storage",
            backupReady,
            backupReady ? "Backup storage is reachable." : "Configure independent backup storage before production deployment.",
            true));

        var databaseReachable = false;
        var ownerExists = false;
        try
        {
            await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
            databaseReachable = await db.Database.CanConnectAsync(cancellationToken);
            if (databaseReachable)
                ownerExists = await db.UserRoleMemberships.AnyAsync(x => x.Role == Core.Entities.FamilyRole.ProjectOwner, cancellationToken);
        }
        catch
        {
            databaseReachable = false;
        }

        checks.Add(new HostingReadinessCheck(
            "Database connectivity",
            databaseReachable,
            databaseReachable ? "The application can connect to the configured database." : "The configured database is not reachable.",
            true));

        checks.Add(new HostingReadinessCheck(
            "Project Owner account",
            ownerExists,
            ownerExists ? "A Project Owner account exists." : "Create and protect a Project Owner account before remote access is enabled.",
            true));

        var emailConfigured = !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("LOPER_EMAIL_PROVIDER"));
        checks.Add(new HostingReadinessCheck(
            "Email provider",
            emailConfigured,
            emailConfigured ? "An email-provider identifier is configured." : "Email delivery is not configured; invitations and password-reset delivery remain local/manual.",
            false));

        var monitoringConfigured = !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("LOPER_MONITORING_PROVIDER"));
        checks.Add(new HostingReadinessCheck(
            "Monitoring",
            monitoringConfigured,
            monitoringConfigured ? "A monitoring-provider identifier is configured." : "Production monitoring has not been selected.",
            false));

        var requiredPassed = checks.Where(x => x.Required).All(x => x.Passed);
        return new HostingReadinessReport(hostedMode, hostedMode && requiredPassed, publicBaseUrl, checks);
    }

    private static bool IsTrue(string? value) =>
        string.Equals(value, "true", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "1", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "yes", StringComparison.OrdinalIgnoreCase);
}
