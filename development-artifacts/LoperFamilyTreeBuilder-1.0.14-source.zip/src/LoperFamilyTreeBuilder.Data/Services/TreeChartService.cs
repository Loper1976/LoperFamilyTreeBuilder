using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class TreeChartService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<PersonLookupItem?> GetFirstPersonAsync(
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);

        var row = await db.People
            .AsNoTracking()
            .OrderBy(p => p.Surname)
            .ThenBy(p => p.GivenName)
            .Select(p => new
            {
                p.Id,
                p.GivenName,
                p.MiddleName,
                p.Surname,
                p.Suffix,
                p.BirthDate,
                p.DeathDate,
                LegacyNumber = p.Identifiers
                    .Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber)
                    .Select(i => i.Value)
                    .FirstOrDefault(),
                Branch = p.BranchMemberships
                    .OrderByDescending(m => m.IsPrimary)
                    .Select(m => m.FamilyBranch.Name)
                    .FirstOrDefault()
            })
            .FirstOrDefaultAsync(cancellationToken);

        if (row is null)
            return null;

        return new PersonLookupItem(
            row.Id,
            BuildDisplayName(row.GivenName, row.MiddleName, row.Surname, row.Suffix),
            row.BirthDate,
            row.DeathDate,
            row.LegacyNumber,
            row.Branch);
    }

    public async Task<TreeChartResult?> GetPedigreeAsync(
        Guid startPersonId,
        int generationDepth,
        CancellationToken cancellationToken = default)
    {
        generationDepth = Math.Clamp(generationDepth, 1, 12);
        var snapshot = await LoadSnapshotAsync(cancellationToken);

        if (!snapshot.People.TryGetValue(startPersonId, out var start))
            return null;

        var nodes = new List<TreePersonNode>
        {
            ToNode(start, 0, null, "Starting person")
        };

        var queue = new Queue<(Guid PersonId, int Generation)>();
        queue.Enqueue((startPersonId, 0));
        var visited = new HashSet<Guid> { startPersonId };

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            if (current.Generation >= generationDepth)
                continue;

            foreach (var rel in snapshot.ParentChild
                .Where(r => r.ChildPersonId == current.PersonId))
            {
                if (!snapshot.People.TryGetValue(rel.ParentPersonId, out var parent))
                    continue;

                var generation = current.Generation + 1;
                nodes.Add(ToNode(
                    parent,
                    generation,
                    current.PersonId,
                    $"{FormatEnum(rel.RelationshipType)} parent"));

                if (visited.Add(parent.Id))
                    queue.Enqueue((parent.Id, generation));
            }
        }

        return new TreeChartResult(start.Id, start.DisplayName, generationDepth, nodes);
    }

    public async Task<TreeChartResult?> GetDescendantsAsync(
        Guid startPersonId,
        int generationDepth,
        CancellationToken cancellationToken = default)
    {
        generationDepth = Math.Clamp(generationDepth, 1, 20);
        var snapshot = await LoadSnapshotAsync(cancellationToken);

        if (!snapshot.People.TryGetValue(startPersonId, out var start))
            return null;

        var nodes = new List<TreePersonNode>
        {
            ToNode(start, 0, null, "Starting person")
        };

        var queue = new Queue<(Guid PersonId, int Generation)>();
        queue.Enqueue((startPersonId, 0));
        var visited = new HashSet<Guid> { startPersonId };

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            if (current.Generation >= generationDepth)
                continue;

            foreach (var rel in snapshot.ParentChild
                .Where(r => r.ParentPersonId == current.PersonId))
            {
                if (!snapshot.People.TryGetValue(rel.ChildPersonId, out var child))
                    continue;

                var generation = current.Generation + 1;
                nodes.Add(ToNode(
                    child,
                    generation,
                    current.PersonId,
                    $"{FormatEnum(rel.RelationshipType)} child"));

                if (visited.Add(child.Id))
                    queue.Enqueue((child.Id, generation));
            }
        }

        return new TreeChartResult(start.Id, start.DisplayName, generationDepth, nodes);
    }

    public async Task<RelationshipPathResult> FindRelationshipAsync(
        Guid firstPersonId,
        Guid secondPersonId,
        CancellationToken cancellationToken = default)
    {
        if (firstPersonId == secondPersonId)
        {
            var snapshotSame = await LoadSnapshotAsync(cancellationToken);
            if (!snapshotSame.People.TryGetValue(firstPersonId, out var person))
                return new RelationshipPathResult(false, "Person not found.", []);

            return new RelationshipPathResult(
                true,
                "Both selections are the same person.",
                [new RelationshipPathStep(person.Id, person.DisplayName, person.LegacyNumber, "Same person")]);
        }

        var snapshot = await LoadSnapshotAsync(cancellationToken);
        if (!snapshot.People.ContainsKey(firstPersonId) ||
            !snapshot.People.ContainsKey(secondPersonId))
        {
            return new RelationshipPathResult(false, "One or both people were not found.", []);
        }

        var graph = BuildRelationshipGraph(snapshot);
        var queue = new Queue<Guid>();
        var previous = new Dictionary<Guid, (Guid PreviousId, string Connection)>();
        var visited = new HashSet<Guid> { firstPersonId };
        queue.Enqueue(firstPersonId);

        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            if (!graph.TryGetValue(current, out var edges))
                continue;

            foreach (var edge in edges)
            {
                if (!visited.Add(edge.TargetId))
                    continue;

                previous[edge.TargetId] = (current, edge.Label);
                if (edge.TargetId == secondPersonId)
                {
                    return BuildRelationshipResult(
                        snapshot,
                        firstPersonId,
                        secondPersonId,
                        previous);
                }

                queue.Enqueue(edge.TargetId);
            }
        }

        return new RelationshipPathResult(
            false,
            "No relationship path is recorded between these people.",
            []);
    }

    public async Task<TreeReportSummary> GetReportSummaryAsync(
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);

        var people = await db.People.CountAsync(cancellationToken);
        var living = await db.People.CountAsync(p => p.IsLiving, cancellationToken);
        var parentChild = await db.ParentChildRelationships.CountAsync(cancellationToken);
        var couples = await db.CoupleRelationships.CountAsync(cancellationToken);
        var branches = await db.FamilyBranches.CountAsync(cancellationToken);
        var legacy = await db.PersonIdentifiers.CountAsync(
            i => i.IdentifierType == PersonIdentifierType.LegacyNumber,
            cancellationToken);

        return new TreeReportSummary(
            people,
            parentChild,
            couples,
            legacy,
            living,
            people - living,
            branches);
    }

    private async Task<TreeSnapshot> LoadSnapshotAsync(CancellationToken cancellationToken)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);

        var peopleRows = await db.People
            .AsNoTracking()
            .Select(p => new
            {
                p.Id,
                p.GivenName,
                p.MiddleName,
                p.Surname,
                p.Suffix,
                p.BirthDate,
                p.DeathDate,
                LegacyNumber = p.Identifiers
                    .Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber)
                    .Select(i => i.Value)
                    .FirstOrDefault()
            })
            .ToListAsync(cancellationToken);

        var people = peopleRows.ToDictionary(
            p => p.Id,
            p => new TreePerson(
                p.Id,
                BuildDisplayName(p.GivenName, p.MiddleName, p.Surname, p.Suffix),
                p.LegacyNumber,
                p.BirthDate,
                p.DeathDate));

        var parentChild = await db.ParentChildRelationships
            .AsNoTracking()
            .Select(r => new ParentChildEdge(
                r.ParentPersonId,
                r.ChildPersonId,
                r.RelationshipType))
            .ToListAsync(cancellationToken);

        var couples = await db.CoupleRelationships
            .AsNoTracking()
            .Select(r => new CoupleEdge(
                r.PersonAId,
                r.PersonBId,
                r.RelationshipType))
            .ToListAsync(cancellationToken);

        return new TreeSnapshot(people, parentChild, couples);
    }

    private static Dictionary<Guid, List<GraphEdge>> BuildRelationshipGraph(TreeSnapshot snapshot)
    {
        var graph = snapshot.People.Keys.ToDictionary(id => id, _ => new List<GraphEdge>());

        foreach (var rel in snapshot.ParentChild)
        {
            graph[rel.ParentPersonId].Add(new GraphEdge(
                rel.ChildPersonId,
                $"{FormatEnum(rel.RelationshipType)} child"));
            graph[rel.ChildPersonId].Add(new GraphEdge(
                rel.ParentPersonId,
                $"{FormatEnum(rel.RelationshipType)} parent"));
        }

        foreach (var rel in snapshot.Couples)
        {
            var label = FormatEnum(rel.RelationshipType);
            graph[rel.PersonAId].Add(new GraphEdge(rel.PersonBId, label));
            graph[rel.PersonBId].Add(new GraphEdge(rel.PersonAId, label));
        }

        return graph;
    }

    private static RelationshipPathResult BuildRelationshipResult(
        TreeSnapshot snapshot,
        Guid firstPersonId,
        Guid secondPersonId,
        Dictionary<Guid, (Guid PreviousId, string Connection)> previous)
    {
        var reverse = new List<(Guid PersonId, string Connection)>();
        var current = secondPersonId;

        while (current != firstPersonId)
        {
            var link = previous[current];
            reverse.Add((current, link.Connection));
            current = link.PreviousId;
        }

        reverse.Reverse();

        var first = snapshot.People[firstPersonId];
        var steps = new List<RelationshipPathStep>
        {
            new(first.Id, first.DisplayName, first.LegacyNumber, "Starting person")
        };

        foreach (var item in reverse)
        {
            var person = snapshot.People[item.PersonId];
            steps.Add(new RelationshipPathStep(
                person.Id,
                person.DisplayName,
                person.LegacyNumber,
                item.Connection));
        }

        var description = DescribePath(steps);
        return new RelationshipPathResult(true, description, steps);
    }

    private static string DescribePath(IReadOnlyList<RelationshipPathStep> steps)
    {
        if (steps.Count == 2)
        {
            return $"{steps[1].DisplayName} is recorded as the {steps[1].ConnectionFromPrevious.ToLowerInvariant()} of {steps[0].DisplayName}.";
        }

        if (steps.Count == 3)
        {
            var a = steps[1].ConnectionFromPrevious.ToLowerInvariant();
            var b = steps[2].ConnectionFromPrevious.ToLowerInvariant();

            if (a.Contains("parent") && b.Contains("child"))
                return $"{steps[0].DisplayName} and {steps[2].DisplayName} share a recorded parent path and are siblings or sibling-equivalent relatives.";

            if (a.Contains("parent") && b.Contains("parent"))
                return $"{steps[2].DisplayName} is a recorded grandparent of {steps[0].DisplayName}.";

            if (a.Contains("child") && b.Contains("child"))
                return $"{steps[2].DisplayName} is a recorded grandchild of {steps[0].DisplayName}.";
        }

        return $"A recorded relationship path connects {steps[0].DisplayName} and {steps[^1].DisplayName} through {steps.Count - 1} connection(s).";
    }

    private static TreePersonNode ToNode(
        TreePerson person,
        int generation,
        Guid? connectedFrom,
        string label) =>
        new(
            person.Id,
            person.DisplayName,
            person.LegacyNumber,
            person.BirthDate,
            person.DeathDate,
            generation,
            connectedFrom,
            label);

    private static string BuildDisplayName(
        string givenName,
        string middleName,
        string surname,
        string suffix) =>
        string.Join(" ", new[] { givenName, middleName, surname, suffix }
            .Where(value => !string.IsNullOrWhiteSpace(value)));

    private static string FormatEnum(Enum value)
    {
        var text = value.ToString();
        return string.Concat(text.Select((c, i) =>
            i > 0 && char.IsUpper(c) ? " " + c : c.ToString()));
    }

    private sealed record TreePerson(
        Guid Id,
        string DisplayName,
        string? LegacyNumber,
        DateOnly? BirthDate,
        DateOnly? DeathDate);

    private sealed record ParentChildEdge(
        Guid ParentPersonId,
        Guid ChildPersonId,
        ParentChildRelationshipType RelationshipType);

    private sealed record CoupleEdge(
        Guid PersonAId,
        Guid PersonBId,
        CoupleRelationshipType RelationshipType);

    private sealed record GraphEdge(Guid TargetId, string Label);

    private sealed record TreeSnapshot(
        Dictionary<Guid, TreePerson> People,
        IReadOnlyList<ParentChildEdge> ParentChild,
        IReadOnlyList<CoupleEdge> Couples);
}
