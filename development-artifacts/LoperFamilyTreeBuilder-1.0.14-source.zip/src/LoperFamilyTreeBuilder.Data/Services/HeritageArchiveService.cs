using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class HeritageArchiveService(IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<HeritageDashboardSummary> GetSummaryAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var cemeteries = await db.CemeteryRecords.CountAsync(cancellationToken);
        var burials = await db.BurialRecords.CountAsync(cancellationToken);
        var military = await db.MilitaryServiceRecords.CountAsync(cancellationToken);
        var stories = await db.FamilyStoryRecords.CountAsync(cancellationToken);
        var timeline = await db.TimelineEventRecords.CountAsync(cancellationToken);
        var mapCemeteries = await db.CemeteryRecords.CountAsync(x => x.Latitude.HasValue && x.Longitude.HasValue, cancellationToken);
        var mapBurials = await db.BurialRecords.CountAsync(x => x.Latitude.HasValue && x.Longitude.HasValue, cancellationToken);
        var mapTimeline = await db.TimelineEventRecords.CountAsync(x => x.Latitude.HasValue && x.Longitude.HasValue, cancellationToken);
        var missing = await db.BurialRecords.CountAsync(x => x.NeedsMarkerPhoto, cancellationToken);
        return new HeritageDashboardSummary(cemeteries, burials, military, stories, timeline, mapCemeteries + mapBurials + mapTimeline, missing);
    }

    public async Task<IReadOnlyList<CemeteryListItem>> GetCemeteriesAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        return await db.CemeteryRecords.AsNoTracking().OrderBy(x => x.Name)
            .Select(x => new CemeteryListItem(x.Id, x.Name, x.Address, x.City, x.StateRegion, x.Country,
                x.Latitude, x.Longitude, x.BoundaryNotes, x.Notes,
                db.BurialRecords.Count(b => b.CemeteryId == x.Id)))
            .ToListAsync(cancellationToken);
    }

    public async Task<Guid> CreateCemeteryAsync(CreateCemeteryRequest request, CancellationToken cancellationToken = default)
    {
        var entity = new CemeteryRecord(request.Name);
        entity.Update(request.Address, request.City, request.StateRegion, request.Country,
            request.Latitude, request.Longitude, request.BoundaryNotes, request.Notes);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        db.CemeteryRecords.Add(entity);
        db.AuditEvents.Add(new AuditEvent("Create cemetery", nameof(CemeteryRecord), entity.Id.ToString(),
            "Local Application", $"Created cemetery {entity.Name}.", source: "Cemetery workspace"));
        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task<IReadOnlyList<BurialListItem>> GetBurialsAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var rows = await db.BurialRecords.AsNoTracking()
            .OrderBy(x => x.Cemetery.Name).ThenBy(x => x.Person.Surname).ThenBy(x => x.Person.GivenName)
            .Select(x => new
            {
                x.Id, x.PersonId, x.CemeteryId, x.Cemetery.Name, x.BurialDate, x.Section, x.Plot, x.Row, x.Grave,
                x.MarkerInscription, x.Latitude, x.Longitude, x.NeedsMarkerPhoto, x.VisitStatus, x.Notes,
                x.Person.GivenName, x.Person.MiddleName, x.Person.Surname, x.Person.Suffix,
                Legacy = x.Person.Identifiers.Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber).Select(i => i.Value).FirstOrDefault()
            }).ToListAsync(cancellationToken);
        return rows.Select(x => new BurialListItem(x.Id, x.PersonId,
            Name(x.GivenName, x.MiddleName, x.Surname, x.Suffix), x.Legacy, x.CemeteryId, x.Name,
            x.BurialDate, x.Section, x.Plot, x.Row, x.Grave, x.MarkerInscription, x.Latitude, x.Longitude,
            x.NeedsMarkerPhoto, x.VisitStatus, x.Notes)).ToList();
    }

    public async Task<Guid> CreateBurialAsync(CreateBurialRequest request, CancellationToken cancellationToken = default)
    {
        var entity = new BurialRecord(request.PersonId, request.CemeteryId);
        entity.Update(request.BurialDate, request.Section, request.Plot, request.Row, request.Grave,
            request.MarkerInscription, request.Latitude, request.Longitude, request.NeedsMarkerPhoto,
            request.VisitStatus, request.Notes);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        db.BurialRecords.Add(entity);
        db.AuditEvents.Add(new AuditEvent("Create burial record", nameof(BurialRecord), entity.Id.ToString(),
            "Local Application", $"Created burial record for person {request.PersonId}.", source: "Cemetery workspace"));
        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task<IReadOnlyList<MilitaryServiceListItem>> GetMilitaryAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var rows = await db.MilitaryServiceRecords.AsNoTracking().OrderBy(x => x.Person.Surname).ThenBy(x => x.Person.GivenName)
            .Select(x => new { x.Id, x.PersonId, x.Branch, x.Component, x.RankRating, x.Specialty, x.StartDate, x.EndDate,
                x.UnitsShipsDutyStations, x.WarsCampaignsDeployments, x.AwardsQualifications, x.Discharge, x.Notes,
                x.Person.GivenName, x.Person.MiddleName, x.Person.Surname, x.Person.Suffix,
                Legacy = x.Person.Identifiers.Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber).Select(i => i.Value).FirstOrDefault() })
            .ToListAsync(cancellationToken);
        return rows.Select(x => new MilitaryServiceListItem(x.Id, x.PersonId, Name(x.GivenName,x.MiddleName,x.Surname,x.Suffix), x.Legacy,
            x.Branch,x.Component,x.RankRating,x.Specialty,x.StartDate,x.EndDate,x.UnitsShipsDutyStations,x.WarsCampaignsDeployments,x.AwardsQualifications,x.Discharge,x.Notes)).ToList();
    }

    public async Task<Guid> CreateMilitaryAsync(CreateMilitaryServiceRequest request, CancellationToken cancellationToken = default)
    {
        var entity = new MilitaryServiceRecord(request.PersonId, request.Branch);
        entity.Update(request.Component, request.RankRating, request.Specialty, request.ServiceNumber,
            request.StartDate, request.EndDate, request.UnitsShipsDutyStations, request.WarsCampaignsDeployments,
            request.AwardsQualifications, request.Discharge, request.Notes);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        db.MilitaryServiceRecords.Add(entity);
        db.AuditEvents.Add(new AuditEvent("Create military service", nameof(MilitaryServiceRecord), entity.Id.ToString(),
            "Local Application", $"Created military service record for person {request.PersonId}.", source: "Military workspace"));
        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task<IReadOnlyList<FamilyStoryListItem>> GetStoriesAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var rows = await db.FamilyStoryRecords.AsNoTracking().OrderByDescending(x => x.RecordedDate).ThenBy(x => x.Title)
            .Select(x => new { x.Id, x.PersonId, x.Title, x.OriginalText, x.EditedPublicationText, x.Contributor, x.RecordedDate, x.Notes, x.ModifiedUtc,
                PersonName = x.Person == null ? null : (x.Person.GivenName + " " + x.Person.MiddleName + " " + x.Person.Surname + " " + x.Person.Suffix) })
            .ToListAsync(cancellationToken);
        return rows.Select(x => new FamilyStoryListItem(x.Id,x.PersonId,x.PersonName == null ? null : x.PersonName.Replace("  "," ").Trim(),x.Title,x.OriginalText,x.EditedPublicationText,x.Contributor,x.RecordedDate,x.Notes,x.ModifiedUtc)).ToList();
    }

    public async Task<Guid> CreateStoryAsync(CreateFamilyStoryRequest request, CancellationToken cancellationToken = default)
    {
        var entity = new FamilyStoryRecord(request.Title, request.OriginalText);
        entity.Update(request.PersonId, request.EditedPublicationText, request.Contributor, request.RecordedDate, request.Notes);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        db.FamilyStoryRecords.Add(entity);
        db.AuditEvents.Add(new AuditEvent("Create family story", nameof(FamilyStoryRecord), entity.Id.ToString(),
            "Local Application", $"Created story {entity.Title}.", source: "Stories workspace"));
        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task<IReadOnlyList<TimelineEventListItem>> GetTimelineAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var rows = await db.TimelineEventRecords.AsNoTracking()
            .OrderBy(x => x.EventDate).ThenBy(x => x.ApproximateYear).ThenBy(x => x.Person.Surname)
            .Select(x => new { x.Id,x.PersonId,x.EventType,x.Title,x.EventDate,x.ApproximateYear,x.PlaceName,x.Latitude,x.Longitude,x.Description,x.SourceSummary,
                x.Person.GivenName,x.Person.MiddleName,x.Person.Surname,x.Person.Suffix,
                Legacy=x.Person.Identifiers.Where(i=>i.IdentifierType==PersonIdentifierType.LegacyNumber).Select(i=>i.Value).FirstOrDefault() }).ToListAsync(cancellationToken);
        return rows.Select(x=>new TimelineEventListItem(x.Id,x.PersonId,Name(x.GivenName,x.MiddleName,x.Surname,x.Suffix),x.Legacy,x.EventType,x.Title,x.EventDate,x.ApproximateYear,x.PlaceName,x.Latitude,x.Longitude,x.Description,x.SourceSummary)).ToList();
    }

    public async Task<Guid> CreateTimelineAsync(CreateTimelineEventRequest request, CancellationToken cancellationToken = default)
    {
        var entity = new TimelineEventRecord(request.PersonId, request.EventType, request.Title);
        entity.Update(request.EventDate, request.ApproximateYear, request.PlaceName, request.Latitude, request.Longitude, request.Description, request.SourceSummary);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        db.TimelineEventRecords.Add(entity);
        db.AuditEvents.Add(new AuditEvent("Create timeline event", nameof(TimelineEventRecord), entity.Id.ToString(),
            "Local Application", $"Created timeline event {entity.Title} for person {request.PersonId}.", source: "Timeline workspace"));
        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task<IReadOnlyList<HeritageMapPoint>> GetMapPointsAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var result = new List<HeritageMapPoint>();
        var cemeteries = await db.CemeteryRecords.AsNoTracking().Where(x=>x.Latitude.HasValue&&x.Longitude.HasValue).ToListAsync(cancellationToken);
        result.AddRange(cemeteries.Select(x=>new HeritageMapPoint("Cemetery",x.Name,string.Empty,x.Latitude!.Value,x.Longitude!.Value,$"{x.City}, {x.StateRegion}")));
        var burials = await GetBurialsAsync(cancellationToken);
        result.AddRange(burials.Where(x=>x.Latitude.HasValue&&x.Longitude.HasValue).Select(x=>new HeritageMapPoint("Grave",x.CemeteryName,x.PersonName,x.Latitude!.Value,x.Longitude!.Value,$"Section {x.Section} Plot {x.Plot} Row {x.Row} Grave {x.Grave}")));
        var timeline = await GetTimelineAsync(cancellationToken);
        result.AddRange(timeline.Where(x=>x.Latitude.HasValue&&x.Longitude.HasValue).Select(x=>new HeritageMapPoint("Timeline",x.PlaceName,x.PersonName,x.Latitude!.Value,x.Longitude!.Value,x.Title)));
        return result;
    }

    private static string Name(string g,string m,string s,string suffix)=>string.Join(" ",new[]{g,m,s,suffix}.Where(v=>!string.IsNullOrWhiteSpace(v)));
}
