using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class MedicalHealthService(IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<MedicalDashboardSummary> GetDashboardAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var personIds = await db.MedicalConditionRecords.AsNoTracking().Select(x => x.PersonId)
            .Concat(db.MedicalEventRecords.AsNoTracking().Select(x => x.PersonId))
            .Concat(db.CauseOfDeathRecords.AsNoTracking().Select(x => x.PersonId))
            .Distinct().CountAsync(cancellationToken);
        var conditions = await db.MedicalConditionRecords.CountAsync(cancellationToken);
        var events = await db.MedicalEventRecords.CountAsync(cancellationToken);
        var causes = await db.CauseOfDeathRecords.CountAsync(cancellationToken);
        var privateRecords = await db.MedicalConditionRecords.CountAsync(x => x.PrivacyLevel != MedicalPrivacyLevel.AuthorizedFamily, cancellationToken)
            + await db.MedicalEventRecords.CountAsync(x => x.PrivacyLevel != MedicalPrivacyLevel.AuthorizedFamily, cancellationToken)
            + await db.CauseOfDeathRecords.CountAsync(x => x.PrivacyLevel != MedicalPrivacyLevel.AuthorizedFamily, cancellationToken);
        return new MedicalDashboardSummary(personIds, conditions, events, causes, privateRecords);
    }

    public async Task<PersonMedicalHistoryModel?> GetPersonHistoryAsync(Guid personId, CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var person = await db.People.AsNoTracking().Where(x => x.Id == personId)
            .Select(x => new
            {
                x.Id, x.GivenName, x.MiddleName, x.Surname, x.Suffix, x.IsLiving,
                Legacy = x.Identifiers.Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber).Select(i => i.Value).FirstOrDefault()
            }).SingleOrDefaultAsync(cancellationToken);
        if (person is null) return null;
        var displayName = string.Join(" ", new[] { person.GivenName, person.MiddleName, person.Surname, person.Suffix }.Where(x => !string.IsNullOrWhiteSpace(x)));

        var conditions = await db.MedicalConditionRecords.AsNoTracking().Where(x => x.PersonId == personId)
            .OrderBy(x => x.ConditionName)
            .Select(x => new MedicalConditionListItem(x.Id, x.ConditionName, x.DiagnosisDate, x.ApproximateDiagnosisYear,
                x.AgeAtOnset, x.Status, x.EvidenceStatus, x.Severity, x.PotentialHereditaryRelevance,
                x.TreatingProvider, x.TreatingFacility, x.PrivacyLevel, x.ModifiedUtc))
            .ToListAsync(cancellationToken);

        var events = await db.MedicalEventRecords.AsNoTracking().Where(x => x.PersonId == personId)
            .OrderByDescending(x => x.EventDate).ThenByDescending(x => x.ApproximateYear)
            .Select(x => new MedicalEventListItem(x.Id, x.EventType, x.Title, x.EventDate, x.ApproximateYear,
                x.Description, x.TreatingProvider, x.TreatingFacility, x.EvidenceStatus, x.PrivacyLevel, x.ModifiedUtc))
            .ToListAsync(cancellationToken);

        var cause = await db.CauseOfDeathRecords.AsNoTracking().Where(x => x.PersonId == personId)
            .Select(x => new CauseOfDeathModel(x.Id, x.PrimaryCause, x.SecondaryCauses, x.ContributingConditions,
                x.EvidenceStatus, x.PrivacyLevel, x.ModifiedUtc)).SingleOrDefaultAsync(cancellationToken);

        return new PersonMedicalHistoryModel(person.Id, displayName, person.Legacy, person.IsLiving, conditions, events, cause);
    }

    public async Task<Guid> AddConditionAsync(CreateMedicalConditionRequest request, string actor, CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var living = await db.People.Where(x => x.Id == request.PersonId).Select(x => (bool?)x.IsLiving).SingleOrDefaultAsync(cancellationToken)
            ?? throw new InvalidOperationException("Person not found.");
        var record = new MedicalConditionRecord(request.PersonId, request.ConditionName);
        var privacy = living ? MedicalPrivacyLevel.Private : request.PrivacyLevel;
        record.Update(request.DiagnosisDate, request.ApproximateDiagnosisYear, request.AgeAtOnset,
            request.Status, request.EvidenceStatus, request.Severity, request.PotentialHereditaryRelevance,
            request.TreatingProvider, request.TreatingFacility, request.PrivateNotes, privacy);
        db.MedicalConditionRecords.Add(record);
        db.AuditEvents.Add(new AuditEvent("Medical Condition Add", nameof(MedicalConditionRecord), record.Id.ToString(), actor,
            $"Added private medical-history condition '{record.ConditionName}' for person {request.PersonId}."));
        await db.SaveChangesAsync(cancellationToken);
        return record.Id;
    }

    public async Task<Guid> AddEventAsync(CreateMedicalEventRequest request, string actor, CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var living = await db.People.Where(x => x.Id == request.PersonId).Select(x => (bool?)x.IsLiving).SingleOrDefaultAsync(cancellationToken)
            ?? throw new InvalidOperationException("Person not found.");
        var record = new MedicalEventRecord(request.PersonId, request.EventType, request.Title);
        var privacy = living ? MedicalPrivacyLevel.Private : request.PrivacyLevel;
        record.Update(request.EventDate, request.ApproximateYear, request.Description, request.TreatingProvider,
            request.TreatingFacility, request.EvidenceStatus, request.PrivateNotes, privacy);
        db.MedicalEventRecords.Add(record);
        db.AuditEvents.Add(new AuditEvent("Medical Event Add", nameof(MedicalEventRecord), record.Id.ToString(), actor,
            $"Added medical-history event '{record.Title}' for person {request.PersonId}."));
        await db.SaveChangesAsync(cancellationToken);
        return record.Id;
    }

    public async Task SaveCauseOfDeathAsync(SaveCauseOfDeathRequest request, string actor, CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var personExists = await db.People.AnyAsync(x => x.Id == request.PersonId, cancellationToken);
        if (!personExists) throw new InvalidOperationException("Person not found.");
        var record = await db.CauseOfDeathRecords.SingleOrDefaultAsync(x => x.PersonId == request.PersonId, cancellationToken);
        if (record is null)
        {
            record = new CauseOfDeathRecord(request.PersonId, request.PrimaryCause);
            db.CauseOfDeathRecords.Add(record);
        }
        record.Update(request.PrimaryCause, request.SecondaryCauses, request.ContributingConditions,
            request.EvidenceStatus, request.PrivateNotes, request.PrivacyLevel);
        db.AuditEvents.Add(new AuditEvent("Cause of Death Update", nameof(CauseOfDeathRecord), record.Id.ToString(), actor,
            $"Updated structured cause-of-death history for person {request.PersonId}."));
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task LinkEvidenceAsync(Guid personId, MedicalRecordType recordType, Guid recordId,
        Guid? citationId, Guid? mediaFileId, string actor, CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        if (citationId.HasValue && !await db.CitationRecords.AnyAsync(x => x.Id == citationId.Value && x.PersonId == personId, cancellationToken))
            throw new InvalidOperationException("Citation does not belong to this person.");
        if (mediaFileId.HasValue && !await db.PersonMediaLinks.AnyAsync(x => x.PersonId == personId && x.MediaFileId == mediaFileId.Value, cancellationToken))
            throw new InvalidOperationException("Archived document is not linked to this person.");
        var link = new MedicalEvidenceLink(personId, recordType, recordId, citationId, mediaFileId);
        db.MedicalEvidenceLinks.Add(link);
        db.AuditEvents.Add(new AuditEvent("Medical Evidence Link", nameof(MedicalEvidenceLink), link.Id.ToString(), actor,
            $"Linked preserved evidence to medical {recordType} record {recordId}."));
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<MedicalSearchResult>> SearchAsync(string searchText, CancellationToken cancellationToken = default)
    {
        var search = (searchText ?? string.Empty).Trim();
        if (search.Length < 2) return [];
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);

        var conditions = await db.MedicalConditionRecords.AsNoTracking()
            .Where(x => x.ConditionName.Contains(search))
            .Select(x => new MedicalSearchResult(x.PersonId,
                (x.Person.GivenName + " " + x.Person.MiddleName + " " + x.Person.Surname).Trim(),
                x.Person.Identifiers.Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber).Select(i => i.Value).FirstOrDefault(),
                "Condition", x.ConditionName, x.EvidenceStatus.ToString(), x.PrivacyLevel))
            .Take(100).ToListAsync(cancellationToken);

        var events = await db.MedicalEventRecords.AsNoTracking()
            .Where(x => x.Title.Contains(search) || x.Description.Contains(search))
            .Select(x => new MedicalSearchResult(x.PersonId,
                (x.Person.GivenName + " " + x.Person.MiddleName + " " + x.Person.Surname).Trim(),
                x.Person.Identifiers.Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber).Select(i => i.Value).FirstOrDefault(),
                "Event", x.Title, x.EvidenceStatus.ToString(), x.PrivacyLevel))
            .Take(100).ToListAsync(cancellationToken);

        return conditions.Concat(events).Take(150).ToList();
    }

    public async Task<IReadOnlyList<FamilyHealthPatternItem>> GetPatternsAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        return await db.MedicalConditionRecords.AsNoTracking()
            .GroupBy(x => x.ConditionName)
            .Select(g => new FamilyHealthPatternItem(
                g.Key,
                g.Select(x => x.PersonId).Distinct().Count(),
                g.Count(x => x.EvidenceStatus == MedicalEvidenceStatus.Confirmed),
                g.Count(x => x.EvidenceStatus == MedicalEvidenceStatus.Probable),
                g.Count(x => x.EvidenceStatus == MedicalEvidenceStatus.Suspected),
                g.Count(x => x.EvidenceStatus == MedicalEvidenceStatus.FamilyReported),
                g.Any(x => x.PotentialHereditaryRelevance)))
            .OrderByDescending(x => x.AffectedPeople).ThenBy(x => x.ConditionName)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<MedicalPedigreePerson>> GetPedigreeHighlightAsync(
        Guid centerPersonId, string conditionName, int generations = 3, CancellationToken cancellationToken = default)
    {
        generations = Math.Clamp(generations, 1, 6);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var people = await db.People.AsNoTracking().Select(p => new
        {
            p.Id,
            Name = (p.GivenName + " " + p.MiddleName + " " + p.Surname + " " + p.Suffix).Trim(),
            Legacy = p.Identifiers.Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber).Select(i => i.Value).FirstOrDefault()
        }).ToDictionaryAsync(x => x.Id, cancellationToken);
        if (!people.ContainsKey(centerPersonId)) return [];
        var relationships = await db.ParentChildRelationships.AsNoTracking()
            .Select(x => new { x.ParentPersonId, x.ChildPersonId }).ToListAsync(cancellationToken);
        var generationMap = new Dictionary<Guid, int> { [centerPersonId] = 0 };
        var queue = new Queue<(Guid Id, int Generation)>();
        queue.Enqueue((centerPersonId, 0));
        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            if (Math.Abs(current.Generation) >= generations) continue;
            foreach (var parent in relationships.Where(x => x.ChildPersonId == current.Id).Select(x => x.ParentPersonId))
                if (!generationMap.ContainsKey(parent)) { generationMap[parent] = current.Generation - 1; queue.Enqueue((parent, current.Generation - 1)); }
            foreach (var child in relationships.Where(x => x.ParentPersonId == current.Id).Select(x => x.ChildPersonId))
                if (!generationMap.ContainsKey(child)) { generationMap[child] = current.Generation + 1; queue.Enqueue((child, current.Generation + 1)); }
        }

        var relevantIds = generationMap.Keys.ToList();
        var affected = await db.MedicalConditionRecords.AsNoTracking()
            .Where(x => relevantIds.Contains(x.PersonId) && x.ConditionName == conditionName)
            .GroupBy(x => x.PersonId)
            .Select(g => new { PersonId = g.Key, Evidence = g.OrderBy(x => x.EvidenceStatus).Select(x => (MedicalEvidenceStatus?)x.EvidenceStatus).FirstOrDefault() })
            .ToDictionaryAsync(x => x.PersonId, x => x.Evidence, cancellationToken);

        return generationMap.OrderBy(x => x.Value).ThenBy(x => people[x.Key].Name)
            .Select(x => new MedicalPedigreePerson(x.Key, people[x.Key].Name, people[x.Key].Legacy, x.Value,
                x.Value < 0 ? "Ancestor" : x.Value > 0 ? "Descendant" : "Selected person",
                affected.ContainsKey(x.Key), affected.TryGetValue(x.Key, out var evidence) ? evidence : null))
            .ToList();
    }
}
