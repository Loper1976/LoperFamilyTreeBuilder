using System.Text.Json;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class PersonCommandService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<Guid> CreateAsync(
        CreatePersonRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var givenName = request.GivenName.Trim();
        var surname = request.Surname.Trim();

        if (string.IsNullOrWhiteSpace(givenName) &&
            string.IsNullOrWhiteSpace(surname))
        {
            throw new InvalidOperationException(
                "A person must have at least a given name or surname.");
        }

        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        var person = new Person(givenName, surname);

        person.UpdateName(
            givenName,
            request.MiddleName.Trim(),
            surname,
            request.Suffix.Trim());

        person.SetBirthDate(request.BirthDate);

        if (request.DeathDate.HasValue)
        {
            person.SetDeathDate(request.DeathDate);
        }
        else
        {
            person.SetLivingStatus(request.IsLiving);
        }

        if (!string.IsNullOrEmpty(request.LegacyNumber))
        {
            var exactLegacy = request.LegacyNumber;

            var duplicateLegacy = await db.PersonIdentifiers
                .AsNoTracking()
                .AnyAsync(identifier =>
                    identifier.IdentifierType ==
                        PersonIdentifierType.LegacyNumber &&
                    identifier.Value == exactLegacy,
                    cancellationToken);

            if (duplicateLegacy)
            {
                throw new InvalidOperationException(
                    "That Robert J. Loper Legacy Number is already assigned to another person. It was not changed or reused.");
            }

            person.AddLegacyNumber(exactLegacy);
        }

        db.People.Add(person);

        if (request.FamilyBranchId.HasValue)
        {
            var branchExists = await db.FamilyBranches
                .AsNoTracking()
                .AnyAsync(
                    branch => branch.Id == request.FamilyBranchId.Value,
                    cancellationToken);

            if (!branchExists)
            {
                throw new InvalidOperationException(
                    "The selected family branch no longer exists.");
            }

            db.BranchMemberships.Add(
                new BranchMembership(
                    person.Id,
                    request.FamilyBranchId.Value,
                    isPrimary: true));
        }

        var auditPayload = JsonSerializer.Serialize(new
        {
            person.Id,
            person.GivenName,
            person.MiddleName,
            person.Surname,
            person.Suffix,
            person.BirthDate,
            person.DeathDate,
            person.IsLiving,
            LegacyNumber = request.LegacyNumber,
            request.FamilyBranchId
        });

        db.AuditEvents.Add(
            new AuditEvent(
                action: "Create",
                entityType: nameof(Person),
                entityId: person.Id.ToString(),
                actor: actor,
                summary: $"Created person record: {person.DisplayName}",
                newValueJson: auditPayload));

        await db.SaveChangesAsync(cancellationToken);

        return person.Id;
    }
}
