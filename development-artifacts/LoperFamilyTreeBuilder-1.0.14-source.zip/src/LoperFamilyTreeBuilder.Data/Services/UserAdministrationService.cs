using System.Security.Cryptography;
using System.Text;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class UserAdministrationService(IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<bool> HasAnyUsersAsync(CancellationToken cancellationToken=default)
    { await using var db=await contextFactory.CreateDbContextAsync(cancellationToken); return await db.FamilyUsers.AnyAsync(cancellationToken); }

    public async Task<AuthenticatedFamilyUser> CreateFirstOwnerAsync(string email,string displayName,string password,CancellationToken cancellationToken=default)
    {
        await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);
        if(await db.FamilyUsers.AnyAsync(cancellationToken)) throw new InvalidOperationException("The project owner account has already been established.");
        ValidatePassword(password);
        var user=new FamilyUser(email,displayName,HashPassword(password)); db.FamilyUsers.Add(user); db.UserRoleMemberships.Add(new UserRoleMembership(user.Id,FamilyRole.ProjectOwner));
        db.AuditEvents.Add(new AuditEvent("Create project owner",nameof(FamilyUser),user.Id.ToString(),displayName,"Created the first local Project Owner account.",source:"Account setup"));
        await db.SaveChangesAsync(cancellationToken); return new AuthenticatedFamilyUser(user.Id,user.Email,user.DisplayName,[FamilyRole.ProjectOwner]);
    }

    public async Task<FamilyUserListItem> CreateUserAsync(string email,string displayName,string password,FamilyRole role,string actor,CancellationToken cancellationToken=default)
    {
        ValidatePassword(password); await using var db=await contextFactory.CreateDbContextAsync(cancellationToken); var normalized=(email??string.Empty).Trim().ToUpperInvariant();
        if(await db.FamilyUsers.AnyAsync(x=>x.NormalizedEmail==normalized,cancellationToken)) throw new InvalidOperationException("A user with that email already exists.");
        var user=new FamilyUser(email,displayName,HashPassword(password));db.FamilyUsers.Add(user);db.UserRoleMemberships.Add(new UserRoleMembership(user.Id,role));
        db.AuditEvents.Add(new AuditEvent("Create family user",nameof(FamilyUser),user.Id.ToString(),actor,$"Created {user.DisplayName} with role {role}.",source:"Users and permissions"));
        await db.SaveChangesAsync(cancellationToken);return new FamilyUserListItem(user.Id,user.Email,user.DisplayName,user.IsActive,user.IsLocked,[role],user.LastLoginUtc,user.CreatedUtc);
    }

    public async Task<AuthenticatedFamilyUser?> AuthenticateAsync(string email,string password,CancellationToken cancellationToken=default)
    {
        await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);var normalized=(email??string.Empty).Trim().ToUpperInvariant();
        var user=await db.FamilyUsers.SingleOrDefaultAsync(x=>x.NormalizedEmail==normalized,cancellationToken);if(user is null||!user.IsActive||user.IsLocked||!VerifyPassword(password,user.PasswordHash))return null;
        var roles=await db.UserRoleMemberships.Where(x=>x.FamilyUserId==user.Id).Select(x=>x.Role).ToListAsync(cancellationToken);user.RecordLogin();await db.SaveChangesAsync(cancellationToken);
        return new AuthenticatedFamilyUser(user.Id,user.Email,user.DisplayName,roles);
    }

    public async Task<IReadOnlyList<FamilyUserListItem>> GetUsersAsync(CancellationToken cancellationToken=default)
    {
        await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);var users=await db.FamilyUsers.AsNoTracking().OrderBy(x=>x.DisplayName).ToListAsync(cancellationToken);var memberships=await db.UserRoleMemberships.AsNoTracking().ToListAsync(cancellationToken);
        return users.Select(u=>new FamilyUserListItem(u.Id,u.Email,u.DisplayName,u.IsActive,u.IsLocked,memberships.Where(r=>r.FamilyUserId==u.Id).Select(r=>r.Role).OrderBy(r=>r).ToList(),u.LastLoginUtc,u.CreatedUtc)).ToList();
    }

    public async Task<InvitationResult> CreateInvitationAsync(string email,FamilyRole role,TimeSpan lifetime,string actor,CancellationToken cancellationToken=default)
    {
        var token=Convert.ToHexString(RandomNumberGenerator.GetBytes(24));var hash=HashToken(token);var expires=DateTimeOffset.UtcNow+lifetime;var invitation=new UserInvitation(email,role,hash,expires);
        await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);db.UserInvitations.Add(invitation);db.AuditEvents.Add(new AuditEvent("Create invitation",nameof(UserInvitation),invitation.Id.ToString(),actor,$"Created invitation for {email} as {role}.",source:"Users and permissions"));await db.SaveChangesAsync(cancellationToken);
        return new InvitationResult(invitation.Id,invitation.Email,role,token,expires);
    }

    public async Task<IReadOnlyList<InvitationListItem>> GetInvitationsAsync(CancellationToken cancellationToken=default)
    { await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);var rows=await db.UserInvitations.AsNoTracking().OrderByDescending(x=>x.CreatedUtc).ToListAsync(cancellationToken);return rows.Select(x=>new InvitationListItem(x.Id,x.Email,x.IntendedRole,x.ExpiresUtc,x.AcceptedUtc,x.RevokedUtc,x.IsOpen)).ToList(); }

    public async Task<CollaborationDashboardSummary> GetCollaborationSummaryAsync(CancellationToken cancellationToken=default)
    { await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);return new CollaborationDashboardSummary(await db.FamilyUsers.CountAsync(cancellationToken),await db.UserInvitations.CountAsync(x=>!x.AcceptedUtc.HasValue&&!x.RevokedUtc.HasValue&&x.ExpiresUtc>DateTimeOffset.UtcNow,cancellationToken),await db.FamilySubmissions.CountAsync(x=>x.Status==FamilySubmissionStatus.Pending,cancellationToken),await db.FamilySubmissions.CountAsync(x=>x.Status==FamilySubmissionStatus.NeedsClarification,cancellationToken),await db.FamilySubmissions.CountAsync(x=>x.Status==FamilySubmissionStatus.Approved,cancellationToken)); }

    public static string HashToken(string token)=>Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token))).ToLowerInvariant();

    private static void ValidatePassword(string password)
    { if(string.IsNullOrWhiteSpace(password)||password.Length<12)throw new InvalidOperationException("Passwords must be at least 12 characters long."); }

    private static string HashPassword(string password)
    {
        const int iterations=210000;var salt=RandomNumberGenerator.GetBytes(16);var hash=Rfc2898DeriveBytes.Pbkdf2(password,salt,iterations,HashAlgorithmName.SHA256,32);
        return $"{iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    private static bool VerifyPassword(string password,string encoded)
    {
        try{var parts=encoded.Split('.');if(parts.Length!=3||!int.TryParse(parts[0],out var iterations))return false;var salt=Convert.FromBase64String(parts[1]);var expected=Convert.FromBase64String(parts[2]);var actual=Rfc2898DeriveBytes.Pbkdf2(password,salt,iterations,HashAlgorithmName.SHA256,expected.Length);return CryptographicOperations.FixedTimeEquals(actual,expected);}catch{return false;}
    }
}
