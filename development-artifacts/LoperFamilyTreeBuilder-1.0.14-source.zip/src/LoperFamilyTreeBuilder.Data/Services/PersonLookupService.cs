using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class PersonLookupService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<IReadOnlyList<PersonLookupItem>> SearchAsync(
        string searchText,
        Guid excludePersonId,
        CancellationToken cancellationToken = default)
    {
        var search = (searchText ?? string.Empty).Trim();

        if (search.Length < 2)
            return [];

        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        var rows = await db.People
            .AsNoTracking()
            .Where(person =>
                person.Id != excludePersonId &&
                (person.GivenName.Contains(search) ||
                 person.MiddleName.Contains(search) ||
                 person.Surname.Contains(search) ||
                 person.Identifiers.Any(identifier =>
                     identifier.Value.Contains(search))))
            .OrderBy(person => person.Surname)
            .ThenBy(person => person.GivenName)
            .Take(30)
            .Select(person => new
            {
                person.Id,
                person.GivenName,
                person.MiddleName,
                person.Surname,
                person.Suffix,
                person.BirthDate,
                person.DeathDate,
                LegacyNumber = person.Identifiers
                    .Where(identifier =>
                        identifier.IdentifierType ==
                            PersonIdentifierType.LegacyNumber)
                    .Select(identifier => identifier.Value)
                    .FirstOrDefault(),
                Branch = person.BranchMemberships
                    .OrderByDescending(membership => membership.IsPrimary)
                    .Select(membership => membership.FamilyBranch.Name)
                    .FirstOrDefault()
            })
            .ToListAsync(cancellationToken);

        return rows
            .Select(row => new PersonLookupItem(
                row.Id,
                BuildDisplayName(
                    row.GivenName,
                    row.MiddleName,
                    row.Surname,
                    row.Suffix),
                row.BirthDate,
                row.DeathDate,
                row.LegacyNumber,
                row.Branch))
            .ToList();
    }

    private static string BuildDisplayName(
        string givenName,
        string middleName,
        string surname,
        string suffix)
    {
        return string.Join(
            " ",
            new[] { givenName, middleName, surname, suffix }
                .Where(value => !string.IsNullOrWhiteSpace(value)));
    }
}
