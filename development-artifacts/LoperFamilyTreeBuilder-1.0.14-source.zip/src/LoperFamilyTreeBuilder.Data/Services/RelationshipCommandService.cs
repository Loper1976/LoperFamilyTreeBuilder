using System.Text.Json;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class RelationshipCommandService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task AddParentChildAsync(
        AddParentChildRelationshipRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        if (request.ParentPersonId == request.ChildPersonId)
        {
            throw new InvalidOperationException(
                "A person cannot be their own parent.");
        }

        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        await EnsurePeopleExistAsync(
            db,
            request.ParentPersonId,
            request.ChildPersonId,
            cancellationToken);

        var exists = await db.ParentChildRelationships
            .AnyAsync(
                relationship =>
                    relationship.ParentPersonId == request.ParentPersonId &&
                    relationship.ChildPersonId == request.ChildPersonId,
                cancellationToken);

        if (exists)
        {
            throw new InvalidOperationException(
                "That parent/child relationship already exists.");
        }

        if (await WouldCreateAncestryCycleAsync(
            db,
            request.ParentPersonId,
            request.ChildPersonId,
            cancellationToken))
        {
            throw new InvalidOperationException(
                "That relationship would create an ancestry cycle and was not saved.");
        }

        var relationship = new ParentChildRelationship(
            request.ParentPersonId,
            request.ChildPersonId,
            request.RelationshipType);

        db.ParentChildRelationships.Add(relationship);

        db.AuditEvents.Add(
            new AuditEvent(
                action: "Create Relationship",
                entityType: nameof(ParentChildRelationship),
                entityId: relationship.Id.ToString(),
                actor: actor,
                summary:
                    $"Parent {request.ParentPersonId} -> child {request.ChildPersonId}",
                newValueJson: JsonSerializer.Serialize(request),
                reason: string.IsNullOrWhiteSpace(request.Reason)
                    ? "Family relationship entry"
                    : request.Reason.Trim(),
                source: "Person Profile - Family"));

        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task RemoveParentChildAsync(
        Guid currentPersonId,
        Guid relatedPersonId,
        bool currentPersonIsParent,
        string actor,
        string reason,
        CancellationToken cancellationToken = default)
    {
        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        var parentId = currentPersonIsParent
            ? currentPersonId
            : relatedPersonId;

        var childId = currentPersonIsParent
            ? relatedPersonId
            : currentPersonId;

        var relationship = await db.ParentChildRelationships
            .SingleOrDefaultAsync(
                item =>
                    item.ParentPersonId == parentId &&
                    item.ChildPersonId == childId,
                cancellationToken)
            ?? throw new InvalidOperationException(
                "The relationship could not be found.");

        db.ParentChildRelationships.Remove(relationship);

        db.AuditEvents.Add(
            new AuditEvent(
                action: "Remove Relationship",
                entityType: nameof(ParentChildRelationship),
                entityId: relationship.Id.ToString(),
                actor: actor,
                summary: $"Removed parent {parentId} -> child {childId}",
                previousValueJson: JsonSerializer.Serialize(new
                {
                    relationship.Id,
                    relationship.ParentPersonId,
                    relationship.ChildPersonId,
                    relationship.RelationshipType
                }),
                reason: string.IsNullOrWhiteSpace(reason)
                    ? "Family relationship correction"
                    : reason.Trim(),
                source: "Person Profile - Family"));

        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task AddOrUpdateCoupleAsync(
        AddCoupleRelationshipRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        if (request.FirstPersonId == request.SecondPersonId)
        {
            throw new InvalidOperationException(
                "A person cannot be connected to themselves as a spouse or partner.");
        }

        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        await EnsurePeopleExistAsync(
            db,
            request.FirstPersonId,
            request.SecondPersonId,
            cancellationToken);

        var a = request.FirstPersonId.CompareTo(request.SecondPersonId) < 0
            ? request.FirstPersonId
            : request.SecondPersonId;

        var b = request.FirstPersonId.CompareTo(request.SecondPersonId) < 0
            ? request.SecondPersonId
            : request.FirstPersonId;

        var relationship = await db.CoupleRelationships
            .SingleOrDefaultAsync(
                item => item.PersonAId == a && item.PersonBId == b,
                cancellationToken);

        if (relationship is null)
        {
            relationship = new CoupleRelationship(
                request.FirstPersonId,
                request.SecondPersonId,
                request.RelationshipType);

            relationship.Update(
                request.RelationshipType,
                request.StartDate,
                request.EndDate,
                request.Notes.Trim());

            db.CoupleRelationships.Add(relationship);

            db.AuditEvents.Add(
                new AuditEvent(
                    action: "Create Relationship",
                    entityType: nameof(CoupleRelationship),
                    entityId: relationship.Id.ToString(),
                    actor: actor,
                    summary:
                        $"Couple relationship {request.FirstPersonId} <-> {request.SecondPersonId}",
                    newValueJson: JsonSerializer.Serialize(request),
                    reason: string.IsNullOrWhiteSpace(request.Reason)
                        ? "Family relationship entry"
                        : request.Reason.Trim(),
                    source: "Person Profile - Family"));
        }
        else
        {
            var before = JsonSerializer.Serialize(new
            {
                relationship.RelationshipType,
                relationship.StartDate,
                relationship.EndDate,
                relationship.Notes
            });

            relationship.Update(
                request.RelationshipType,
                request.StartDate,
                request.EndDate,
                request.Notes.Trim());

            db.AuditEvents.Add(
                new AuditEvent(
                    action: "Update Relationship",
                    entityType: nameof(CoupleRelationship),
                    entityId: relationship.Id.ToString(),
                    actor: actor,
                    summary:
                        $"Updated couple relationship {request.FirstPersonId} <-> {request.SecondPersonId}",
                    previousValueJson: before,
                    newValueJson: JsonSerializer.Serialize(request),
                    reason: string.IsNullOrWhiteSpace(request.Reason)
                        ? "Family relationship edit"
                        : request.Reason.Trim(),
                    source: "Person Profile - Family"));
        }

        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task RemoveCoupleAsync(
        Guid relationshipId,
        string actor,
        string reason,
        CancellationToken cancellationToken = default)
    {
        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        var relationship = await db.CoupleRelationships
            .SingleOrDefaultAsync(
                item => item.Id == relationshipId,
                cancellationToken)
            ?? throw new InvalidOperationException(
                "The spouse/partner relationship could not be found.");

        var before = JsonSerializer.Serialize(new
        {
            relationship.Id,
            relationship.PersonAId,
            relationship.PersonBId,
            relationship.RelationshipType,
            relationship.StartDate,
            relationship.EndDate,
            relationship.Notes
        });

        db.CoupleRelationships.Remove(relationship);

        db.AuditEvents.Add(
            new AuditEvent(
                action: "Remove Relationship",
                entityType: nameof(CoupleRelationship),
                entityId: relationship.Id.ToString(),
                actor: actor,
                summary:
                    $"Removed couple relationship {relationship.PersonAId} <-> {relationship.PersonBId}",
                previousValueJson: before,
                reason: string.IsNullOrWhiteSpace(reason)
                    ? "Family relationship correction"
                    : reason.Trim(),
                source: "Person Profile - Family"));

        await db.SaveChangesAsync(cancellationToken);
    }

    private static async Task EnsurePeopleExistAsync(
        FamilyTreeDbContext db,
        Guid firstPersonId,
        Guid secondPersonId,
        CancellationToken cancellationToken)
    {
        var count = await db.People
            .CountAsync(
                person =>
                    person.Id == firstPersonId ||
                    person.Id == secondPersonId,
                cancellationToken);

        if (count != 2)
        {
            throw new InvalidOperationException(
                "One or both selected people no longer exist.");
        }
    }

    private static async Task<bool> WouldCreateAncestryCycleAsync(
        FamilyTreeDbContext db,
        Guid proposedParentId,
        Guid proposedChildId,
        CancellationToken cancellationToken)
    {
        var frontier = new HashSet<Guid> { proposedParentId };
        var visited = new HashSet<Guid>();

        while (frontier.Count > 0)
        {
            var current = frontier
                .Where(id => !visited.Contains(id))
                .ToList();

            if (current.Count == 0)
                return false;

            foreach (var id in current)
                visited.Add(id);

            var ancestors = await db.ParentChildRelationships
                .AsNoTracking()
                .Where(relationship =>
                    current.Contains(relationship.ChildPersonId))
                .Select(relationship => relationship.ParentPersonId)
                .Distinct()
                .ToListAsync(cancellationToken);

            if (ancestors.Contains(proposedChildId))
                return true;

            frontier = ancestors.ToHashSet();
        }

        return false;
    }
}
