using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class PersonProfileQueryService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<PersonProfileModel?> GetAsync(
        Guid personId,
        CancellationToken cancellationToken = default)
    {
        await using var db =
            await contextFactory.CreateDbContextAsync(cancellationToken);

        var basic = await db.People
            .AsNoTracking()
            .Where(person => person.Id == personId)
            .Select(person => new
            {
                person.Id,
                person.GivenName,
                person.MiddleName,
                person.Surname,
                person.Suffix,
                person.BirthDate,
                person.DeathDate,
                person.IsLiving,
                LegacyNumber = person.Identifiers
                    .Where(identifier =>
                        identifier.IdentifierType ==
                            PersonIdentifierType.LegacyNumber)
                    .Select(identifier => identifier.Value)
                    .FirstOrDefault()
            })
            .SingleOrDefaultAsync(cancellationToken);

        if (basic is null)
            return null;

        var branches = await db.BranchMemberships
            .AsNoTracking()
            .Where(membership => membership.PersonId == personId)
            .OrderByDescending(membership => membership.IsPrimary)
            .ThenBy(membership => membership.FamilyBranch.Name)
            .Select(membership => new FamilyBranchListItem(
                membership.FamilyBranch.Id,
                membership.FamilyBranch.Name,
                membership.FamilyBranch.ShortCode))
            .ToListAsync(cancellationToken);

        var parentRows = await db.ParentChildRelationships
            .AsNoTracking()
            .Where(relationship => relationship.ChildPersonId == personId)
            .OrderBy(relationship => relationship.ParentPerson.Surname)
            .ThenBy(relationship => relationship.ParentPerson.GivenName)
            .Select(relationship => new
            {
                relationship.ParentPersonId,
                relationship.RelationshipType,
                relationship.ParentPerson.GivenName,
                relationship.ParentPerson.MiddleName,
                relationship.ParentPerson.Surname,
                relationship.ParentPerson.Suffix,
                relationship.ParentPerson.BirthDate,
                relationship.ParentPerson.DeathDate,
                LegacyNumber = relationship.ParentPerson.Identifiers
                    .Where(identifier =>
                        identifier.IdentifierType ==
                            PersonIdentifierType.LegacyNumber)
                    .Select(identifier => identifier.Value)
                    .FirstOrDefault()
            })
            .ToListAsync(cancellationToken);

        var parents = parentRows
            .Select(row => new PersonRelationshipListItem(
                row.ParentPersonId,
                BuildDisplayName(
                    row.GivenName,
                    row.MiddleName,
                    row.Surname,
                    row.Suffix),
                row.BirthDate,
                row.DeathDate,
                row.LegacyNumber,
                row.RelationshipType))
            .ToList();

        var childRows = await db.ParentChildRelationships
            .AsNoTracking()
            .Where(relationship => relationship.ParentPersonId == personId)
            .OrderBy(relationship => relationship.ChildPerson.BirthDate)
            .ThenBy(relationship => relationship.ChildPerson.Surname)
            .ThenBy(relationship => relationship.ChildPerson.GivenName)
            .Select(relationship => new
            {
                relationship.ChildPersonId,
                relationship.RelationshipType,
                relationship.ChildPerson.GivenName,
                relationship.ChildPerson.MiddleName,
                relationship.ChildPerson.Surname,
                relationship.ChildPerson.Suffix,
                relationship.ChildPerson.BirthDate,
                relationship.ChildPerson.DeathDate,
                LegacyNumber = relationship.ChildPerson.Identifiers
                    .Where(identifier =>
                        identifier.IdentifierType ==
                            PersonIdentifierType.LegacyNumber)
                    .Select(identifier => identifier.Value)
                    .FirstOrDefault()
            })
            .ToListAsync(cancellationToken);

        var children = childRows
            .Select(row => new PersonRelationshipListItem(
                row.ChildPersonId,
                BuildDisplayName(
                    row.GivenName,
                    row.MiddleName,
                    row.Surname,
                    row.Suffix),
                row.BirthDate,
                row.DeathDate,
                row.LegacyNumber,
                row.RelationshipType))
            .ToList();

        var parentIds = parents.Select(parent => parent.PersonId).ToList();
        var siblings = new List<PersonRelationshipListItem>();

        if (parentIds.Count > 0)
        {
            var siblingRows = await db.ParentChildRelationships
                .AsNoTracking()
                .Where(relationship =>
                    parentIds.Contains(relationship.ParentPersonId) &&
                    relationship.ChildPersonId != personId)
                .Select(relationship => new
                {
                    relationship.ChildPersonId,
                    relationship.RelationshipType,
                    relationship.ChildPerson.GivenName,
                    relationship.ChildPerson.MiddleName,
                    relationship.ChildPerson.Surname,
                    relationship.ChildPerson.Suffix,
                    relationship.ChildPerson.BirthDate,
                    relationship.ChildPerson.DeathDate,
                    LegacyNumber = relationship.ChildPerson.Identifiers
                        .Where(identifier =>
                            identifier.IdentifierType ==
                                PersonIdentifierType.LegacyNumber)
                        .Select(identifier => identifier.Value)
                        .FirstOrDefault()
                })
                .ToListAsync(cancellationToken);

            siblings = siblingRows
                .GroupBy(row => row.ChildPersonId)
                .Select(group => group.First())
                .Select(row => new PersonRelationshipListItem(
                    row.ChildPersonId,
                    BuildDisplayName(
                        row.GivenName,
                        row.MiddleName,
                        row.Surname,
                        row.Suffix),
                    row.BirthDate,
                    row.DeathDate,
                    row.LegacyNumber,
                    row.RelationshipType))
                .OrderBy(sibling => sibling.BirthDate)
                .ThenBy(sibling => sibling.DisplayName)
                .ToList();
        }

        var coupleRows = await db.CoupleRelationships
            .AsNoTracking()
            .Where(relationship =>
                relationship.PersonAId == personId ||
                relationship.PersonBId == personId)
            .Select(relationship => new
            {
                relationship.Id,
                relationship.PersonAId,
                relationship.PersonBId,
                relationship.RelationshipType,
                relationship.StartDate,
                relationship.EndDate,
                relationship.Notes,
                AId = relationship.PersonA.Id,
                AGivenName = relationship.PersonA.GivenName,
                AMiddleName = relationship.PersonA.MiddleName,
                ASurname = relationship.PersonA.Surname,
                ASuffix = relationship.PersonA.Suffix,
                ABirthDate = relationship.PersonA.BirthDate,
                ADeathDate = relationship.PersonA.DeathDate,
                ALegacy = relationship.PersonA.Identifiers
                    .Where(identifier =>
                        identifier.IdentifierType ==
                            PersonIdentifierType.LegacyNumber)
                    .Select(identifier => identifier.Value)
                    .FirstOrDefault(),
                BId = relationship.PersonB.Id,
                BGivenName = relationship.PersonB.GivenName,
                BMiddleName = relationship.PersonB.MiddleName,
                BSurname = relationship.PersonB.Surname,
                BSuffix = relationship.PersonB.Suffix,
                BBirthDate = relationship.PersonB.BirthDate,
                BDeathDate = relationship.PersonB.DeathDate,
                BLegacy = relationship.PersonB.Identifiers
                    .Where(identifier =>
                        identifier.IdentifierType ==
                            PersonIdentifierType.LegacyNumber)
                    .Select(identifier => identifier.Value)
                    .FirstOrDefault()
            })
            .ToListAsync(cancellationToken);

        var couples = coupleRows
            .Select(row =>
            {
                var useB = row.PersonAId == personId;

                return new CoupleRelationshipListItem(
                    row.Id,
                    useB ? row.BId : row.AId,
                    BuildDisplayName(
                        useB ? row.BGivenName : row.AGivenName,
                        useB ? row.BMiddleName : row.AMiddleName,
                        useB ? row.BSurname : row.ASurname,
                        useB ? row.BSuffix : row.ASuffix),
                    useB ? row.BBirthDate : row.ABirthDate,
                    useB ? row.BDeathDate : row.ADeathDate,
                    useB ? row.BLegacy : row.ALegacy,
                    row.RelationshipType,
                    row.StartDate,
                    row.EndDate,
                    row.Notes);
            })
            .OrderBy(couple => couple.DisplayName)
            .ToList();

        var auditHistory = await db.AuditEvents
            .AsNoTracking()
            .Where(audit =>
                audit.EntityId == personId.ToString() ||
                audit.Summary.Contains(personId.ToString()))
            .OrderByDescending(audit => audit.OccurredUtc)
            .Take(100)
            .Select(audit => new AuditHistoryItem(
                audit.Id,
                audit.OccurredUtc,
                audit.Action,
                audit.Actor,
                audit.Summary,
                audit.Reason,
                audit.Source))
            .ToListAsync(cancellationToken);

        var orderedRows = await db.People
            .AsNoTracking()
            .OrderBy(person => person.Surname)
            .ThenBy(person => person.GivenName)
            .ThenBy(person => person.MiddleName)
            .Select(person => new
            {
                person.Id,
                person.GivenName,
                person.MiddleName,
                person.Surname,
                person.Suffix
            })
            .ToListAsync(cancellationToken);

        var orderedPeople = orderedRows
            .Select(row => new AdjacentPerson(
                row.Id,
                BuildDisplayName(
                    row.GivenName,
                    row.MiddleName,
                    row.Surname,
                    row.Suffix)))
            .ToList();

        var index = orderedPeople.FindIndex(person => person.Id == personId);

        AdjacentPerson? previous = index > 0
            ? orderedPeople[index - 1]
            : null;

        AdjacentPerson? next = index >= 0 && index < orderedPeople.Count - 1
            ? orderedPeople[index + 1]
            : null;

        return new PersonProfileModel(
            basic.Id,
            basic.GivenName,
            basic.MiddleName,
            basic.Surname,
            basic.Suffix,
            basic.BirthDate,
            basic.DeathDate,
            basic.IsLiving,
            basic.LegacyNumber,
            branches,
            parents,
            children,
            siblings,
            couples,
            auditHistory,
            previous,
            next);
    }

    private static string BuildDisplayName(
        string givenName,
        string middleName,
        string surname,
        string suffix)
    {
        return string.Join(
            " ",
            new[] { givenName, middleName, surname, suffix }
                .Where(value => !string.IsNullOrWhiteSpace(value)));
    }
}
