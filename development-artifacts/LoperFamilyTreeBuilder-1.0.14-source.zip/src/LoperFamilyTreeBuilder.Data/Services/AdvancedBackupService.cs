using System.Security.Cryptography;
using System.Text.Json;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using LoperFamilyTreeBuilder.Infrastructure.Configuration;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class AdvancedBackupService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory,
    ArchiveConfigurationStore configurationStore,
    ApplicationPaths applicationPaths)
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true };

    public async Task<BackupCatalogItem> CreateBackupAsync(
        BackupReason reason,
        bool includeArchiveFiles,
        string actor,
        CancellationToken cancellationToken = default)
    {
        var configuration = await configurationStore.LoadAsync(cancellationToken)
            ?? throw new InvalidOperationException("Backup storage has not been configured.");

        if (!configuration.IsComplete)
            throw new InvalidOperationException("Primary archive and backup paths are required.");

        var stamp = DateTime.UtcNow.ToString("yyyyMMdd-HHmmss");
        var directory = Path.Combine(
            configuration.BackupPath,
            "ManagedBackups",
            DateTime.UtcNow.ToString("yyyy"),
            DateTime.UtcNow.ToString("MM"),
            $"{stamp}-{reason}");

        Directory.CreateDirectory(directory);

        var databasePath = Path.Combine(directory, "LoperFamilyTreeBuilder.bak");
        var escapedDatabasePath = databasePath.Replace("'", "''", StringComparison.Ordinal);

        await using (var db = await contextFactory.CreateDbContextAsync(cancellationToken))
        {
            await db.Database.ExecuteSqlRawAsync(
                $"BACKUP DATABASE [LoperFamilyTreeBuilder] TO DISK = N'{escapedDatabasePath}' WITH COPY_ONLY, INIT, CHECKSUM",
                cancellationToken);
        }

        var manifest = new BackupManifest
        {
            ApplicationVersion = typeof(AdvancedBackupService).Assembly.GetName().Version?.ToString() ?? string.Empty,
            Reason = reason,
            CreatedUtc = DateTimeOffset.UtcNow,
            DatabaseBackupFile = "LoperFamilyTreeBuilder.bak",
            IncludesArchiveFiles = includeArchiveFiles
        };

        manifest.Entries.Add(await CreateEntryAsync(directory, databasePath, "Database", cancellationToken));

        if (File.Exists(applicationPaths.ConfigurationFile))
        {
            var configDestination = Path.Combine(directory, "archive-settings.json");
            File.Copy(applicationPaths.ConfigurationFile, configDestination, overwrite: true);
            manifest.ConfigurationFile = "archive-settings.json";
            manifest.Entries.Add(await CreateEntryAsync(directory, configDestination, "Configuration", cancellationToken));
        }

        if (includeArchiveFiles)
        {
            var archiveRoot = Path.GetFullPath(configuration.PrimaryArchivePath)
                .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

            if (Directory.Exists(archiveRoot))
            {
                foreach (var source in Directory.EnumerateFiles(archiveRoot, "*", SearchOption.AllDirectories))
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    var relative = Path.GetRelativePath(archiveRoot, source);
                    var destination = Path.Combine(directory, "Archive", relative);
                    Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
                    await CopyFileAsync(source, destination, cancellationToken);
                    manifest.Entries.Add(await CreateEntryAsync(directory, destination, "Archive", cancellationToken));
                }
            }
        }

        var manifestPath = Path.Combine(directory, "backup-manifest.json");
        await File.WriteAllTextAsync(
            manifestPath,
            JsonSerializer.Serialize(manifest, JsonOptions),
            cancellationToken);

        await using (var db = await contextFactory.CreateDbContextAsync(cancellationToken))
        {
            db.AuditEvents.Add(new AuditEvent(
                "Backup Created",
                "Backup",
                directory,
                actor,
                $"Created {reason} backup with {manifest.Entries.Count} verified manifest entries.",
                source: "Advanced backup"));
            await db.SaveChangesAsync(cancellationToken);
        }

        return ToCatalog(directory, manifest);
    }

    public async Task<IReadOnlyList<BackupCatalogItem>> GetBackupsAsync(
        CancellationToken cancellationToken = default)
    {
        var configuration = await configurationStore.LoadAsync(cancellationToken);
        if (configuration is null || !configuration.IsComplete)
            return [];

        var root = Path.Combine(configuration.BackupPath, "ManagedBackups");
        if (!Directory.Exists(root))
            return [];

        var results = new List<BackupCatalogItem>();
        foreach (var manifestPath in Directory.EnumerateFiles(root, "backup-manifest.json", SearchOption.AllDirectories)
                     .OrderByDescending(x => x, StringComparer.OrdinalIgnoreCase)
                     .Take(250))
        {
            try
            {
                var manifest = JsonSerializer.Deserialize<BackupManifest>(
                    await File.ReadAllTextAsync(manifestPath, cancellationToken),
                    JsonOptions);
                if (manifest is not null)
                    results.Add(ToCatalog(Path.GetDirectoryName(manifestPath)!, manifest));
            }
            catch
            {
                results.Add(new BackupCatalogItem(
                    Path.GetDirectoryName(manifestPath)!,
                    BackupReason.Manual,
                    File.GetLastWriteTimeUtc(manifestPath),
                    false,
                    0,
                    0,
                    false));
            }
        }

        return results.OrderByDescending(x => x.CreatedUtc).ToList();
    }

    public async Task<BackupVerificationResult> VerifyBackupAsync(
        string backupDirectory,
        CancellationToken cancellationToken = default)
    {
        var manifestPath = Path.Combine(backupDirectory, "backup-manifest.json");
        if (!File.Exists(manifestPath))
            return new BackupVerificationResult(false, 0, 1, 0, "Backup manifest is missing.");

        var manifest = JsonSerializer.Deserialize<BackupManifest>(
            await File.ReadAllTextAsync(manifestPath, cancellationToken),
            JsonOptions);

        if (manifest is null)
            return new BackupVerificationResult(false, 0, 1, 0, "Backup manifest could not be read.");

        var checkedFiles = 0;
        var missing = 0;
        var mismatches = 0;

        foreach (var entry in manifest.Entries)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var path = Path.Combine(backupDirectory, entry.RelativePath);
            if (!File.Exists(path))
            {
                missing++;
                continue;
            }

            checkedFiles++;
            var hash = await ComputeSha256Async(path, cancellationToken);
            if (!string.Equals(hash, entry.Sha256, StringComparison.OrdinalIgnoreCase))
                mismatches++;
        }

        var valid = missing == 0 && mismatches == 0 && checkedFiles == manifest.Entries.Count;
        return new BackupVerificationResult(
            valid,
            checkedFiles,
            missing,
            mismatches,
            valid
                ? $"Backup verified. {checkedFiles} files match the manifest."
                : $"Backup verification failed. Missing: {missing}; hash mismatches: {mismatches}.");
    }

    public async Task StageRestoreAsync(
        string backupDirectory,
        string actor,
        CancellationToken cancellationToken = default)
    {
        var verification = await VerifyBackupAsync(backupDirectory, cancellationToken);
        if (!verification.IsValid)
            throw new InvalidOperationException("The selected backup failed verification and cannot be staged for restore.");

        var manifestPath = Path.Combine(backupDirectory, "backup-manifest.json");
        var manifest = JsonSerializer.Deserialize<BackupManifest>(
            await File.ReadAllTextAsync(manifestPath, cancellationToken),
            JsonOptions) ?? throw new InvalidOperationException("Backup manifest could not be read.");

        var request = new PendingRestoreRequest
        {
            BackupDirectory = backupDirectory,
            DatabaseBackupFile = Path.Combine(backupDirectory, manifest.DatabaseBackupFile),
            ConfigurationFile = string.IsNullOrWhiteSpace(manifest.ConfigurationFile)
                ? string.Empty
                : Path.Combine(backupDirectory, manifest.ConfigurationFile),
            RequestedUtc = DateTimeOffset.UtcNow
        };

        applicationPaths.EnsureLocalDirectories();
        await File.WriteAllTextAsync(
            applicationPaths.PendingRestoreRequestFile,
            JsonSerializer.Serialize(request, JsonOptions),
            cancellationToken);

        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        db.AuditEvents.Add(new AuditEvent(
            "Restore Staged",
            "Backup",
            backupDirectory,
            actor,
            "A verified database restore was staged for the next application launch.",
            source: "Advanced backup"));
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task<int> PruneExpiredBackupsAsync(
        int retentionDays,
        string actor,
        CancellationToken cancellationToken = default)
    {
        retentionDays = Math.Clamp(retentionDays, 7, 3650);
        var cutoff = DateTimeOffset.UtcNow.AddDays(-retentionDays);
        var backups = await GetBackupsAsync(cancellationToken);
        var removed = 0;

        foreach (var backup in backups.Where(x => x.CreatedUtc < cutoff))
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (Directory.Exists(backup.BackupDirectory))
            {
                Directory.Delete(backup.BackupDirectory, recursive: true);
                removed++;
            }
        }

        if (removed > 0)
        {
            await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
            db.AuditEvents.Add(new AuditEvent(
                "Backup Retention",
                "Backup",
                "ManagedBackups",
                actor,
                $"Removed {removed} backups older than {retentionDays} days.",
                source: "Backup retention"));
            await db.SaveChangesAsync(cancellationToken);
        }

        return removed;
    }

    public async Task EnsureScheduledBackupAsync(CancellationToken cancellationToken = default)
    {
        var configuration = await configurationStore.LoadAsync(cancellationToken);
        if (configuration is null || !configuration.IsComplete || !configuration.AutomaticBackupsEnabled)
            return;

        var backups = await GetBackupsAsync(cancellationToken);
        var latest = backups.OrderByDescending(x => x.CreatedUtc).FirstOrDefault();
        var now = DateTimeOffset.UtcNow;

        if (latest is null || now - latest.CreatedUtc >= TimeSpan.FromDays(30))
        {
            await CreateBackupAsync(BackupReason.Monthly, true, "Automatic Backup", cancellationToken);
            return;
        }

        if (now - latest.CreatedUtc >= TimeSpan.FromDays(7))
        {
            await CreateBackupAsync(BackupReason.Weekly, true, "Automatic Backup", cancellationToken);
            return;
        }

        if (now - latest.CreatedUtc >= TimeSpan.FromHours(24))
            await CreateBackupAsync(BackupReason.Daily, false, "Automatic Backup", cancellationToken);
    }

    private static BackupCatalogItem ToCatalog(string directory, BackupManifest manifest) =>
        new(
            directory,
            manifest.Reason,
            manifest.CreatedUtc,
            manifest.IncludesArchiveFiles,
            manifest.Entries.Count,
            manifest.Entries.Sum(x => x.SizeBytes),
            true);

    private static async Task<BackupManifestEntry> CreateEntryAsync(
        string root,
        string path,
        string category,
        CancellationToken cancellationToken) =>
        new(
            Path.GetRelativePath(root, path),
            category,
            new FileInfo(path).Length,
            await ComputeSha256Async(path, cancellationToken));

    private static async Task<string> ComputeSha256Async(
        string path,
        CancellationToken cancellationToken)
    {
        await using var stream = new FileStream(
            path,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            1024 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan);

        var hash = await SHA256.HashDataAsync(stream, cancellationToken);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static async Task CopyFileAsync(
        string source,
        string destination,
        CancellationToken cancellationToken)
    {
        await using var input = new FileStream(
            source,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            1024 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
        await using var output = new FileStream(
            destination,
            FileMode.Create,
            FileAccess.Write,
            FileShare.None,
            1024 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
        await input.CopyToAsync(output, cancellationToken);
    }
}
