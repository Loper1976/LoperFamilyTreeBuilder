using System.Security.Cryptography;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using LoperFamilyTreeBuilder.Infrastructure.Configuration;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class FamilyCollaborationService(IDbContextFactory<FamilyTreeDbContext> contextFactory, ArchiveConfigurationStore configurationStore)
{
    public async Task<Guid> CreateSubmissionAsync(CreateFamilySubmissionRequest request, Stream? fileStream, string? originalFileName, CancellationToken cancellationToken=default)
    {
        if(!request.RightsAndPrivacyAccepted)throw new InvalidOperationException("The contributor rights and privacy statement must be accepted before submission.");
        var entity=new FamilySubmission(request.SubmittedByUserId,request.SubmissionType,request.Subject,request.Details);entity.SetTargetPerson(request.TargetPersonId);entity.SetRightsAccepted(true);
        if(fileStream is not null&&!string.IsNullOrWhiteSpace(originalFileName))
        {
            var configuration=await configurationStore.LoadAsync(cancellationToken)??throw new InvalidOperationException("Family archive storage is not configured.");
            var safeName=Path.GetFileName(originalFileName);var relative=Path.Combine("Submissions","Pending",entity.Id.ToString("N"),safeName);var full=Path.Combine(configuration.PrimaryArchivePath,relative);Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            await using(var output=File.Create(full)){using var sha=SHA256.Create();var buffer=new byte[81920];long total=0;int read;while((read=await fileStream.ReadAsync(buffer.AsMemory(0,buffer.Length),cancellationToken))>0){await output.WriteAsync(buffer.AsMemory(0,read),cancellationToken);sha.TransformBlock(buffer,0,read,null,0);total+=read;}sha.TransformFinalBlock([],0,0);entity.AttachFile(safeName,relative,Convert.ToHexString(sha.Hash!).ToLowerInvariant(),total);}
        }
        await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);db.FamilySubmissions.Add(entity);db.AuditEvents.Add(new AuditEvent("Create family submission",nameof(FamilySubmission),entity.Id.ToString(),request.SubmittedByUserId.ToString(),$"Submitted {request.SubmissionType}: {request.Subject}.",source:"Family upload portal"));await db.SaveChangesAsync(cancellationToken);return entity.Id;
    }

    public async Task<IReadOnlyList<FamilySubmissionListItem>> GetSubmissionsAsync(CancellationToken cancellationToken=default)
    {
        await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);var rows=await db.FamilySubmissions.AsNoTracking().OrderBy(x=>x.Status).ThenByDescending(x=>x.SubmittedUtc).Select(x=>new{x.Id,x.SubmittedByUserId,SubmitterName=x.SubmittedByUser.DisplayName,x.TargetPersonId,TargetPersonName=x.TargetPerson==null?null:(x.TargetPerson.GivenName+" "+x.TargetPerson.MiddleName+" "+x.TargetPerson.Surname+" "+x.TargetPerson.Suffix),x.SubmissionType,x.Subject,x.Details,x.OriginalFileName,x.Sha256,x.FileSizeBytes,x.RightsAndPrivacyAccepted,x.Status,x.ReviewNotes,x.SubmittedUtc,x.ReviewedUtc}).ToListAsync(cancellationToken);
        return rows.Select(x=>new FamilySubmissionListItem(x.Id,x.SubmittedByUserId,x.SubmitterName,x.TargetPersonId,x.TargetPersonName?.Replace("  "," ").Trim(),x.SubmissionType,x.Subject,x.Details,x.OriginalFileName,x.Sha256,x.FileSizeBytes,x.RightsAndPrivacyAccepted,x.Status,x.ReviewNotes,x.SubmittedUtc,x.ReviewedUtc)).ToList();
    }

    public async Task ReviewAsync(Guid submissionId,FamilySubmissionStatus status,Guid reviewerId,string notes,CancellationToken cancellationToken=default)
    {
        await using var db=await contextFactory.CreateDbContextAsync(cancellationToken);var entity=await db.FamilySubmissions.SingleOrDefaultAsync(x=>x.Id==submissionId,cancellationToken)??throw new InvalidOperationException("Submission not found.");entity.Review(status,reviewerId,notes);db.AuditEvents.Add(new AuditEvent("Review family submission",nameof(FamilySubmission),entity.Id.ToString(),reviewerId.ToString(),$"Submission status changed to {status}.",reason:notes,source:"Submission review queue"));await db.SaveChangesAsync(cancellationToken);
    }
}
