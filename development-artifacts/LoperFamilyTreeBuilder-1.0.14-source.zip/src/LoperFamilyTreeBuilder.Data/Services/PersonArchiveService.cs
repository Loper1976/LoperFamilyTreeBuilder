using System.Text.Json;
using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using LoperFamilyTreeBuilder.Infrastructure.Storage;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class PersonArchiveService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory,
    ArchiveMediaStorageService storageService)
{
    public async Task<IReadOnlyList<ArchiveMediaListItem>> GetMediaAsync(
        Guid personId,
        ArchiveMediaType? mediaType = null,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var query = db.PersonMediaLinks.AsNoTracking().Where(link => link.PersonId == personId);
        if (mediaType.HasValue)
            query = query.Where(link => link.MediaFile.MediaType == mediaType.Value);

        return await query
            .OrderByDescending(link => link.MediaFile.CaptureDateTime)
            .ThenByDescending(link => link.MediaFile.CreatedUtc)
            .Select(link => new ArchiveMediaListItem(
                link.MediaFile.Id,
                link.MediaFile.MediaType,
                link.Role,
                link.MediaFile.OriginalFileName,
                link.MediaFile.Caption,
                link.MediaFile.MimeType,
                link.MediaFile.FileSizeBytes,
                link.MediaFile.Sha256,
                link.MediaFile.CaptureDateTime,
                link.MediaFile.CaptureDateIsApproximate,
                link.MediaFile.DeviceOrCamera,
                link.MediaFile.Latitude,
                link.MediaFile.Longitude,
                link.MediaFile.Photographer,
                link.MediaFile.Owner,
                link.MediaFile.Rights,
                link.MediaFile.DocumentType,
                link.MediaFile.CreatedUtc,
                db.DocumentTranscriptions.Any(t => t.MediaFileId == link.MediaFile.Id)))
            .ToListAsync(cancellationToken);
    }

    public async Task<Guid> UploadAsync(
        MediaUploadRequest request,
        Stream fileStream,
        string actor,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        if (request.PersonId == Guid.Empty)
            throw new InvalidOperationException("A person is required before a file can be linked.");

        var folder = request.MediaType == ArchiveMediaType.Photo ? "Photos" :
            request.MediaType == ArchiveMediaType.Document ? "Documents" : "Other";

        var stored = await storageService.StoreOriginalAsync(
            fileStream,
            request.OriginalFileName,
            folder,
            cancellationToken);

        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        if (!await db.People.AnyAsync(p => p.Id == request.PersonId, cancellationToken))
        {
            ArchiveMediaStorageService.DeleteIfExists(stored.FullPath);
            throw new InvalidOperationException("The selected person no longer exists.");
        }

        var existing = await db.ArchiveMediaFiles
            .SingleOrDefaultAsync(x => x.Sha256 == stored.Sha256, cancellationToken);

        ArchiveMediaFile media;
        if (existing is not null)
        {
            ArchiveMediaStorageService.DeleteIfExists(stored.FullPath);
            media = existing;
        }
        else
        {
            media = new ArchiveMediaFile(
                request.MediaType,
                request.OriginalFileName,
                stored.StoredRelativePath,
                request.MimeType,
                stored.FileSizeBytes,
                stored.Sha256);

            media.SetDescriptiveMetadata(
                request.Caption,
                request.CaptureDateTime,
                request.CaptureDateIsApproximate,
                request.DeviceOrCamera,
                request.Orientation,
                request.Latitude,
                request.Longitude,
                request.MetadataSource,
                request.Photographer,
                request.Owner,
                request.Rights,
                request.DocumentType);

            db.ArchiveMediaFiles.Add(media);
        }

        var alreadyLinked = await db.PersonMediaLinks.AnyAsync(
            link => link.PersonId == request.PersonId && link.MediaFileId == media.Id,
            cancellationToken);
        if (!alreadyLinked)
            db.PersonMediaLinks.Add(new PersonMediaLink(request.PersonId, media.Id, request.Role, request.Notes));

        db.AuditEvents.Add(new AuditEvent(
            "ArchiveFileLinked",
            nameof(ArchiveMediaFile),
            media.Id.ToString(),
            actor,
            $"Linked original {request.MediaType.ToString().ToLowerInvariant()} '{request.OriginalFileName}' to person.",
            newValueJson: JsonSerializer.Serialize(new { media.Id, media.Sha256, request.PersonId, request.Role }),
            source: "Person Profile Archive"));

        await db.SaveChangesAsync(cancellationToken);
        return media.Id;
    }

    public async Task<IReadOnlyList<SourceRecordListItem>> GetAllSourcesAsync(
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        return await db.SourceRecords.AsNoTracking()
            .OrderBy(x => x.Title)
            .Select(x => new SourceRecordListItem(
                x.Id, x.Title, x.Repository, x.CallNumber, x.Url, x.AccessDate,
                x.Classification, x.EvidenceQuality, x.Confidence, x.Notes,
                x.OriginalDocumentMediaFileId))
            .ToListAsync(cancellationToken);
    }

    public async Task<Guid> CreateSourceAsync(
        CreateSourceRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        var source = new SourceRecord(request.Title, request.Classification);
        source.SetDetails(request.Repository, request.CallNumber, request.Url,
            request.AccessDate, request.EvidenceQuality, request.Confidence,
            request.Notes, request.OriginalDocumentMediaFileId);

        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        db.SourceRecords.Add(source);
        db.AuditEvents.Add(new AuditEvent(
            "SourceCreated", nameof(SourceRecord), source.Id.ToString(), actor,
            $"Created source: {source.Title}",
            newValueJson: JsonSerializer.Serialize(request),
            source: "Sources"));
        await db.SaveChangesAsync(cancellationToken);
        return source.Id;
    }

    public async Task<IReadOnlyList<CitationListItem>> GetCitationsAsync(
        Guid personId,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        return await db.CitationRecords.AsNoTracking()
            .Where(x => x.PersonId == personId)
            .OrderBy(x => x.FactOrSubject)
            .ThenBy(x => x.SourceRecord.Title)
            .Select(x => new CitationListItem(
                x.Id, x.SourceRecordId, x.SourceRecord.Title, x.SourceRecord.Repository,
                x.FactOrSubject, x.Position, x.PageOrCallNumber, x.CitationText,
                x.Notes, x.MediaFileId, x.CreatedUtc))
            .ToListAsync(cancellationToken);
    }

    public async Task<Guid> AddCitationAsync(
        CreateCitationRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        if (!await db.People.AnyAsync(x => x.Id == request.PersonId, cancellationToken))
            throw new InvalidOperationException("The person no longer exists.");
        if (!await db.SourceRecords.AnyAsync(x => x.Id == request.SourceRecordId, cancellationToken))
            throw new InvalidOperationException("The selected source no longer exists.");

        var citation = new CitationRecord(
            request.PersonId, request.SourceRecordId, request.FactOrSubject, request.Position);
        citation.SetDetails(request.MediaFileId, request.PageOrCallNumber, request.CitationText, request.Notes);
        db.CitationRecords.Add(citation);
        db.AuditEvents.Add(new AuditEvent(
            "CitationAdded", nameof(CitationRecord), citation.Id.ToString(), actor,
            $"Added {request.Position.ToString().ToLowerInvariant()} citation for '{citation.FactOrSubject}'.",
            newValueJson: JsonSerializer.Serialize(request),
            source: "Person Profile Sources"));
        await db.SaveChangesAsync(cancellationToken);
        return citation.Id;
    }

    public async Task<DocumentTranscriptionModel?> GetTranscriptionAsync(
        Guid mediaFileId,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var media = await db.ArchiveMediaFiles.AsNoTracking()
            .SingleOrDefaultAsync(x => x.Id == mediaFileId && x.MediaType == ArchiveMediaType.Document, cancellationToken);
        if (media is null) return null;

        var tx = await db.DocumentTranscriptions.AsNoTracking()
            .SingleOrDefaultAsync(x => x.MediaFileId == mediaFileId, cancellationToken);
        return new DocumentTranscriptionModel(
            media.Id, media.OriginalFileName, media.MimeType, media.Caption,
            tx?.Text ?? string.Empty, tx?.Origin ?? TranscriptionOrigin.Human,
            tx?.IsApproved ?? false, tx?.Actor ?? string.Empty, tx?.ModifiedUtc);
    }

    public async Task SaveTranscriptionAsync(
        Guid mediaFileId,
        string text,
        TranscriptionOrigin origin,
        bool approved,
        string actor,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var media = await db.ArchiveMediaFiles.SingleOrDefaultAsync(
            x => x.Id == mediaFileId && x.MediaType == ArchiveMediaType.Document,
            cancellationToken) ?? throw new InvalidOperationException("Document not found.");

        var tx = await db.DocumentTranscriptions.SingleOrDefaultAsync(
            x => x.MediaFileId == mediaFileId, cancellationToken);
        if (tx is null)
        {
            tx = new DocumentTranscription(mediaFileId, text, origin, actor);
            if (approved != tx.IsApproved)
                tx.Revise(text, origin, actor, approved);
            db.DocumentTranscriptions.Add(tx);
        }
        else
        {
            tx.Revise(text, origin, actor, approved);
        }

        db.AuditEvents.Add(new AuditEvent(
            "TranscriptionSaved", nameof(DocumentTranscription), tx.Id.ToString(), actor,
            $"Saved transcription for original document '{media.OriginalFileName}'.",
            newValueJson: JsonSerializer.Serialize(new { origin, approved, CharacterCount = text?.Length ?? 0 }),
            source: "Document Transcription"));
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task<ArchiveDashboardCounts> GetArchiveCountsAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        return new ArchiveDashboardCounts(
            await db.ArchiveMediaFiles.CountAsync(x => x.MediaType == ArchiveMediaType.Photo, cancellationToken),
            await db.ArchiveMediaFiles.CountAsync(x => x.MediaType == ArchiveMediaType.Document, cancellationToken),
            await db.SourceRecords.CountAsync(cancellationToken));
    }

    public async Task<(string FullPath, string MimeType, string FileName)?> ResolveMediaAsync(
        Guid mediaId,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var media = await db.ArchiveMediaFiles.AsNoTracking().SingleOrDefaultAsync(x => x.Id == mediaId, cancellationToken);
        if (media is null) return null;
        var fullPath = await storageService.ResolveFullPathAsync(media.StoredRelativePath, cancellationToken);
        return (fullPath, media.MimeType, media.OriginalFileName);
    }
}
