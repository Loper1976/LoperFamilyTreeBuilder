using LoperFamilyTreeBuilder.Infrastructure.Configuration;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class DatabaseBackupService(
    IDbContextFactory<FamilyTreeDbContext> contextFactory,
    ArchiveConfigurationStore configurationStore)
{
    public async Task<string> CreatePreImportBackupAsync(
        CancellationToken cancellationToken = default)
    {
        var configuration = await configurationStore.LoadAsync(cancellationToken)
            ?? throw new InvalidOperationException("Backup storage has not been configured.");

        if (!configuration.IsComplete)
            throw new InvalidOperationException("Backup storage configuration is incomplete.");

        var directory = Path.Combine(
            configuration.BackupPath,
            "DatabaseBackups",
            DateTime.UtcNow.ToString("yyyy"),
            DateTime.UtcNow.ToString("MM"));
        Directory.CreateDirectory(directory);

        var path = Path.Combine(
            directory,
            $"LoperFamilyTreeBuilder_PreImport_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}.bak");

        var escaped = path.Replace("'", "''", StringComparison.Ordinal);
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var sql = $"BACKUP DATABASE [LoperFamilyTreeBuilder] TO DISK = N'{escaped}' WITH COPY_ONLY, INIT, CHECKSUM";
        await db.Database.ExecuteSqlRawAsync(sql, cancellationToken);
        return path;
    }
}
