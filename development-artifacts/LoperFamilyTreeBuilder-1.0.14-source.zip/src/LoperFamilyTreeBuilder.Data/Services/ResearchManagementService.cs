using LoperFamilyTreeBuilder.Core.Entities;
using LoperFamilyTreeBuilder.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data.Services;

public sealed class ResearchManagementService(IDbContextFactory<FamilyTreeDbContext> contextFactory)
{
    public async Task<ResearchDashboardSummary> GetDashboardAsync(CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var open = await db.ResearchTasks.CountAsync(x => x.Status != ResearchStatus.Verified && x.Status != ResearchStatus.Archived, cancellationToken);
        var pending = await db.AiResearchSuggestions.CountAsync(x => x.Status == AiSuggestionStatus.PendingReview, cancellationToken);
        var conflicts = await db.ResearchTasks.CountAsync(x => x.Status == ResearchStatus.ConflictingEvidence || x.Status == ResearchStatus.Disputed, cancellationToken);
        var archived = await db.ResearchTasks.CountAsync(x => x.Status == ResearchStatus.Archived, cancellationToken);
        return new ResearchDashboardSummary(open, pending, conflicts, archived);
    }

    public async Task<IReadOnlyList<ResearchTaskListItem>> GetTasksAsync(
        ResearchStatus? status = null,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var query = db.ResearchTasks.AsNoTracking();
        if (status.HasValue)
            query = query.Where(x => x.Status == status.Value);

        return await query
            .OrderBy(x => x.Status)
            .ThenByDescending(x => x.ModifiedUtc)
            .Select(x => new ResearchTaskListItem(
                x.Id,
                x.PersonId,
                x.Person == null ? null : (x.Person.GivenName + " " + x.Person.MiddleName + " " + x.Person.Surname).Trim(),
                x.Person == null ? null : x.Person.Identifiers
                    .Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber)
                    .Select(i => i.Value)
                    .FirstOrDefault(),
                x.FamilyBranchId,
                x.FamilyBranch == null ? null : x.FamilyBranch.Name,
                x.ResearchQuestion,
                x.AssignedResearcher,
                x.Status,
                x.RepositorySearched,
                x.SearchDate,
                x.SearchResults,
                x.NegativeSearches,
                x.Notes,
                x.Sources,
                x.FollowUpAction,
                x.ModifiedUtc))
            .Take(500)
            .ToListAsync(cancellationToken);
    }

    public async Task<Guid> CreateTaskAsync(
        CreateResearchTaskRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);

        if (request.PersonId.HasValue && !await db.People.AnyAsync(x => x.Id == request.PersonId.Value, cancellationToken))
            throw new InvalidOperationException("Linked person was not found.");

        if (request.FamilyBranchId.HasValue && !await db.FamilyBranches.AnyAsync(x => x.Id == request.FamilyBranchId.Value, cancellationToken))
            throw new InvalidOperationException("Family branch was not found.");

        var entity = new ResearchTaskRecord(request.ResearchQuestion);
        entity.Update(
            request.PersonId,
            request.FamilyBranchId,
            request.AssignedResearcher,
            request.Status,
            request.RepositorySearched,
            request.SearchDate,
            request.SearchResults,
            request.NegativeSearches,
            request.Notes,
            request.Sources,
            request.FollowUpAction);

        db.ResearchTasks.Add(entity);
        db.AuditEvents.Add(new AuditEvent(
            "Research Task Add",
            nameof(ResearchTaskRecord),
            entity.Id.ToString(),
            actor,
            $"Created research task: {entity.ResearchQuestion}",
            source: "Research task manager"));

        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task UpdateTaskStatusAsync(
        Guid taskId,
        ResearchStatus status,
        string actor,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var entity = await db.ResearchTasks.SingleOrDefaultAsync(x => x.Id == taskId, cancellationToken)
            ?? throw new InvalidOperationException("Research task not found.");

        var previous = entity.Status;
        entity.SetStatus(status);
        db.AuditEvents.Add(new AuditEvent(
            "Research Task Status",
            nameof(ResearchTaskRecord),
            entity.Id.ToString(),
            actor,
            $"Research task status changed from {previous} to {status}.",
            previousValueJson: previous.ToString(),
            newValueJson: status.ToString(),
            source: "Research task manager"));
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task<Guid> CreateSuggestionAsync(
        CreateAiSuggestionRequest request,
        string actor,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var entity = new AiResearchSuggestion(
            request.SuggestionType,
            request.Prompt,
            request.Result,
            request.SourcesUsed);
        entity.SetContext(request.PersonId, request.FamilyBranchId);
        entity.SetProposal(request.Result, request.SourcesUsed, request.Confidence, request.ProposedChange);
        db.AiResearchSuggestions.Add(entity);
        db.AuditEvents.Add(new AuditEvent(
            "AI Research Suggestion Add",
            nameof(AiResearchSuggestion),
            entity.Id.ToString(),
            actor,
            "Stored a proposal-first AI/research suggestion for human review.",
            source: "AI research approval queue"));
        await db.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task<int> GenerateArchiveReviewSuggestionsAsync(
        string actor,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);

        var people = await db.People.AsNoTracking()
            .Select(p => new
            {
                p.Id,
                p.GivenName,
                p.MiddleName,
                p.Surname,
                p.IsLiving,
                p.BirthDate,
                p.DeathDate,
                CitationCount = db.CitationRecords.Count(c => c.PersonId == p.Id),
                PhotoCount = db.PersonMediaLinks.Count(m => m.PersonId == p.Id && m.MediaFile.MediaType == ArchiveMediaType.Photo),
                BurialCount = db.BurialRecords.Count(b => b.PersonId == p.Id)
            })
            .OrderBy(x => x.Surname)
            .ThenBy(x => x.GivenName)
            .Take(5000)
            .ToListAsync(cancellationToken);

        var existing = await db.AiResearchSuggestions
            .Where(x => x.Status == AiSuggestionStatus.PendingReview && x.PersonId != null)
            .Select(x => new { x.PersonId, x.SuggestionType, x.ProposedChange })
            .ToListAsync(cancellationToken);

        var existingKeys = existing
            .Select(x => $"{x.PersonId}|{x.SuggestionType}|{x.ProposedChange}")
            .ToHashSet(StringComparer.Ordinal);

        var created = 0;

        foreach (var person in people)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (created >= 250)
                break;

            var name = string.Join(" ", new[] { person.GivenName, person.MiddleName, person.Surname }
                .Where(x => !string.IsNullOrWhiteSpace(x)));

            created += AddIfMissing(
                person.BirthDate is null,
                person.Id,
                AiSuggestionType.MissingInformation,
                $"Review missing birth date for {name}.",
                "Birth date is not recorded.",
                "Research and document the birth date with source evidence.",
                existingKeys,
                db);

            created += AddIfMissing(
                !person.IsLiving && person.DeathDate is null,
                person.Id,
                AiSuggestionType.MissingInformation,
                $"Review missing death date for {name}.",
                "The person is marked deceased but no death date is recorded.",
                "Research and document the death date with source evidence.",
                existingKeys,
                db);

            created += AddIfMissing(
                person.CitationCount == 0,
                person.Id,
                AiSuggestionType.SourceGap,
                $"Review source coverage for {name}.",
                "No person citations are currently linked.",
                "Locate and cite at least one reliable source before treating key facts as verified.",
                existingKeys,
                db);

            created += AddIfMissing(
                person.PhotoCount == 0,
                person.Id,
                AiSuggestionType.ResearchTarget,
                $"Review photo coverage for {name}.",
                "No archived photograph is currently linked.",
                "Search family collections for an original photograph and preserve provenance.",
                existingKeys,
                db);

            created += AddIfMissing(
                !person.IsLiving && person.BurialCount == 0,
                person.Id,
                AiSuggestionType.CemeteryResearch,
                $"Review burial/cemetery information for {name}.",
                "No burial record is currently linked.",
                "Research cemetery, grave location, and headstone evidence.",
                existingKeys,
                db);
        }

        if (created > 0)
        {
            db.AuditEvents.Add(new AuditEvent(
                "Archive Research Review",
                nameof(AiResearchSuggestion),
                Guid.NewGuid().ToString(),
                actor,
                $"Generated {created} proposal-first research suggestions from gaps in existing archive data.",
                source: "Local archive review engine"));
            await db.SaveChangesAsync(cancellationToken);
        }

        return created;
    }

    public async Task<IReadOnlyList<AiSuggestionListItem>> GetSuggestionsAsync(
        AiSuggestionStatus? status = null,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var query = db.AiResearchSuggestions.AsNoTracking();
        if (status.HasValue)
            query = query.Where(x => x.Status == status.Value);

        return await query
            .OrderBy(x => x.Status)
            .ThenByDescending(x => x.CreatedUtc)
            .Select(x => new AiSuggestionListItem(
                x.Id,
                x.PersonId,
                x.Person == null ? null : (x.Person.GivenName + " " + x.Person.MiddleName + " " + x.Person.Surname).Trim(),
                x.Person == null ? null : x.Person.Identifiers
                    .Where(i => i.IdentifierType == PersonIdentifierType.LegacyNumber)
                    .Select(i => i.Value)
                    .FirstOrDefault(),
                x.SuggestionType,
                x.Prompt,
                x.Result,
                x.SourcesUsed,
                x.Confidence,
                x.ProposedChange,
                x.Status,
                x.ReviewNotes,
                x.CreatedUtc,
                x.ReviewedUtc))
            .Take(500)
            .ToListAsync(cancellationToken);
    }

    public async Task ReviewSuggestionAsync(
        Guid suggestionId,
        AiSuggestionStatus status,
        Guid? reviewerUserId,
        string reviewNotes,
        string actor,
        CancellationToken cancellationToken = default)
    {
        await using var db = await contextFactory.CreateDbContextAsync(cancellationToken);
        var suggestion = await db.AiResearchSuggestions.SingleOrDefaultAsync(x => x.Id == suggestionId, cancellationToken)
            ?? throw new InvalidOperationException("AI/research suggestion not found.");

        if (status == AiSuggestionStatus.SavedAsResearchLead)
        {
            var task = new ResearchTaskRecord(
                string.IsNullOrWhiteSpace(suggestion.ProposedChange)
                    ? suggestion.Prompt
                    : suggestion.ProposedChange);
            task.Update(
                suggestion.PersonId,
                suggestion.FamilyBranchId,
                actor,
                ResearchStatus.AiResearchLead,
                string.Empty,
                null,
                suggestion.Result,
                string.Empty,
                reviewNotes,
                suggestion.SourcesUsed,
                "Verify the suggestion independently and attach supporting evidence.");
            db.ResearchTasks.Add(task);
        }

        suggestion.Review(status, reviewerUserId, reviewNotes);
        db.AuditEvents.Add(new AuditEvent(
            "AI Research Suggestion Review",
            nameof(AiResearchSuggestion),
            suggestion.Id.ToString(),
            actor,
            $"Suggestion reviewed with status {status}. No authoritative genealogy fact was changed automatically.",
            reason: reviewNotes,
            source: "AI research approval queue"));
        await db.SaveChangesAsync(cancellationToken);
    }

    private static int AddIfMissing(
        bool condition,
        Guid personId,
        AiSuggestionType type,
        string prompt,
        string result,
        string proposedChange,
        HashSet<string> existingKeys,
        FamilyTreeDbContext db)
    {
        if (!condition)
            return 0;

        var key = $"{personId}|{type}|{proposedChange}";
        if (!existingKeys.Add(key))
            return 0;

        var suggestion = new AiResearchSuggestion(type, prompt, result, "Existing Loper Family Tree Builder archive");
        suggestion.SetContext(personId, null);
        suggestion.SetProposal(result, "Existing Loper Family Tree Builder archive", "Rule-based archive gap detection", proposedChange);
        db.AiResearchSuggestions.Add(suggestion);
        return 1;
    }
}
