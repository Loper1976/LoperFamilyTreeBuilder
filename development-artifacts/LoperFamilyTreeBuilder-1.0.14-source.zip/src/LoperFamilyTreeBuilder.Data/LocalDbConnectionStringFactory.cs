using LoperFamilyTreeBuilder.Infrastructure.Configuration;

namespace LoperFamilyTreeBuilder.Data;

public sealed class LocalDbConnectionStringFactory
{
    private readonly ApplicationPaths _paths;

    public LocalDbConnectionStringFactory(ApplicationPaths paths)
    {
        _paths = paths;
    }

    public string Create()
    {
        var productionConnectionString =
            Environment.GetEnvironmentVariable("LOPER_FAMILYTREE_CONNECTION_STRING")?.Trim();

        if (!string.IsNullOrWhiteSpace(productionConnectionString))
            return productionConnectionString;

        _paths.EnsureLocalDirectories();

        var escapedFile = _paths.DatabaseFile.Replace(";", ";;");

        return
            "Server=(localdb)\\MSSQLLocalDB;" +
            "Integrated Security=true;" +
            "TrustServerCertificate=true;" +
            $"AttachDbFilename={escapedFile};" +
            "Database=LoperFamilyTreeBuilder;" +
            "MultipleActiveResultSets=true;";
    }
}
