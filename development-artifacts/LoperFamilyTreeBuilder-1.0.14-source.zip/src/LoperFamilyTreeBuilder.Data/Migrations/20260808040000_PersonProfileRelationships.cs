using System;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoperFamilyTreeBuilder.Data.Migrations;

[DbContext(typeof(FamilyTreeDbContext))]
[Migration("20260808040000_PersonProfileRelationships")]
public partial class PersonProfileRelationships : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<string>(
            name: "Reason",
            table: "AuditEvents",
            type: "nvarchar(1000)",
            maxLength: 1000,
            nullable: true);

        migrationBuilder.AddColumn<string>(
            name: "Source",
            table: "AuditEvents",
            type: "nvarchar(500)",
            maxLength: 500,
            nullable: true);

        migrationBuilder.CreateTable(
            name: "CoupleRelationships",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonAId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonBId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                RelationshipType = table.Column<int>(type: "int", nullable: false),
                StartDate = table.Column<DateOnly>(type: "date", nullable: true),
                EndDate = table.Column<DateOnly>(type: "date", nullable: true),
                Notes = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_CoupleRelationships", x => x.Id);
                table.ForeignKey(
                    name: "FK_CoupleRelationships_People_PersonAId",
                    column: x => x.PersonAId,
                    principalTable: "People",
                    principalColumn: "Id");
                table.ForeignKey(
                    name: "FK_CoupleRelationships_People_PersonBId",
                    column: x => x.PersonBId,
                    principalTable: "People",
                    principalColumn: "Id");
            });

        migrationBuilder.CreateIndex(
            name: "IX_CoupleRelationships_PersonAId",
            table: "CoupleRelationships",
            column: "PersonAId");

        migrationBuilder.CreateIndex(
            name: "IX_CoupleRelationships_PersonBId",
            table: "CoupleRelationships",
            column: "PersonBId");

        migrationBuilder.CreateIndex(
            name: "IX_CoupleRelationships_PersonAId_PersonBId",
            table: "CoupleRelationships",
            columns: new[] { "PersonAId", "PersonBId" },
            unique: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "CoupleRelationships");

        migrationBuilder.DropColumn(
            name: "Reason",
            table: "AuditEvents");

        migrationBuilder.DropColumn(
            name: "Source",
            table: "AuditEvents");
    }
}
