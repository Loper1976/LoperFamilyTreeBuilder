using System;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoperFamilyTreeBuilder.Data.Migrations;

[DbContext(typeof(FamilyTreeDbContext))]
[Migration("20260808050000_SourcesDocumentsPhotos")]
public partial class SourcesDocumentsPhotos : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "ArchiveMediaFiles",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                MediaType = table.Column<int>(type: "int", nullable: false),
                OriginalFileName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                StoredRelativePath = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                MimeType = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                FileSizeBytes = table.Column<long>(type: "bigint", nullable: false),
                Sha256 = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                IsOriginal = table.Column<bool>(type: "bit", nullable: false),
                DerivativeOfMediaFileId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                Caption = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                CaptureDateTime = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                CaptureDateIsApproximate = table.Column<bool>(type: "bit", nullable: false),
                DeviceOrCamera = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Orientation = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                Latitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: true),
                Longitude = table.Column<decimal>(type: "decimal(9,6)", precision: 9, scale: 6, nullable: true),
                MetadataSource = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                Photographer = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Owner = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Rights = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                DocumentType = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table => table.PrimaryKey("PK_ArchiveMediaFiles", x => x.Id));

        migrationBuilder.CreateTable(
            name: "SourceRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                Title = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                Repository = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                CallNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Url = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                AccessDate = table.Column<DateOnly>(type: "date", nullable: true),
                Classification = table.Column<int>(type: "int", nullable: false),
                EvidenceQuality = table.Column<int>(type: "int", nullable: false),
                Confidence = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                Notes = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: false),
                OriginalDocumentMediaFileId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table => table.PrimaryKey("PK_SourceRecords", x => x.Id));

        migrationBuilder.CreateTable(
            name: "DocumentTranscriptions",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                MediaFileId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                Text = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Origin = table.Column<int>(type: "int", nullable: false),
                Actor = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                IsApproved = table.Column<bool>(type: "bit", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table => table.PrimaryKey("PK_DocumentTranscriptions", x => x.Id));

        migrationBuilder.CreateTable(
            name: "PersonMediaLinks",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                MediaFileId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                Role = table.Column<int>(type: "int", nullable: false),
                Notes = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_PersonMediaLinks", x => x.Id);
                table.ForeignKey("FK_PersonMediaLinks_ArchiveMediaFiles_MediaFileId", x => x.MediaFileId, "ArchiveMediaFiles", "Id", onDelete: ReferentialAction.Cascade);
                table.ForeignKey("FK_PersonMediaLinks_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "CitationRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                SourceRecordId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                MediaFileId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                FactOrSubject = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Position = table.Column<int>(type: "int", nullable: false),
                PageOrCallNumber = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                CitationText = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: false),
                Notes = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_CitationRecords", x => x.Id);
                table.ForeignKey("FK_CitationRecords_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.Cascade);
                table.ForeignKey("FK_CitationRecords_SourceRecords_SourceRecordId", x => x.SourceRecordId, "SourceRecords", "Id");
            });

        migrationBuilder.CreateIndex("IX_ArchiveMediaFiles_CreatedUtc", "ArchiveMediaFiles", "CreatedUtc");
        migrationBuilder.CreateIndex("IX_ArchiveMediaFiles_MediaType", "ArchiveMediaFiles", "MediaType");
        migrationBuilder.CreateIndex("IX_ArchiveMediaFiles_Sha256", "ArchiveMediaFiles", "Sha256");
        migrationBuilder.CreateIndex("IX_CitationRecords_PersonId", "CitationRecords", "PersonId");
        migrationBuilder.CreateIndex("IX_CitationRecords_Position", "CitationRecords", "Position");
        migrationBuilder.CreateIndex("IX_CitationRecords_SourceRecordId", "CitationRecords", "SourceRecordId");
        migrationBuilder.CreateIndex("IX_DocumentTranscriptions_MediaFileId", "DocumentTranscriptions", "MediaFileId", unique: true);
        migrationBuilder.CreateIndex("IX_PersonMediaLinks_MediaFileId", "PersonMediaLinks", "MediaFileId");
        migrationBuilder.CreateIndex("IX_PersonMediaLinks_PersonId_MediaFileId", "PersonMediaLinks", new[] { "PersonId", "MediaFileId" }, unique: true);
        migrationBuilder.CreateIndex("IX_SourceRecords_Repository", "SourceRecords", "Repository");
        migrationBuilder.CreateIndex("IX_SourceRecords_Title", "SourceRecords", "Title");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("CitationRecords");
        migrationBuilder.DropTable("DocumentTranscriptions");
        migrationBuilder.DropTable("PersonMediaLinks");
        migrationBuilder.DropTable("SourceRecords");
        migrationBuilder.DropTable("ArchiveMediaFiles");
    }
}
