using System;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoperFamilyTreeBuilder.Data.Migrations;

[DbContext(typeof(FamilyTreeDbContext))]
[Migration("20260808090000_UsersCollaborationPrivacy")]
public partial class UsersCollaborationPrivacy : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable("FamilyUsers", table => new
        {
            Id=table.Column<Guid>(type:"uniqueidentifier",nullable:false), Email=table.Column<string>(type:"nvarchar(500)",maxLength:500,nullable:false),
            NormalizedEmail=table.Column<string>(type:"nvarchar(500)",maxLength:500,nullable:false), DisplayName=table.Column<string>(type:"nvarchar(500)",maxLength:500,nullable:false),
            PasswordHash=table.Column<string>(type:"nvarchar(2000)",maxLength:2000,nullable:false), IsActive=table.Column<bool>(type:"bit",nullable:false), IsLocked=table.Column<bool>(type:"bit",nullable:false),
            LastLoginUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:true), CreatedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false), ModifiedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false)
        }, constraints: table=>table.PrimaryKey("PK_FamilyUsers",x=>x.Id));

        migrationBuilder.CreateTable("UserInvitations", table => new
        {
            Id=table.Column<Guid>(type:"uniqueidentifier",nullable:false), Email=table.Column<string>(type:"nvarchar(500)",maxLength:500,nullable:false), NormalizedEmail=table.Column<string>(type:"nvarchar(500)",maxLength:500,nullable:false),
            IntendedRole=table.Column<int>(type:"int",nullable:false), TokenHash=table.Column<string>(type:"nvarchar(128)",maxLength:128,nullable:false), ExpiresUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false),
            AcceptedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:true), RevokedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:true), CreatedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false)
        }, constraints: table=>table.PrimaryKey("PK_UserInvitations",x=>x.Id));

        migrationBuilder.CreateTable("UserRoleMemberships", table => new
        {
            Id=table.Column<Guid>(type:"uniqueidentifier",nullable:false), FamilyUserId=table.Column<Guid>(type:"uniqueidentifier",nullable:false), Role=table.Column<int>(type:"int",nullable:false), CreatedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false)
        }, constraints: table=>{table.PrimaryKey("PK_UserRoleMemberships",x=>x.Id);table.ForeignKey("FK_UserRoleMemberships_FamilyUsers_FamilyUserId",x=>x.FamilyUserId,"FamilyUsers","Id",onDelete:ReferentialAction.Cascade);});

        migrationBuilder.CreateTable("BranchPermissions", table => new
        {
            Id=table.Column<Guid>(type:"uniqueidentifier",nullable:false), FamilyUserId=table.Column<Guid>(type:"uniqueidentifier",nullable:false), FamilyBranchId=table.Column<Guid>(type:"uniqueidentifier",nullable:false),
            CanViewLivingPeople=table.Column<bool>(type:"bit",nullable:false), CanEditGenealogy=table.Column<bool>(type:"bit",nullable:false), CanViewMedical=table.Column<bool>(type:"bit",nullable:false),
            CanReviewSubmissions=table.Column<bool>(type:"bit",nullable:false), CreatedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false), ModifiedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false)
        }, constraints: table=>{table.PrimaryKey("PK_BranchPermissions",x=>x.Id);table.ForeignKey("FK_BranchPermissions_FamilyBranches_FamilyBranchId",x=>x.FamilyBranchId,"FamilyBranches","Id",onDelete:ReferentialAction.Cascade);table.ForeignKey("FK_BranchPermissions_FamilyUsers_FamilyUserId",x=>x.FamilyUserId,"FamilyUsers","Id",onDelete:ReferentialAction.Cascade);});

        migrationBuilder.CreateTable("FamilySubmissions", table => new
        {
            Id=table.Column<Guid>(type:"uniqueidentifier",nullable:false), SubmittedByUserId=table.Column<Guid>(type:"uniqueidentifier",nullable:false), TargetPersonId=table.Column<Guid>(type:"uniqueidentifier",nullable:true),
            SubmissionType=table.Column<int>(type:"int",nullable:false), Subject=table.Column<string>(type:"nvarchar(1000)",maxLength:1000,nullable:false), Details=table.Column<string>(type:"nvarchar(max)",nullable:false),
            OriginalFileName=table.Column<string>(type:"nvarchar(1000)",maxLength:1000,nullable:false), StoredRelativePath=table.Column<string>(type:"nvarchar(2000)",maxLength:2000,nullable:false), Sha256=table.Column<string>(type:"nvarchar(64)",maxLength:64,nullable:false),
            FileSizeBytes=table.Column<long>(type:"bigint",nullable:false), RightsAndPrivacyAccepted=table.Column<bool>(type:"bit",nullable:false), Status=table.Column<int>(type:"int",nullable:false), ReviewNotes=table.Column<string>(type:"nvarchar(max)",nullable:false),
            ReviewedByUserId=table.Column<Guid>(type:"uniqueidentifier",nullable:true), SubmittedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:false), ReviewedUtc=table.Column<DateTimeOffset>(type:"datetimeoffset",nullable:true)
        }, constraints: table=>{table.PrimaryKey("PK_FamilySubmissions",x=>x.Id);table.ForeignKey("FK_FamilySubmissions_FamilyUsers_SubmittedByUserId",x=>x.SubmittedByUserId,"FamilyUsers","Id",onDelete:ReferentialAction.Restrict);table.ForeignKey("FK_FamilySubmissions_People_TargetPersonId",x=>x.TargetPersonId,"People","Id",onDelete:ReferentialAction.SetNull);});

        migrationBuilder.CreateIndex("IX_FamilyUsers_NormalizedEmail","FamilyUsers","NormalizedEmail",unique:true);
        migrationBuilder.CreateIndex("IX_UserInvitations_TokenHash","UserInvitations","TokenHash",unique:true); migrationBuilder.CreateIndex("IX_UserInvitations_NormalizedEmail","UserInvitations","NormalizedEmail");
        migrationBuilder.CreateIndex("IX_UserRoleMemberships_FamilyUserId_Role","UserRoleMemberships",new[]{"FamilyUserId","Role"},unique:true); migrationBuilder.CreateIndex("IX_UserRoleMemberships_FamilyUserId","UserRoleMemberships","FamilyUserId");
        migrationBuilder.CreateIndex("IX_BranchPermissions_FamilyUserId_FamilyBranchId","BranchPermissions",new[]{"FamilyUserId","FamilyBranchId"},unique:true); migrationBuilder.CreateIndex("IX_BranchPermissions_FamilyBranchId","BranchPermissions","FamilyBranchId");
        migrationBuilder.CreateIndex("IX_FamilySubmissions_Status","FamilySubmissions","Status"); migrationBuilder.CreateIndex("IX_FamilySubmissions_SubmittedByUserId","FamilySubmissions","SubmittedByUserId"); migrationBuilder.CreateIndex("IX_FamilySubmissions_TargetPersonId","FamilySubmissions","TargetPersonId");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("BranchPermissions"); migrationBuilder.DropTable("FamilySubmissions"); migrationBuilder.DropTable("UserInvitations"); migrationBuilder.DropTable("UserRoleMemberships"); migrationBuilder.DropTable("FamilyUsers");
    }
}
