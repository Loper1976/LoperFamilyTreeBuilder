using System;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoperFamilyTreeBuilder.Data.Migrations;

[DbContext(typeof(FamilyTreeDbContext))]
[Migration("20260808080000_CemeteryMilitaryStoriesTimeline")]
public partial class CemeteryMilitaryStoriesTimeline : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "CemeteryRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                Name = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Address = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                City = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                StateRegion = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Country = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Latitude = table.Column<decimal>(type: "decimal(10,7)", precision: 10, scale: 7, nullable: true),
                Longitude = table.Column<decimal>(type: "decimal(10,7)", precision: 10, scale: 7, nullable: true),
                BoundaryNotes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Notes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table => table.PrimaryKey("PK_CemeteryRecords", x => x.Id));

        migrationBuilder.CreateTable(
            name: "FamilyStoryRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                Title = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                OriginalText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                EditedPublicationText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Contributor = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                RecordedDate = table.Column<DateOnly>(type: "date", nullable: true),
                Notes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_FamilyStoryRecords", x => x.Id);
                table.ForeignKey("FK_FamilyStoryRecords_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.SetNull);
            });

        migrationBuilder.CreateTable(
            name: "MilitaryServiceRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                Branch = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Component = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                RankRating = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Specialty = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                ServiceNumber = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                StartDate = table.Column<DateOnly>(type: "date", nullable: true),
                EndDate = table.Column<DateOnly>(type: "date", nullable: true),
                UnitsShipsDutyStations = table.Column<string>(type: "nvarchar(max)", nullable: false),
                WarsCampaignsDeployments = table.Column<string>(type: "nvarchar(max)", nullable: false),
                AwardsQualifications = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Discharge = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Notes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_MilitaryServiceRecords", x => x.Id);
                table.ForeignKey("FK_MilitaryServiceRecords_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "TimelineEventRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                EventType = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Title = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                EventDate = table.Column<DateOnly>(type: "date", nullable: true),
                ApproximateYear = table.Column<int>(type: "int", nullable: true),
                PlaceName = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                Latitude = table.Column<decimal>(type: "decimal(10,7)", precision: 10, scale: 7, nullable: true),
                Longitude = table.Column<decimal>(type: "decimal(10,7)", precision: 10, scale: 7, nullable: true),
                Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                SourceSummary = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_TimelineEventRecords", x => x.Id);
                table.ForeignKey("FK_TimelineEventRecords_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "BurialRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                CemeteryId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                BurialDate = table.Column<DateOnly>(type: "date", nullable: true),
                Section = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Plot = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Row = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Grave = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                MarkerInscription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Latitude = table.Column<decimal>(type: "decimal(10,7)", precision: 10, scale: 7, nullable: true),
                Longitude = table.Column<decimal>(type: "decimal(10,7)", precision: 10, scale: 7, nullable: true),
                NeedsMarkerPhoto = table.Column<bool>(type: "bit", nullable: false),
                VisitStatus = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                Notes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_BurialRecords", x => x.Id);
                table.ForeignKey("FK_BurialRecords_CemeteryRecords_CemeteryId", x => x.CemeteryId, "CemeteryRecords", "Id", onDelete: ReferentialAction.Restrict);
                table.ForeignKey("FK_BurialRecords_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateIndex("IX_CemeteryRecords_Name", "CemeteryRecords", "Name");
        migrationBuilder.CreateIndex("IX_FamilyStoryRecords_PersonId", "FamilyStoryRecords", "PersonId");
        migrationBuilder.CreateIndex("IX_FamilyStoryRecords_Title", "FamilyStoryRecords", "Title");
        migrationBuilder.CreateIndex("IX_MilitaryServiceRecords_PersonId", "MilitaryServiceRecords", "PersonId");
        migrationBuilder.CreateIndex("IX_MilitaryServiceRecords_Branch", "MilitaryServiceRecords", "Branch");
        migrationBuilder.CreateIndex("IX_TimelineEventRecords_PersonId", "TimelineEventRecords", "PersonId");
        migrationBuilder.CreateIndex("IX_TimelineEventRecords_EventDate", "TimelineEventRecords", "EventDate");
        migrationBuilder.CreateIndex("IX_TimelineEventRecords_ApproximateYear", "TimelineEventRecords", "ApproximateYear");
        migrationBuilder.CreateIndex("IX_BurialRecords_PersonId", "BurialRecords", "PersonId");
        migrationBuilder.CreateIndex("IX_BurialRecords_CemeteryId", "BurialRecords", "CemeteryId");
        migrationBuilder.CreateIndex("IX_BurialRecords_CemeteryId_Section_Plot_Row_Grave", "BurialRecords", new[] { "CemeteryId", "Section", "Plot", "Row", "Grave" });
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("BurialRecords");
        migrationBuilder.DropTable("FamilyStoryRecords");
        migrationBuilder.DropTable("MilitaryServiceRecords");
        migrationBuilder.DropTable("TimelineEventRecords");
        migrationBuilder.DropTable("CemeteryRecords");
    }
}
