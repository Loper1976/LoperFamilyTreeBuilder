using System;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoperFamilyTreeBuilder.Data.Migrations;

[DbContext(typeof(FamilyTreeDbContext))]
[Migration("20260808070000_MedicalFamilyHealth")]
public partial class MedicalFamilyHealth : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "MedicalConditionRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                ConditionName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                DiagnosisDate = table.Column<DateOnly>(type: "date", nullable: true),
                ApproximateDiagnosisYear = table.Column<int>(type: "int", nullable: true),
                AgeAtOnset = table.Column<int>(type: "int", nullable: true),
                Status = table.Column<int>(type: "int", nullable: false),
                EvidenceStatus = table.Column<int>(type: "int", nullable: false),
                Severity = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                PotentialHereditaryRelevance = table.Column<bool>(type: "bit", nullable: false),
                TreatingProvider = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                TreatingFacility = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                PrivateNotes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                PrivacyLevel = table.Column<int>(type: "int", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_MedicalConditionRecords", x => x.Id);
                table.ForeignKey(name: "FK_MedicalConditionRecords_People_PersonId", column: x => x.PersonId,
                    principalTable: "People", principalColumn: "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "MedicalEventRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                EventType = table.Column<int>(type: "int", nullable: false),
                Title = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                EventDate = table.Column<DateOnly>(type: "date", nullable: true),
                ApproximateYear = table.Column<int>(type: "int", nullable: true),
                Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                TreatingProvider = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                TreatingFacility = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                EvidenceStatus = table.Column<int>(type: "int", nullable: false),
                PrivateNotes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                PrivacyLevel = table.Column<int>(type: "int", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_MedicalEventRecords", x => x.Id);
                table.ForeignKey(name: "FK_MedicalEventRecords_People_PersonId", column: x => x.PersonId,
                    principalTable: "People", principalColumn: "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "CauseOfDeathRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PrimaryCause = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                SecondaryCauses = table.Column<string>(type: "nvarchar(max)", nullable: false),
                ContributingConditions = table.Column<string>(type: "nvarchar(max)", nullable: false),
                EvidenceStatus = table.Column<int>(type: "int", nullable: false),
                PrivateNotes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                PrivacyLevel = table.Column<int>(type: "int", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_CauseOfDeathRecords", x => x.Id);
                table.ForeignKey(name: "FK_CauseOfDeathRecords_People_PersonId", column: x => x.PersonId,
                    principalTable: "People", principalColumn: "Id", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "MedicalEvidenceLinks",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                RecordType = table.Column<int>(type: "int", nullable: false),
                RecordId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                CitationRecordId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                MediaFileId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table => table.PrimaryKey("PK_MedicalEvidenceLinks", x => x.Id));

        migrationBuilder.CreateIndex(name: "IX_MedicalConditionRecords_PersonId", table: "MedicalConditionRecords", column: "PersonId");
        migrationBuilder.CreateIndex(name: "IX_MedicalConditionRecords_ConditionName", table: "MedicalConditionRecords", column: "ConditionName");
        migrationBuilder.CreateIndex(name: "IX_MedicalConditionRecords_EvidenceStatus", table: "MedicalConditionRecords", column: "EvidenceStatus");
        migrationBuilder.CreateIndex(name: "IX_MedicalEventRecords_PersonId", table: "MedicalEventRecords", column: "PersonId");
        migrationBuilder.CreateIndex(name: "IX_MedicalEventRecords_EventType", table: "MedicalEventRecords", column: "EventType");
        migrationBuilder.CreateIndex(name: "IX_MedicalEventRecords_EventDate", table: "MedicalEventRecords", column: "EventDate");
        migrationBuilder.CreateIndex(name: "IX_CauseOfDeathRecords_PersonId", table: "CauseOfDeathRecords", column: "PersonId", unique: true);
        migrationBuilder.CreateIndex(name: "IX_MedicalEvidenceLinks_PersonId", table: "MedicalEvidenceLinks", column: "PersonId");
        migrationBuilder.CreateIndex(name: "IX_MedicalEvidenceLinks_RecordType_RecordId", table: "MedicalEvidenceLinks", columns: new[] { "RecordType", "RecordId" });
        migrationBuilder.CreateIndex(name: "IX_MedicalEvidenceLinks_CitationRecordId", table: "MedicalEvidenceLinks", column: "CitationRecordId");
        migrationBuilder.CreateIndex(name: "IX_MedicalEvidenceLinks_MediaFileId", table: "MedicalEvidenceLinks", column: "MediaFileId");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "MedicalEvidenceLinks");
        migrationBuilder.DropTable(name: "CauseOfDeathRecords");
        migrationBuilder.DropTable(name: "MedicalEventRecords");
        migrationBuilder.DropTable(name: "MedicalConditionRecords");
    }
}
