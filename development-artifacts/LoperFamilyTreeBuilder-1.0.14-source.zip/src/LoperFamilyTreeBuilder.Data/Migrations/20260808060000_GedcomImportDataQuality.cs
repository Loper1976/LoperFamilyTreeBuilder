using System;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoperFamilyTreeBuilder.Data.Migrations;

[DbContext(typeof(FamilyTreeDbContext))]
[Migration("20260808060000_GedcomImportDataQuality")]
public partial class GedcomImportDataQuality : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "GedcomImportSessions",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                OriginalFileName = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                StoredRelativePath = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                Sha256 = table.Column<string>(type: "nvarchar(64)", maxLength: 64, nullable: false),
                Status = table.Column<int>(type: "int", nullable: false),
                IndividualCount = table.Column<int>(type: "int", nullable: false),
                FamilyCount = table.Column<int>(type: "int", nullable: false),
                SourceCount = table.Column<int>(type: "int", nullable: false),
                UnsupportedTagCount = table.Column<int>(type: "int", nullable: false),
                DuplicateCandidateCount = table.Column<int>(type: "int", nullable: false),
                ConflictCount = table.Column<int>(type: "int", nullable: false),
                ImportPlanJson = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Notes = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: false),
                BackupFilePath = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ApprovedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                AppliedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true)
            },
            constraints: table => table.PrimaryKey("PK_GedcomImportSessions", x => x.Id));

        migrationBuilder.CreateTable(
            name: "GedcomImportIssues",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                ImportSessionId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                IssueType = table.Column<int>(type: "int", nullable: false),
                RecordPointer = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                Message = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                Details = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_GedcomImportIssues", x => x.Id);
                table.ForeignKey(
                    name: "FK_GedcomImportIssues_GedcomImportSessions_ImportSessionId",
                    column: x => x.ImportSessionId,
                    principalTable: "GedcomImportSessions",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateIndex(name: "IX_GedcomImportSessions_CreatedUtc", table: "GedcomImportSessions", column: "CreatedUtc");
        migrationBuilder.CreateIndex(name: "IX_GedcomImportSessions_Status", table: "GedcomImportSessions", column: "Status");
        migrationBuilder.CreateIndex(name: "IX_GedcomImportSessions_Sha256", table: "GedcomImportSessions", column: "Sha256");
        migrationBuilder.CreateIndex(name: "IX_GedcomImportIssues_ImportSessionId", table: "GedcomImportIssues", column: "ImportSessionId");
        migrationBuilder.CreateIndex(name: "IX_GedcomImportIssues_IssueType", table: "GedcomImportIssues", column: "IssueType");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "GedcomImportIssues");
        migrationBuilder.DropTable(name: "GedcomImportSessions");
    }
}
