using System;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LoperFamilyTreeBuilder.Data.Migrations;

[DbContext(typeof(FamilyTreeDbContext))]
[Migration("20260808100000_AIResearch")]
public partial class AIResearch : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "ResearchTasks",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                FamilyBranchId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                ResearchQuestion = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                AssignedResearcher = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                Status = table.Column<int>(type: "int", nullable: false),
                RepositorySearched = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                SearchDate = table.Column<DateOnly>(type: "date", nullable: true),
                SearchResults = table.Column<string>(type: "nvarchar(max)", nullable: false),
                NegativeSearches = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Notes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Sources = table.Column<string>(type: "nvarchar(max)", nullable: false),
                FollowUpAction = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ModifiedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_ResearchTasks", x => x.Id);
                table.ForeignKey("FK_ResearchTasks_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.SetNull);
                table.ForeignKey("FK_ResearchTasks_FamilyBranches_FamilyBranchId", x => x.FamilyBranchId, "FamilyBranches", "Id", onDelete: ReferentialAction.SetNull);
            });

        migrationBuilder.CreateTable(
            name: "AiResearchSuggestions",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PersonId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                FamilyBranchId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                SuggestionType = table.Column<int>(type: "int", nullable: false),
                Prompt = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Result = table.Column<string>(type: "nvarchar(max)", nullable: false),
                SourcesUsed = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Confidence = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                ProposedChange = table.Column<string>(type: "nvarchar(max)", nullable: false),
                Status = table.Column<int>(type: "int", nullable: false),
                ReviewedByUserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                ReviewNotes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                CreatedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                ReviewedUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_AiResearchSuggestions", x => x.Id);
                table.ForeignKey("FK_AiResearchSuggestions_People_PersonId", x => x.PersonId, "People", "Id", onDelete: ReferentialAction.SetNull);
                table.ForeignKey("FK_AiResearchSuggestions_FamilyBranches_FamilyBranchId", x => x.FamilyBranchId, "FamilyBranches", "Id", onDelete: ReferentialAction.SetNull);
            });

        migrationBuilder.CreateIndex("IX_ResearchTasks_Status", "ResearchTasks", "Status");
        migrationBuilder.CreateIndex("IX_ResearchTasks_PersonId", "ResearchTasks", "PersonId");
        migrationBuilder.CreateIndex("IX_ResearchTasks_FamilyBranchId", "ResearchTasks", "FamilyBranchId");
        migrationBuilder.CreateIndex("IX_AiResearchSuggestions_Status", "AiResearchSuggestions", "Status");
        migrationBuilder.CreateIndex("IX_AiResearchSuggestions_PersonId", "AiResearchSuggestions", "PersonId");
        migrationBuilder.CreateIndex("IX_AiResearchSuggestions_FamilyBranchId", "AiResearchSuggestions", "FamilyBranchId");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("AiResearchSuggestions");
        migrationBuilder.DropTable("ResearchTasks");
    }
}
