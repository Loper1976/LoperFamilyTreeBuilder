using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace LoperFamilyTreeBuilder.Data;

public sealed class FamilyTreeDbContext : DbContext
{
    public FamilyTreeDbContext(DbContextOptions<FamilyTreeDbContext> options)
        : base(options)
    {
    }

    public DbSet<Person> People => Set<Person>();

    public DbSet<PersonIdentifier> PersonIdentifiers => Set<PersonIdentifier>();

    public DbSet<FamilyBranch> FamilyBranches => Set<FamilyBranch>();

    public DbSet<BranchMembership> BranchMemberships => Set<BranchMembership>();

    public DbSet<ParentChildRelationship> ParentChildRelationships =>
        Set<ParentChildRelationship>();

    public DbSet<CoupleRelationship> CoupleRelationships =>
        Set<CoupleRelationship>();

    public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();

    public DbSet<ArchiveMediaFile> ArchiveMediaFiles => Set<ArchiveMediaFile>();

    public DbSet<PersonMediaLink> PersonMediaLinks => Set<PersonMediaLink>();

    public DbSet<SourceRecord> SourceRecords => Set<SourceRecord>();

    public DbSet<CitationRecord> CitationRecords => Set<CitationRecord>();

    public DbSet<DocumentTranscription> DocumentTranscriptions => Set<DocumentTranscription>();

    public DbSet<GedcomImportSession> GedcomImportSessions => Set<GedcomImportSession>();

    public DbSet<GedcomImportIssue> GedcomImportIssues => Set<GedcomImportIssue>();

    public DbSet<MedicalConditionRecord> MedicalConditionRecords => Set<MedicalConditionRecord>();

    public DbSet<MedicalEventRecord> MedicalEventRecords => Set<MedicalEventRecord>();

    public DbSet<CauseOfDeathRecord> CauseOfDeathRecords => Set<CauseOfDeathRecord>();

    public DbSet<MedicalEvidenceLink> MedicalEvidenceLinks => Set<MedicalEvidenceLink>();

    public DbSet<CemeteryRecord> CemeteryRecords => Set<CemeteryRecord>();

    public DbSet<BurialRecord> BurialRecords => Set<BurialRecord>();

    public DbSet<MilitaryServiceRecord> MilitaryServiceRecords => Set<MilitaryServiceRecord>();

    public DbSet<FamilyStoryRecord> FamilyStoryRecords => Set<FamilyStoryRecord>();

    public DbSet<TimelineEventRecord> TimelineEventRecords => Set<TimelineEventRecord>();

    public DbSet<FamilyUser> FamilyUsers => Set<FamilyUser>();

    public DbSet<UserRoleMembership> UserRoleMemberships => Set<UserRoleMembership>();

    public DbSet<UserInvitation> UserInvitations => Set<UserInvitation>();

    public DbSet<BranchPermission> BranchPermissions => Set<BranchPermission>();

    public DbSet<FamilySubmission> FamilySubmissions => Set<FamilySubmission>();

    public DbSet<ResearchTaskRecord> ResearchTasks => Set<ResearchTaskRecord>();

    public DbSet<AiResearchSuggestion> AiResearchSuggestions => Set<AiResearchSuggestion>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.ApplyConfigurationsFromAssembly(
            typeof(FamilyTreeDbContext).Assembly);
    }
}
