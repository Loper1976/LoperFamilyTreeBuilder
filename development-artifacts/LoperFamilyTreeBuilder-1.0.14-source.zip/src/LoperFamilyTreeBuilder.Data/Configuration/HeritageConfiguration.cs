using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class CemeteryRecordConfiguration : IEntityTypeConfiguration<CemeteryRecord>
{
    public void Configure(EntityTypeBuilder<CemeteryRecord> builder)
    {
        builder.ToTable("CemeteryRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Name).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Address).HasMaxLength(1000).IsRequired();
        builder.Property(x => x.City).HasMaxLength(300).IsRequired();
        builder.Property(x => x.StateRegion).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Country).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Latitude).HasPrecision(10, 7);
        builder.Property(x => x.Longitude).HasPrecision(10, 7);
        builder.Property(x => x.BoundaryNotes).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Notes).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.Name);
    }
}

public sealed class BurialRecordConfiguration : IEntityTypeConfiguration<BurialRecord>
{
    public void Configure(EntityTypeBuilder<BurialRecord> builder)
    {
        builder.ToTable("BurialRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Section).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Plot).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Row).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Grave).HasMaxLength(300).IsRequired();
        builder.Property(x => x.MarkerInscription).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Latitude).HasPrecision(10, 7);
        builder.Property(x => x.Longitude).HasPrecision(10, 7);
        builder.Property(x => x.VisitStatus).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Notes).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.CemeteryId);
        builder.HasIndex(x => new { x.CemeteryId, x.Section, x.Plot, x.Row, x.Grave });
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
        builder.HasOne(x => x.Cemetery).WithMany().HasForeignKey(x => x.CemeteryId).OnDelete(DeleteBehavior.Restrict);
    }
}

public sealed class MilitaryServiceRecordConfiguration : IEntityTypeConfiguration<MilitaryServiceRecord>
{
    public void Configure(EntityTypeBuilder<MilitaryServiceRecord> builder)
    {
        builder.ToTable("MilitaryServiceRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Branch).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Component).HasMaxLength(300).IsRequired();
        builder.Property(x => x.RankRating).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Specialty).HasMaxLength(500).IsRequired();
        builder.Property(x => x.ServiceNumber).HasMaxLength(300).IsRequired();
        builder.Property(x => x.UnitsShipsDutyStations).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.WarsCampaignsDeployments).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.AwardsQualifications).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Discharge).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Notes).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.Branch);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class FamilyStoryRecordConfiguration : IEntityTypeConfiguration<FamilyStoryRecord>
{
    public void Configure(EntityTypeBuilder<FamilyStoryRecord> builder)
    {
        builder.ToTable("FamilyStoryRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Title).HasMaxLength(500).IsRequired();
        builder.Property(x => x.OriginalText).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.EditedPublicationText).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Contributor).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Notes).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.Title);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.SetNull);
    }
}

public sealed class TimelineEventRecordConfiguration : IEntityTypeConfiguration<TimelineEventRecord>
{
    public void Configure(EntityTypeBuilder<TimelineEventRecord> builder)
    {
        builder.ToTable("TimelineEventRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.EventType).HasMaxLength(300).IsRequired();
        builder.Property(x => x.Title).HasMaxLength(500).IsRequired();
        builder.Property(x => x.PlaceName).HasMaxLength(1000).IsRequired();
        builder.Property(x => x.Latitude).HasPrecision(10, 7);
        builder.Property(x => x.Longitude).HasPrecision(10, 7);
        builder.Property(x => x.Description).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.SourceSummary).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.EventDate);
        builder.HasIndex(x => x.ApproximateYear);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
    }
}
