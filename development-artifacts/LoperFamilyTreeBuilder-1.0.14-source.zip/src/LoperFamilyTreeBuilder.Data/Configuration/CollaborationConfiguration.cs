using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class FamilyUserConfiguration : IEntityTypeConfiguration<FamilyUser>
{
    public void Configure(EntityTypeBuilder<FamilyUser> builder)
    {
        builder.ToTable("FamilyUsers"); builder.HasKey(x=>x.Id);
        builder.Property(x=>x.Email).HasMaxLength(500).IsRequired(); builder.Property(x=>x.NormalizedEmail).HasMaxLength(500).IsRequired();
        builder.Property(x=>x.DisplayName).HasMaxLength(500).IsRequired(); builder.Property(x=>x.PasswordHash).HasMaxLength(2000).IsRequired();
        builder.HasIndex(x=>x.NormalizedEmail).IsUnique();
    }
}

public sealed class UserRoleMembershipConfiguration : IEntityTypeConfiguration<UserRoleMembership>
{
    public void Configure(EntityTypeBuilder<UserRoleMembership> builder)
    {
        builder.ToTable("UserRoleMemberships"); builder.HasKey(x=>x.Id); builder.Property(x=>x.Role).HasConversion<int>();
        builder.HasIndex(x=>new{x.FamilyUserId,x.Role}).IsUnique();
        builder.HasOne(x=>x.FamilyUser).WithMany().HasForeignKey(x=>x.FamilyUserId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class UserInvitationConfiguration : IEntityTypeConfiguration<UserInvitation>
{
    public void Configure(EntityTypeBuilder<UserInvitation> builder)
    {
        builder.ToTable("UserInvitations"); builder.HasKey(x=>x.Id); builder.Property(x=>x.Email).HasMaxLength(500).IsRequired();
        builder.Property(x=>x.NormalizedEmail).HasMaxLength(500).IsRequired(); builder.Property(x=>x.IntendedRole).HasConversion<int>();
        builder.Property(x=>x.TokenHash).HasMaxLength(128).IsRequired(); builder.HasIndex(x=>x.TokenHash).IsUnique(); builder.HasIndex(x=>x.NormalizedEmail);
        builder.Ignore(x=>x.IsOpen);
    }
}

public sealed class BranchPermissionConfiguration : IEntityTypeConfiguration<BranchPermission>
{
    public void Configure(EntityTypeBuilder<BranchPermission> builder)
    {
        builder.ToTable("BranchPermissions"); builder.HasKey(x=>x.Id); builder.HasIndex(x=>new{x.FamilyUserId,x.FamilyBranchId}).IsUnique();
        builder.HasOne(x=>x.FamilyUser).WithMany().HasForeignKey(x=>x.FamilyUserId).OnDelete(DeleteBehavior.Cascade);
        builder.HasOne(x=>x.FamilyBranch).WithMany().HasForeignKey(x=>x.FamilyBranchId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class FamilySubmissionConfiguration : IEntityTypeConfiguration<FamilySubmission>
{
    public void Configure(EntityTypeBuilder<FamilySubmission> builder)
    {
        builder.ToTable("FamilySubmissions"); builder.HasKey(x=>x.Id); builder.Property(x=>x.SubmissionType).HasConversion<int>(); builder.Property(x=>x.Status).HasConversion<int>();
        builder.Property(x=>x.Subject).HasMaxLength(1000).IsRequired(); builder.Property(x=>x.Details).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x=>x.OriginalFileName).HasMaxLength(1000).IsRequired(); builder.Property(x=>x.StoredRelativePath).HasMaxLength(2000).IsRequired();
        builder.Property(x=>x.Sha256).HasMaxLength(64).IsRequired(); builder.Property(x=>x.ReviewNotes).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x=>x.Status); builder.HasIndex(x=>x.SubmittedByUserId); builder.HasIndex(x=>x.TargetPersonId);
        builder.HasOne(x=>x.SubmittedByUser).WithMany().HasForeignKey(x=>x.SubmittedByUserId).OnDelete(DeleteBehavior.Restrict);
        builder.HasOne(x=>x.TargetPerson).WithMany().HasForeignKey(x=>x.TargetPersonId).OnDelete(DeleteBehavior.SetNull);
    }
}
