using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class CoupleRelationshipConfiguration :
    IEntityTypeConfiguration<CoupleRelationship>
{
    public void Configure(EntityTypeBuilder<CoupleRelationship> builder)
    {
        builder.ToTable("CoupleRelationships");

        builder.HasKey(relationship => relationship.Id);

        builder.Property(relationship => relationship.RelationshipType)
            .HasConversion<int>()
            .IsRequired();

        builder.Property(relationship => relationship.Notes)
            .HasMaxLength(4000);

        builder.HasIndex(relationship => relationship.PersonAId);
        builder.HasIndex(relationship => relationship.PersonBId);

        builder.HasIndex(relationship => new
        {
            relationship.PersonAId,
            relationship.PersonBId
        })
        .IsUnique();

        builder.HasOne(relationship => relationship.PersonA)
            .WithMany()
            .HasForeignKey(relationship => relationship.PersonAId)
            .OnDelete(DeleteBehavior.NoAction);

        builder.HasOne(relationship => relationship.PersonB)
            .WithMany()
            .HasForeignKey(relationship => relationship.PersonBId)
            .OnDelete(DeleteBehavior.NoAction);
    }
}
