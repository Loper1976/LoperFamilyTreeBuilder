using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class ResearchTaskRecordConfiguration : IEntityTypeConfiguration<ResearchTaskRecord>
{
    public void Configure(EntityTypeBuilder<ResearchTaskRecord> builder)
    {
        builder.ToTable("ResearchTasks");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.ResearchQuestion).HasMaxLength(2000).IsRequired();
        builder.Property(x => x.AssignedResearcher).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Status).HasConversion<int>();
        builder.Property(x => x.RepositorySearched).HasMaxLength(1000).IsRequired();
        builder.Property(x => x.SearchResults).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.NegativeSearches).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Notes).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Sources).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.FollowUpAction).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.Status);
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.FamilyBranchId);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.SetNull);
        builder.HasOne(x => x.FamilyBranch).WithMany().HasForeignKey(x => x.FamilyBranchId).OnDelete(DeleteBehavior.SetNull);
    }
}

public sealed class AiResearchSuggestionConfiguration : IEntityTypeConfiguration<AiResearchSuggestion>
{
    public void Configure(EntityTypeBuilder<AiResearchSuggestion> builder)
    {
        builder.ToTable("AiResearchSuggestions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.SuggestionType).HasConversion<int>();
        builder.Property(x => x.Prompt).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Result).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.SourcesUsed).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Confidence).HasMaxLength(200).IsRequired();
        builder.Property(x => x.ProposedChange).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Status).HasConversion<int>();
        builder.Property(x => x.ReviewNotes).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.Status);
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.FamilyBranchId);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.SetNull);
        builder.HasOne(x => x.FamilyBranch).WithMany().HasForeignKey(x => x.FamilyBranchId).OnDelete(DeleteBehavior.SetNull);
    }
}
