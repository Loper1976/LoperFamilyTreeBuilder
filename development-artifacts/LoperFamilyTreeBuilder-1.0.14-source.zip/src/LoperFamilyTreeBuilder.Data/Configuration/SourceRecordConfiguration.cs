using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class SourceRecordConfiguration : IEntityTypeConfiguration<SourceRecord>
{
    public void Configure(EntityTypeBuilder<SourceRecord> builder)
    {
        builder.ToTable("SourceRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Title).HasMaxLength(1000).IsRequired();
        builder.Property(x => x.Repository).HasMaxLength(500);
        builder.Property(x => x.CallNumber).HasMaxLength(500);
        builder.Property(x => x.Url).HasMaxLength(2000);
        builder.Property(x => x.Classification).HasConversion<int>();
        builder.Property(x => x.EvidenceQuality).HasConversion<int>();
        builder.Property(x => x.Confidence).HasMaxLength(100);
        builder.Property(x => x.Notes).HasMaxLength(4000);
        builder.HasIndex(x => x.Title);
        builder.HasIndex(x => x.Repository);
    }
}
