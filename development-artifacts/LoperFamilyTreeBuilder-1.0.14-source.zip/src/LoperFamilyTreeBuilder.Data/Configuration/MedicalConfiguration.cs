using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class MedicalConditionRecordConfiguration : IEntityTypeConfiguration<MedicalConditionRecord>
{
    public void Configure(EntityTypeBuilder<MedicalConditionRecord> builder)
    {
        builder.ToTable("MedicalConditionRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.ConditionName).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Status).HasConversion<int>().IsRequired();
        builder.Property(x => x.EvidenceStatus).HasConversion<int>().IsRequired();
        builder.Property(x => x.Severity).HasMaxLength(200).IsRequired();
        builder.Property(x => x.TreatingProvider).HasMaxLength(500).IsRequired();
        builder.Property(x => x.TreatingFacility).HasMaxLength(500).IsRequired();
        builder.Property(x => x.PrivateNotes).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.PrivacyLevel).HasConversion<int>().IsRequired();
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.ConditionName);
        builder.HasIndex(x => x.EvidenceStatus);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class MedicalEventRecordConfiguration : IEntityTypeConfiguration<MedicalEventRecord>
{
    public void Configure(EntityTypeBuilder<MedicalEventRecord> builder)
    {
        builder.ToTable("MedicalEventRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.EventType).HasConversion<int>().IsRequired();
        builder.Property(x => x.Title).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Description).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.TreatingProvider).HasMaxLength(500).IsRequired();
        builder.Property(x => x.TreatingFacility).HasMaxLength(500).IsRequired();
        builder.Property(x => x.EvidenceStatus).HasConversion<int>().IsRequired();
        builder.Property(x => x.PrivateNotes).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.PrivacyLevel).HasConversion<int>().IsRequired();
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.EventType);
        builder.HasIndex(x => x.EventDate);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class CauseOfDeathRecordConfiguration : IEntityTypeConfiguration<CauseOfDeathRecord>
{
    public void Configure(EntityTypeBuilder<CauseOfDeathRecord> builder)
    {
        builder.ToTable("CauseOfDeathRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.PrimaryCause).HasMaxLength(1000).IsRequired();
        builder.Property(x => x.SecondaryCauses).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.ContributingConditions).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.EvidenceStatus).HasConversion<int>().IsRequired();
        builder.Property(x => x.PrivateNotes).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.PrivacyLevel).HasConversion<int>().IsRequired();
        builder.HasIndex(x => x.PersonId).IsUnique();
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
    }
}

public sealed class MedicalEvidenceLinkConfiguration : IEntityTypeConfiguration<MedicalEvidenceLink>
{
    public void Configure(EntityTypeBuilder<MedicalEvidenceLink> builder)
    {
        builder.ToTable("MedicalEvidenceLinks");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.RecordType).HasConversion<int>().IsRequired();
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => new { x.RecordType, x.RecordId });
        builder.HasIndex(x => x.CitationRecordId);
        builder.HasIndex(x => x.MediaFileId);
    }
}
