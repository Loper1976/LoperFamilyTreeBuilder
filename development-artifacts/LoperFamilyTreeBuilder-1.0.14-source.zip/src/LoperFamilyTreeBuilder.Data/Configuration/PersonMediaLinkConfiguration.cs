using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class PersonMediaLinkConfiguration : IEntityTypeConfiguration<PersonMediaLink>
{
    public void Configure(EntityTypeBuilder<PersonMediaLink> builder)
    {
        builder.ToTable("PersonMediaLinks");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Role).HasConversion<int>();
        builder.Property(x => x.Notes).HasMaxLength(2000);
        builder.HasIndex(x => new { x.PersonId, x.MediaFileId }).IsUnique();
        builder.HasIndex(x => x.MediaFileId);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
        builder.HasOne(x => x.MediaFile).WithMany().HasForeignKey(x => x.MediaFileId).OnDelete(DeleteBehavior.Cascade);
    }
}
