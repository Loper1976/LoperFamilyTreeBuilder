using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class DocumentTranscriptionConfiguration : IEntityTypeConfiguration<DocumentTranscription>
{
    public void Configure(EntityTypeBuilder<DocumentTranscription> builder)
    {
        builder.ToTable("DocumentTranscriptions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Text).HasColumnType("nvarchar(max)");
        builder.Property(x => x.Origin).HasConversion<int>();
        builder.Property(x => x.Actor).HasMaxLength(250);
        builder.HasIndex(x => x.MediaFileId).IsUnique();
    }
}
