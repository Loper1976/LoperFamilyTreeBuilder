using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class GedcomImportSessionConfiguration : IEntityTypeConfiguration<GedcomImportSession>
{
    public void Configure(EntityTypeBuilder<GedcomImportSession> builder)
    {
        builder.ToTable("GedcomImportSessions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.OriginalFileName).HasMaxLength(500).IsRequired();
        builder.Property(x => x.StoredRelativePath).HasMaxLength(1000).IsRequired();
        builder.Property(x => x.Sha256).HasMaxLength(64).IsRequired();
        builder.Property(x => x.Status).HasConversion<int>().IsRequired();
        builder.Property(x => x.ImportPlanJson).HasColumnType("nvarchar(max)").IsRequired();
        builder.Property(x => x.Notes).HasMaxLength(4000).IsRequired();
        builder.Property(x => x.BackupFilePath).HasMaxLength(1000);
        builder.HasIndex(x => x.CreatedUtc);
        builder.HasIndex(x => x.Status);
        builder.HasIndex(x => x.Sha256);
    }
}
