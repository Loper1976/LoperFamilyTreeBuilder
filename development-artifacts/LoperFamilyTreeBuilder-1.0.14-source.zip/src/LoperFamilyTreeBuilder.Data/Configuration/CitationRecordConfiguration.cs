using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class CitationRecordConfiguration : IEntityTypeConfiguration<CitationRecord>
{
    public void Configure(EntityTypeBuilder<CitationRecord> builder)
    {
        builder.ToTable("CitationRecords");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.FactOrSubject).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Position).HasConversion<int>();
        builder.Property(x => x.PageOrCallNumber).HasMaxLength(500);
        builder.Property(x => x.CitationText).HasMaxLength(4000);
        builder.Property(x => x.Notes).HasMaxLength(4000);
        builder.HasIndex(x => x.PersonId);
        builder.HasIndex(x => x.SourceRecordId);
        builder.HasIndex(x => x.Position);
        builder.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId).OnDelete(DeleteBehavior.Cascade);
        builder.HasOne(x => x.SourceRecord).WithMany().HasForeignKey(x => x.SourceRecordId).OnDelete(DeleteBehavior.NoAction);
    }
}
