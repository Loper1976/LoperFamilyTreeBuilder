using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class GedcomImportIssueConfiguration : IEntityTypeConfiguration<GedcomImportIssue>
{
    public void Configure(EntityTypeBuilder<GedcomImportIssue> builder)
    {
        builder.ToTable("GedcomImportIssues");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.IssueType).HasConversion<int>().IsRequired();
        builder.Property(x => x.RecordPointer).HasMaxLength(100).IsRequired();
        builder.Property(x => x.Message).HasMaxLength(2000).IsRequired();
        builder.Property(x => x.Details).HasColumnType("nvarchar(max)").IsRequired();
        builder.HasIndex(x => x.ImportSessionId);
        builder.HasIndex(x => x.IssueType);
        builder.HasOne(x => x.ImportSession)
            .WithMany()
            .HasForeignKey(x => x.ImportSessionId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
