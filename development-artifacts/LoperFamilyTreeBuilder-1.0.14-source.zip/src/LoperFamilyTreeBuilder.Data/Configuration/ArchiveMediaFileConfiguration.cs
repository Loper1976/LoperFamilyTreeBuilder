using LoperFamilyTreeBuilder.Core.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoperFamilyTreeBuilder.Data.Configuration;

public sealed class ArchiveMediaFileConfiguration : IEntityTypeConfiguration<ArchiveMediaFile>
{
    public void Configure(EntityTypeBuilder<ArchiveMediaFile> builder)
    {
        builder.ToTable("ArchiveMediaFiles");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.MediaType).HasConversion<int>();
        builder.Property(x => x.OriginalFileName).HasMaxLength(500).IsRequired();
        builder.Property(x => x.StoredRelativePath).HasMaxLength(1000).IsRequired();
        builder.Property(x => x.MimeType).HasMaxLength(250).IsRequired();
        builder.Property(x => x.Sha256).HasMaxLength(64).IsRequired();
        builder.Property(x => x.Caption).HasMaxLength(2000);
        builder.Property(x => x.DeviceOrCamera).HasMaxLength(500);
        builder.Property(x => x.Orientation).HasMaxLength(100);
        builder.Property(x => x.MetadataSource).HasMaxLength(250);
        builder.Property(x => x.Photographer).HasMaxLength(500);
        builder.Property(x => x.Owner).HasMaxLength(500);
        builder.Property(x => x.Rights).HasMaxLength(1000);
        builder.Property(x => x.DocumentType).HasMaxLength(250);
        builder.Property(x => x.Latitude).HasPrecision(9, 6);
        builder.Property(x => x.Longitude).HasPrecision(9, 6);
        builder.HasIndex(x => x.Sha256);
        builder.HasIndex(x => x.MediaType);
        builder.HasIndex(x => x.CreatedUtc);
    }
}
