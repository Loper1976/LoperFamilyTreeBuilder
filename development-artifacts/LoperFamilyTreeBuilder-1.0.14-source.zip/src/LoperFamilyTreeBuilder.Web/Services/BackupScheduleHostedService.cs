using LoperFamilyTreeBuilder.Data.Services;

namespace LoperFamilyTreeBuilder.Web.Services;

public sealed class BackupScheduleHostedService(
    IServiceScopeFactory scopeFactory,
    ILogger<BackupScheduleHostedService> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await Task.Delay(TimeSpan.FromSeconds(20), stoppingToken);
            await using var scope = scopeFactory.CreateAsyncScope();
            var backups = scope.ServiceProvider.GetRequiredService<AdvancedBackupService>();
            await backups.EnsureScheduledBackupAsync(stoppingToken);
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Automatic backup check failed.");
        }
    }
}
