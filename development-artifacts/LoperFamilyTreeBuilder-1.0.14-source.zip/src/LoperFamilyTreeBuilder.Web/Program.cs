using System.Security.Claims;
using LoperFamilyTreeBuilder.Data;
using LoperFamilyTreeBuilder.Data.Services;
using LoperFamilyTreeBuilder.Infrastructure.Configuration;
using LoperFamilyTreeBuilder.Web.Components;
using LoperFamilyTreeBuilder.Web.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.HttpOverrides;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);
var hostedMode = IsHostedMode();

builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.AccessDeniedPath = "/login";
        options.Cookie.Name = "LoperFamilyTreeBuilder.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.Cookie.SecurePolicy = hostedMode
            ? CookieSecurePolicy.Always
            : CookieSecurePolicy.SameAsRequest;
        options.SlidingExpiration = true;
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
    });
builder.Services.AddAuthorization();
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    options.KnownNetworks.Clear();
    options.KnownProxies.Clear();
});

builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("auth", limiter =>
    {
        limiter.PermitLimit = 20;
        limiter.Window = TimeSpan.FromMinutes(5);
        limiter.QueueLimit = 0;
        limiter.AutoReplenishment = true;
    });
});

builder.Services.AddSingleton<ApplicationPaths>();
builder.Services.AddSingleton<ArchiveConfigurationStore>();
builder.Services.AddFamilyTreeData();
builder.Services.AddSingleton<ActiveCircuitTracker>();
builder.Services.AddSingleton<Microsoft.AspNetCore.Components.Server.Circuits.CircuitHandler>(sp => sp.GetRequiredService<ActiveCircuitTracker>());
if (!hostedMode)
    builder.Services.AddHostedService<IdleShutdownService>();
builder.Services.AddHostedService<BackupScheduleHostedService>();

var app = builder.Build();
if (!app.Environment.IsDevelopment())
    app.UseExceptionHandler("/Error", createScopeForErrors: true);

if (hostedMode)
{
    app.UseForwardedHeaders();
    app.UseHttpsRedirection();
    app.UseHsts();
}

app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();
app.Use(async (context, next) =>
{
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-Frame-Options"] = "DENY";
    context.Response.Headers["Referrer-Policy"] = "same-origin";
    await next();
});
app.UseAntiforgery();

app.MapGet("/health", () => Results.Ok(new { application = "Loper Family Tree Builder", version = "1.0.14", status = "ok", utc = DateTimeOffset.UtcNow }));

app.MapGet("/health/ready", async (HostingReadinessService readiness, CancellationToken cancellationToken) =>
{
    var report = await readiness.GetReportAsync(cancellationToken);
    var payload = new
    {
        application = "Loper Family Tree Builder",
        version = "1.0.14",
        hostedMode = report.HostedMode,
        ready = report.IsReady,
        checks = report.Checks.Select(x => new { x.Name, x.Passed, x.Required })
    };

    if (report.IsReady)
        return Results.Ok(payload);

    return Results.Json(payload, statusCode: StatusCodes.Status503ServiceUnavailable);
}).AllowAnonymous();


app.MapGet("/health/release", async (SystemDiagnosticsService diagnostics, HostingReadinessService hosting, CancellationToken cancellationToken) =>
{
    var system = await diagnostics.GetReportAsync(cancellationToken);
    var hosted = await hosting.GetReportAsync(cancellationToken);
    var localReady = system.Checks.Where(x => x.Required).All(x => x.Passed);
    var payload = new
    {
        application = "Loper Family Tree Builder",
        version = "1.0.14",
        release = "production-baseline",
        localReady,
        hostedMode = hosted.HostedMode,
        hostedReady = hosted.IsReady,
        installerSigning = "verify-external-authenticode-signature",
        utc = DateTimeOffset.UtcNow
    };

    if (localReady)
        return Results.Ok(payload);

    return Results.Json(payload, statusCode: StatusCodes.Status503ServiceUnavailable);
}).AllowAnonymous();
app.MapPost("/account/bootstrap", async (HttpContext http, UserAdministrationService users, CancellationToken ct) =>
{
    var form = await http.Request.ReadFormAsync(ct);
    try
    {
        var user = await users.CreateFirstOwnerAsync(form["email"].ToString(), form["displayName"].ToString(), form["password"].ToString(), ct);
        await SignInAsync(http, user);
        return Results.Redirect("/");
    }
    catch (Exception ex) { return Results.Content($"<h1>Project Owner setup failed</h1><p>{System.Net.WebUtility.HtmlEncode(ex.Message)}</p><p><a href='/owner-setup'>Return</a></p>", "text/html"); }
}).DisableAntiforgery().RequireRateLimiting("auth");

app.MapPost("/account/login", async (HttpContext http, UserAdministrationService users, CancellationToken ct) =>
{
    var form = await http.Request.ReadFormAsync(ct);
    var user = await users.AuthenticateAsync(form["email"].ToString(), form["password"].ToString(), ct);
    if (user is null) return Results.Redirect("/login?failed=1");
    await SignInAsync(http, user);
    return Results.Redirect("/");
}).DisableAntiforgery().RequireRateLimiting("auth");

app.MapPost("/account/logout", async (HttpContext http) =>
{
    await http.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Redirect("/login");
}).DisableAntiforgery();

app.MapGet("/archive/media/{mediaId:guid}", async (Guid mediaId, PersonArchiveService archiveService, CancellationToken cancellationToken) =>
{
    var resolved = await archiveService.ResolveMediaAsync(mediaId, cancellationToken);
    if (resolved is null || !File.Exists(resolved.Value.FullPath)) return Results.NotFound();
    return Results.File(resolved.Value.FullPath, resolved.Value.MimeType, fileDownloadName: null, enableRangeProcessing: true);
});

app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

try { await app.Services.InitializeFamilyTreeDatabaseAsync(); }
catch (Exception ex) { app.Logger.LogCritical(ex, "The local genealogy database could not be initialized."); throw; }

app.Run();

static bool IsHostedMode()
{
    var value = Environment.GetEnvironmentVariable("LOPER_HOSTED_MODE");
    return string.Equals(value, "true", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "1", StringComparison.OrdinalIgnoreCase)
        || string.Equals(value, "yes", StringComparison.OrdinalIgnoreCase);
}

static async Task SignInAsync(HttpContext http, LoperFamilyTreeBuilder.Core.Models.AuthenticatedFamilyUser user)
{
    var claims = new List<Claim>
    {
        new(ClaimTypes.NameIdentifier, user.Id.ToString()),
        new("family_user_id", user.Id.ToString()),
        new(ClaimTypes.Name, user.DisplayName),
        new(ClaimTypes.Email, user.Email)
    };
    claims.AddRange(user.Roles.Select(role => new Claim(ClaimTypes.Role, role.ToString())));
    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
    await http.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity), new AuthenticationProperties { IsPersistent = true });
}
