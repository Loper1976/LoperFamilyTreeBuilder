using LoperFamilyTreeBuilder.Infrastructure.Configuration;

namespace LoperFamilyTreeBuilder.Launcher;

internal static class UpgradeBackupService
{
    private const string TargetVersion = "1.0.14";

    public static async Task EnsurePreUpgradeBackupAsync(
        ApplicationPaths paths,
        ArchiveConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        var marker = Path.Combine(paths.LocalApplicationRoot, $"pre-upgrade-backup-{TargetVersion}.complete");
        if (File.Exists(marker) || !File.Exists(paths.DatabaseFile))
            return;

        var timestamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        var destination = Path.Combine(configuration.BackupPath, "PreUpgrade", TargetVersion, timestamp);
        Directory.CreateDirectory(destination);

        var databaseFiles = Directory.GetFiles(paths.DatabaseDirectory)
            .Where(path => path.EndsWith(".mdf", StringComparison.OrdinalIgnoreCase) ||
                           path.EndsWith(".ldf", StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (databaseFiles.Count == 0)
            return;

        foreach (var source in databaseFiles)
        {
            cancellationToken.ThrowIfCancellationRequested();
            File.Copy(source, Path.Combine(destination, Path.GetFileName(source)), overwrite: false);
        }

        if (File.Exists(paths.ConfigurationFile))
            File.Copy(paths.ConfigurationFile, Path.Combine(destination, Path.GetFileName(paths.ConfigurationFile)), overwrite: false);

        var note = $"Pre-upgrade backup created before Loper Family Tree Builder {TargetVersion} database migrations.{Environment.NewLine}" +
                   $"Created: {DateTimeOffset.Now:O}{Environment.NewLine}" +
                   $"Source database: {paths.DatabaseDirectory}{Environment.NewLine}";
        await File.WriteAllTextAsync(Path.Combine(destination, "README-PRE-UPGRADE.txt"), note, cancellationToken);
        await File.WriteAllTextAsync(marker, destination, cancellationToken);
    }
}
