using System.Text.Json;
using LoperFamilyTreeBuilder.Infrastructure.Configuration;
using Microsoft.Data.SqlClient;

namespace LoperFamilyTreeBuilder.Launcher;

internal sealed record RestoreApplyResult(bool Applied, bool Failed, string Message);

internal static class RestoreManager
{
    public static async Task<RestoreApplyResult> TryApplyPendingRestoreAsync(
        ApplicationPaths paths,
        CancellationToken cancellationToken = default)
    {
        if (!File.Exists(paths.PendingRestoreRequestFile))
            return new RestoreApplyResult(false, false, string.Empty);

        PendingRestoreRequest? request;
        try
        {
            request = JsonSerializer.Deserialize<PendingRestoreRequest>(
                await File.ReadAllTextAsync(paths.PendingRestoreRequestFile, cancellationToken));
        }
        catch (Exception ex)
        {
            return new RestoreApplyResult(false, true, "The pending restore request is invalid. " + ex.Message);
        }

        if (request is null || string.IsNullOrWhiteSpace(request.DatabaseBackupFile) || !File.Exists(request.DatabaseBackupFile))
            return new RestoreApplyResult(false, true, "The staged database backup file cannot be found.");

        try
        {
            paths.EnsureLocalDirectories();
            var safetyDirectory = Path.Combine(
                paths.LocalApplicationRoot,
                "RestoreSafety",
                DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            Directory.CreateDirectory(safetyDirectory);

            await using var connection = new SqlConnection(
                "Server=(localdb)\\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true;Database=master;");
            await connection.OpenAsync(cancellationToken);

            if (File.Exists(paths.DatabaseFile))
            {
                var safetyBackup = Path.Combine(safetyDirectory, "LoperFamilyTreeBuilder_PreRestore.bak");
                await ExecuteAsync(connection,
                    $"IF DB_ID(N'LoperFamilyTreeBuilder') IS NOT NULL BACKUP DATABASE [LoperFamilyTreeBuilder] TO DISK = N'{Escape(safetyBackup)}' WITH COPY_ONLY, INIT, CHECKSUM;",
                    cancellationToken);
            }

            var logicalNames = await ReadLogicalNamesAsync(connection, request.DatabaseBackupFile, cancellationToken);
            if (logicalNames.DataName is null || logicalNames.LogName is null)
                throw new InvalidOperationException("The database backup does not contain the expected data and log files.");

            var restoreSql = $"""
                IF DB_ID(N'LoperFamilyTreeBuilder') IS NOT NULL
                    ALTER DATABASE [LoperFamilyTreeBuilder] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
                RESTORE DATABASE [LoperFamilyTreeBuilder]
                    FROM DISK = N'{Escape(request.DatabaseBackupFile)}'
                    WITH REPLACE,
                         MOVE N'{Escape(logicalNames.DataName)}' TO N'{Escape(paths.DatabaseFile)}',
                         MOVE N'{Escape(logicalNames.LogName)}' TO N'{Escape(paths.DatabaseLogFile)}';
                ALTER DATABASE [LoperFamilyTreeBuilder] SET MULTI_USER;
                """;

            await ExecuteAsync(connection, restoreSql, cancellationToken);

            if (!string.IsNullOrWhiteSpace(request.ConfigurationFile) && File.Exists(request.ConfigurationFile))
            {
                if (File.Exists(paths.ConfigurationFile))
                    File.Copy(paths.ConfigurationFile, Path.Combine(safetyDirectory, "archive-settings-before-restore.json"), overwrite: true);
                File.Copy(request.ConfigurationFile, paths.ConfigurationFile, overwrite: true);
            }

            File.Delete(paths.PendingRestoreRequestFile);
            await File.WriteAllTextAsync(
                Path.Combine(safetyDirectory, "RESTORE-SUCCESS.txt"),
                $"Restore completed {DateTimeOffset.Now:O}{Environment.NewLine}Source: {request.BackupDirectory}",
                cancellationToken);

            return new RestoreApplyResult(true, false, "The verified backup was restored successfully.");
        }
        catch (Exception ex)
        {
            return new RestoreApplyResult(false, true, "Restore failed. The pending request was retained for recovery. " + ex.Message);
        }
    }

    private static async Task<(string? DataName, string? LogName)> ReadLogicalNamesAsync(
        SqlConnection connection,
        string backupFile,
        CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = $"RESTORE FILELISTONLY FROM DISK = N'{Escape(backupFile)}';";
        command.CommandTimeout = 120;

        string? dataName = null;
        string? logName = null;

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var logicalName = reader.GetString(reader.GetOrdinal("LogicalName"));
            var type = reader.GetString(reader.GetOrdinal("Type"));
            if (string.Equals(type, "D", StringComparison.OrdinalIgnoreCase))
                dataName ??= logicalName;
            else if (string.Equals(type, "L", StringComparison.OrdinalIgnoreCase))
                logName ??= logicalName;
        }

        return (dataName, logName);
    }

    private static async Task ExecuteAsync(SqlConnection connection, string sql, CancellationToken cancellationToken)
    {
        await using var command = connection.CreateCommand();
        command.CommandText = sql;
        command.CommandTimeout = 300;
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static string Escape(string value) => value.Replace("'", "''", StringComparison.Ordinal);
}
