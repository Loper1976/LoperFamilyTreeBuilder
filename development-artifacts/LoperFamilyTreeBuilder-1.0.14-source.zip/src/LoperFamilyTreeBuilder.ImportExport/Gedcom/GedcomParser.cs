using System.Globalization;
using System.Text;

namespace LoperFamilyTreeBuilder.ImportExport.Gedcom;

public sealed class GedcomParser
{
    private static readonly HashSet<string> SupportedTags = new(StringComparer.OrdinalIgnoreCase)
    {
        "HEAD", "TRLR", "CHAR", "GEDC", "VERS", "FORM", "SOUR", "SUBM",
        "INDI", "FAM", "NAME", "GIVN", "SURN", "SEX", "BIRT", "DEAT", "DATE",
        "FAMC", "FAMS", "HUSB", "WIFE", "CHIL", "MARR", "TITL", "NOTE", "CONT", "CONC"
    };

    public GedcomDocument Parse(byte[] content)
    {
        ArgumentNullException.ThrowIfNull(content);
        var text = Decode(content);
        return Parse(text);
    }

    public GedcomDocument Parse(string text)
    {
        var document = new GedcomDocument();
        if (string.IsNullOrWhiteSpace(text))
        {
            document.Errors.Add("The GEDCOM file is empty.");
            return document;
        }

        GedcomIndividual? currentIndividual = null;
        GedcomFamily? currentFamily = null;
        GedcomSource? currentSource = null;
        string context = string.Empty;

        var lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        document.LineCount = lines.Length;

        for (var index = 0; index < lines.Length; index++)
        {
            var raw = lines[index];
            if (string.IsNullOrWhiteSpace(raw))
                continue;

            if (!TryParseLine(raw, out var level, out var pointer, out var tag, out var value))
            {
                document.Errors.Add($"Line {index + 1}: invalid GEDCOM line format.");
                continue;
            }

            if (!SupportedTags.Contains(tag) && !tag.StartsWith("_", StringComparison.Ordinal))
            {
                document.UnsupportedTags.Add(new GedcomUnsupportedTag(index + 1, tag, value));
            }
            else if (tag.StartsWith("_", StringComparison.Ordinal))
            {
                document.UnsupportedTags.Add(new GedcomUnsupportedTag(index + 1, tag, value));
            }

            if (level == 0)
            {
                currentIndividual = null;
                currentFamily = null;
                currentSource = null;
                context = string.Empty;

                if (tag.Equals("INDI", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(pointer))
                {
                    currentIndividual = new GedcomIndividual { Pointer = pointer };
                    document.Individuals.Add(currentIndividual);
                }
                else if (tag.Equals("FAM", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(pointer))
                {
                    currentFamily = new GedcomFamily { Pointer = pointer };
                    document.Families.Add(currentFamily);
                }
                else if (tag.Equals("SOUR", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(pointer))
                {
                    currentSource = new GedcomSource { Pointer = pointer };
                    document.Sources.Add(currentSource);
                }

                continue;
            }

            if (currentIndividual is not null)
            {
                switch (tag.ToUpperInvariant())
                {
                    case "NAME":
                        currentIndividual.Name = value;
                        ParseName(value, currentIndividual);
                        break;
                    case "GIVN": currentIndividual.GivenName = value.Trim(); break;
                    case "SURN": currentIndividual.Surname = value.Trim(); break;
                    case "SEX": currentIndividual.Sex = value.Trim(); break;
                    case "BIRT": context = "BIRT"; break;
                    case "DEAT": context = "DEAT"; break;
                    case "DATE" when context == "BIRT":
                        currentIndividual.BirthDateText = value;
                        currentIndividual.BirthDate = ParseExactDate(value, document.Warnings, index + 1);
                        break;
                    case "DATE" when context == "DEAT":
                        currentIndividual.DeathDateText = value;
                        currentIndividual.DeathDate = ParseExactDate(value, document.Warnings, index + 1);
                        break;
                    case "FAMC": currentIndividual.FamilyChildPointers.Add(value.Trim()); break;
                    case "FAMS": currentIndividual.FamilySpousePointers.Add(value.Trim()); break;
                }
            }
            else if (currentFamily is not null)
            {
                switch (tag.ToUpperInvariant())
                {
                    case "HUSB": currentFamily.HusbandPointer = value.Trim(); break;
                    case "WIFE": currentFamily.WifePointer = value.Trim(); break;
                    case "CHIL": currentFamily.ChildPointers.Add(value.Trim()); break;
                    case "MARR": context = "MARR"; break;
                    case "DATE" when context == "MARR":
                        currentFamily.MarriageDateText = value;
                        currentFamily.MarriageDate = ParseExactDate(value, document.Warnings, index + 1);
                        break;
                }
            }
            else if (currentSource is not null && tag.Equals("TITL", StringComparison.OrdinalIgnoreCase))
            {
                currentSource.Title = value.Trim();
            }
        }

        if (document.Individuals.Count == 0 && document.Families.Count == 0)
            document.Warnings.Add("No INDI or FAM records were found.");

        var duplicatePointers = document.Individuals
            .GroupBy(i => i.Pointer, StringComparer.OrdinalIgnoreCase)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();
        foreach (var pointer in duplicatePointers)
            document.Errors.Add($"Duplicate individual pointer {pointer}.");

        return document;
    }

    private static bool TryParseLine(
        string raw,
        out int level,
        out string pointer,
        out string tag,
        out string value)
    {
        level = 0;
        pointer = string.Empty;
        tag = string.Empty;
        value = string.Empty;

        var firstSpace = raw.IndexOf(' ');
        if (firstSpace <= 0 || !int.TryParse(raw[..firstSpace], out level))
            return false;

        var remainder = raw[(firstSpace + 1)..].Trim();
        if (remainder.Length == 0)
            return false;

        var parts = remainder.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0)
            return false;

        var tagIndex = 0;
        if (parts[0].StartsWith('@') && parts[0].EndsWith('@'))
        {
            pointer = parts[0];
            tagIndex = 1;
        }

        if (tagIndex >= parts.Length)
            return false;

        tag = parts[tagIndex];
        var tagPosition = remainder.IndexOf(tag, StringComparison.Ordinal);
        var valueStart = tagPosition + tag.Length;
        value = valueStart < remainder.Length ? remainder[valueStart..].Trim() : string.Empty;
        return true;
    }

    private static void ParseName(string name, GedcomIndividual individual)
    {
        var firstSlash = name.IndexOf('/');
        var secondSlash = firstSlash >= 0 ? name.IndexOf('/', firstSlash + 1) : -1;
        if (firstSlash >= 0 && secondSlash > firstSlash)
        {
            individual.GivenName = name[..firstSlash].Trim();
            individual.Surname = name[(firstSlash + 1)..secondSlash].Trim();
        }
        else
        {
            individual.GivenName = name.Trim();
        }
    }

    private static DateOnly? ParseExactDate(string value, List<string> warnings, int lineNumber)
    {
        var normalized = value.Trim();
        var formats = new[] { "d MMM yyyy", "dd MMM yyyy" };
        foreach (var format in formats)
        {
            if (DateOnly.TryParseExact(normalized, format, CultureInfo.InvariantCulture,
                DateTimeStyles.AllowWhiteSpaces, out var date))
                return date;
        }

        if (!string.IsNullOrWhiteSpace(normalized))
            warnings.Add($"Line {lineNumber}: date '{normalized}' is not an exact day-month-year value and will remain review-only.");
        return null;
    }

    private static string Decode(byte[] content)
    {
        if (content.Length >= 3 && content[0] == 0xEF && content[1] == 0xBB && content[2] == 0xBF)
            return Encoding.UTF8.GetString(content, 3, content.Length - 3);

        return Encoding.UTF8.GetString(content);
    }
}
