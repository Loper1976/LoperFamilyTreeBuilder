using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed class CreateMedicalConditionRequest
{
    public Guid PersonId { get; set; }
    public string ConditionName { get; set; } = string.Empty;
    public DateOnly? DiagnosisDate { get; set; }
    public int? ApproximateDiagnosisYear { get; set; }
    public int? AgeAtOnset { get; set; }
    public MedicalConditionStatus Status { get; set; } = MedicalConditionStatus.Unknown;
    public MedicalEvidenceStatus EvidenceStatus { get; set; } = MedicalEvidenceStatus.Unknown;
    public string Severity { get; set; } = string.Empty;
    public bool PotentialHereditaryRelevance { get; set; }
    public string TreatingProvider { get; set; } = string.Empty;
    public string TreatingFacility { get; set; } = string.Empty;
    public string PrivateNotes { get; set; } = string.Empty;
    public MedicalPrivacyLevel PrivacyLevel { get; set; } = MedicalPrivacyLevel.Private;
}

public sealed class CreateMedicalEventRequest
{
    public Guid PersonId { get; set; }
    public MedicalEventType EventType { get; set; } = MedicalEventType.Hospitalization;
    public string Title { get; set; } = string.Empty;
    public DateOnly? EventDate { get; set; }
    public int? ApproximateYear { get; set; }
    public string Description { get; set; } = string.Empty;
    public string TreatingProvider { get; set; } = string.Empty;
    public string TreatingFacility { get; set; } = string.Empty;
    public MedicalEvidenceStatus EvidenceStatus { get; set; } = MedicalEvidenceStatus.Unknown;
    public string PrivateNotes { get; set; } = string.Empty;
    public MedicalPrivacyLevel PrivacyLevel { get; set; } = MedicalPrivacyLevel.Private;
}

public sealed class SaveCauseOfDeathRequest
{
    public Guid PersonId { get; set; }
    public string PrimaryCause { get; set; } = string.Empty;
    public string SecondaryCauses { get; set; } = string.Empty;
    public string ContributingConditions { get; set; } = string.Empty;
    public MedicalEvidenceStatus EvidenceStatus { get; set; } = MedicalEvidenceStatus.Unknown;
    public string PrivateNotes { get; set; } = string.Empty;
    public MedicalPrivacyLevel PrivacyLevel { get; set; } = MedicalPrivacyLevel.Private;
}

public sealed record MedicalConditionListItem(
    Guid Id, string ConditionName, DateOnly? DiagnosisDate, int? ApproximateDiagnosisYear,
    int? AgeAtOnset, MedicalConditionStatus Status, MedicalEvidenceStatus EvidenceStatus,
    string Severity, bool PotentialHereditaryRelevance, string TreatingProvider,
    string TreatingFacility, MedicalPrivacyLevel PrivacyLevel, DateTimeOffset ModifiedUtc);

public sealed record MedicalEventListItem(
    Guid Id, MedicalEventType EventType, string Title, DateOnly? EventDate, int? ApproximateYear,
    string Description, string TreatingProvider, string TreatingFacility,
    MedicalEvidenceStatus EvidenceStatus, MedicalPrivacyLevel PrivacyLevel, DateTimeOffset ModifiedUtc);

public sealed record CauseOfDeathModel(
    Guid Id, string PrimaryCause, string SecondaryCauses, string ContributingConditions,
    MedicalEvidenceStatus EvidenceStatus, MedicalPrivacyLevel PrivacyLevel, DateTimeOffset ModifiedUtc);

public sealed record PersonMedicalHistoryModel(
    Guid PersonId, string DisplayName, string? LegacyNumber, bool IsLiving,
    IReadOnlyList<MedicalConditionListItem> Conditions,
    IReadOnlyList<MedicalEventListItem> Events,
    CauseOfDeathModel? CauseOfDeath);

public sealed record MedicalDashboardSummary(
    int PeopleWithMedicalHistory,
    int Conditions,
    int MedicalEvents,
    int CauseOfDeathRecords,
    int PrivateOrRestrictedRecords);

public sealed record MedicalSearchResult(
    Guid PersonId, string DisplayName, string? LegacyNumber,
    string RecordType, string Subject, string EvidenceStatus, MedicalPrivacyLevel PrivacyLevel);

public sealed record FamilyHealthPatternItem(
    string ConditionName,
    int AffectedPeople,
    int Confirmed,
    int Probable,
    int Suspected,
    int FamilyReported,
    bool AnyPotentialHereditaryFlag);

public sealed record MedicalPedigreePerson(
    Guid PersonId,
    string DisplayName,
    string? LegacyNumber,
    int Generation,
    string RelationshipDirection,
    bool HasCondition,
    MedicalEvidenceStatus? EvidenceStatus);
