using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed class GedcomPreviewRequest
{
    public string OriginalFileName { get; set; } = string.Empty;
    public byte[] Content { get; set; } = Array.Empty<byte>();
}

public sealed record GedcomImportSessionListItem(
    Guid Id,
    string OriginalFileName,
    GedcomImportStatus Status,
    int IndividualCount,
    int FamilyCount,
    int SourceCount,
    int UnsupportedTagCount,
    int DuplicateCandidateCount,
    int ConflictCount,
    DateTimeOffset CreatedUtc,
    DateTimeOffset? ApprovedUtc,
    DateTimeOffset? AppliedUtc);

public sealed record GedcomImportIssueListItem(
    GedcomImportIssueType IssueType,
    string RecordPointer,
    string Message,
    string Details);

public sealed record GedcomImportReviewModel(
    GedcomImportSessionListItem Session,
    IReadOnlyList<GedcomImportIssueListItem> Issues,
    IReadOnlyList<GedcomPlannedPerson> PlannedPeople,
    IReadOnlyList<GedcomPlannedFamily> PlannedFamilies);

public sealed record GedcomPlannedPerson(
    string Pointer,
    string GivenName,
    string Surname,
    string DisplayName,
    DateOnly? BirthDate,
    DateOnly? DeathDate,
    string ExternalId,
    bool IsDuplicate,
    Guid? MatchedPersonId,
    string DuplicateReason,
    bool WillCreate);

public sealed record GedcomPlannedFamily(
    string Pointer,
    string? Spouse1Pointer,
    string? Spouse2Pointer,
    IReadOnlyList<string> ChildPointers,
    DateOnly? MarriageDate,
    bool CanApply,
    string Note);

public sealed record GedcomValidationReport(
    bool IsValid,
    string FileName,
    int LineCount,
    int IndividualCount,
    int FamilyCount,
    int SourceCount,
    IReadOnlyList<string> Errors,
    IReadOnlyList<string> Warnings,
    IReadOnlyList<string> UnsupportedTags);

public sealed record GedcomApplyResult(
    int PeopleCreated,
    int ParentChildRelationshipsCreated,
    int CoupleRelationshipsCreated,
    int SkippedDuplicates,
    string BackupFilePath);
