namespace LoperFamilyTreeBuilder.Core.Models;

public sealed class CreateCemeteryRequest
{
    public string Name { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string StateRegion { get; set; } = string.Empty;
    public string Country { get; set; } = "United States";
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public string BoundaryNotes { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public sealed record CemeteryListItem(Guid Id, string Name, string Address, string City,
    string StateRegion, string Country, decimal? Latitude, decimal? Longitude,
    string BoundaryNotes, string Notes, int Burials);

public sealed class CreateBurialRequest
{
    public Guid PersonId { get; set; }
    public Guid CemeteryId { get; set; }
    public DateOnly? BurialDate { get; set; }
    public string Section { get; set; } = string.Empty;
    public string Plot { get; set; } = string.Empty;
    public string Row { get; set; } = string.Empty;
    public string Grave { get; set; } = string.Empty;
    public string MarkerInscription { get; set; } = string.Empty;
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public bool NeedsMarkerPhoto { get; set; }
    public string VisitStatus { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public sealed record BurialListItem(Guid Id, Guid PersonId, string PersonName, string? LegacyNumber,
    Guid CemeteryId, string CemeteryName, DateOnly? BurialDate, string Section, string Plot,
    string Row, string Grave, string MarkerInscription, decimal? Latitude, decimal? Longitude,
    bool NeedsMarkerPhoto, string VisitStatus, string Notes);

public sealed class CreateMilitaryServiceRequest
{
    public Guid PersonId { get; set; }
    public string Branch { get; set; } = string.Empty;
    public string Component { get; set; } = string.Empty;
    public string RankRating { get; set; } = string.Empty;
    public string Specialty { get; set; } = string.Empty;
    public string ServiceNumber { get; set; } = string.Empty;
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public string UnitsShipsDutyStations { get; set; } = string.Empty;
    public string WarsCampaignsDeployments { get; set; } = string.Empty;
    public string AwardsQualifications { get; set; } = string.Empty;
    public string Discharge { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public sealed record MilitaryServiceListItem(Guid Id, Guid PersonId, string PersonName, string? LegacyNumber,
    string Branch, string Component, string RankRating, string Specialty, DateOnly? StartDate,
    DateOnly? EndDate, string UnitsShipsDutyStations, string WarsCampaignsDeployments,
    string AwardsQualifications, string Discharge, string Notes);

public sealed class CreateFamilyStoryRequest
{
    public Guid? PersonId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string OriginalText { get; set; } = string.Empty;
    public string EditedPublicationText { get; set; } = string.Empty;
    public string Contributor { get; set; } = string.Empty;
    public DateOnly? RecordedDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public sealed record FamilyStoryListItem(Guid Id, Guid? PersonId, string? PersonName, string Title,
    string OriginalText, string EditedPublicationText, string Contributor, DateOnly? RecordedDate,
    string Notes, DateTimeOffset ModifiedUtc);

public sealed class CreateTimelineEventRequest
{
    public Guid PersonId { get; set; }
    public string EventType { get; set; } = "Life Event";
    public string Title { get; set; } = string.Empty;
    public DateOnly? EventDate { get; set; }
    public int? ApproximateYear { get; set; }
    public string PlaceName { get; set; } = string.Empty;
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public string Description { get; set; } = string.Empty;
    public string SourceSummary { get; set; } = string.Empty;
}

public sealed record TimelineEventListItem(Guid Id, Guid PersonId, string PersonName, string? LegacyNumber,
    string EventType, string Title, DateOnly? EventDate, int? ApproximateYear, string PlaceName,
    decimal? Latitude, decimal? Longitude, string Description, string SourceSummary);

public sealed record HeritageMapPoint(string Category, string Label, string PersonName,
    decimal Latitude, decimal Longitude, string Detail);

public sealed record HeritageDashboardSummary(int Cemeteries, int Burials, int MilitaryRecords,
    int Stories, int TimelineEvents, int MappableLocations, int MissingMarkerPhotos);
