using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed record PersonProfileModel(
    Guid Id,
    string GivenName,
    string MiddleName,
    string Surname,
    string Suffix,
    DateOnly? BirthDate,
    DateOnly? DeathDate,
    bool IsLiving,
    string? LegacyNumber,
    IReadOnlyList<FamilyBranchListItem> Branches,
    IReadOnlyList<PersonRelationshipListItem> Parents,
    IReadOnlyList<PersonRelationshipListItem> Children,
    IReadOnlyList<PersonRelationshipListItem> Siblings,
    IReadOnlyList<CoupleRelationshipListItem> Couples,
    IReadOnlyList<AuditHistoryItem> AuditHistory,
    AdjacentPerson? PreviousPerson,
    AdjacentPerson? NextPerson)
{
    public string DisplayName
    {
        get
        {
            var parts = new[] { GivenName, MiddleName, Surname, Suffix }
                .Where(value => !string.IsNullOrWhiteSpace(value));

            return string.Join(" ", parts);
        }
    }

    public int? Age
    {
        get
        {
            if (!BirthDate.HasValue)
                return null;

            var end = DeathDate ?? DateOnly.FromDateTime(DateTime.Today);
            var age = end.Year - BirthDate.Value.Year;

            if (end < BirthDate.Value.AddYears(age))
                age--;

            return Math.Max(0, age);
        }
    }
}

public sealed record PersonRelationshipListItem(
    Guid PersonId,
    string DisplayName,
    DateOnly? BirthDate,
    DateOnly? DeathDate,
    string? LegacyNumber,
    ParentChildRelationshipType RelationshipType);

public sealed record CoupleRelationshipListItem(
    Guid RelationshipId,
    Guid OtherPersonId,
    string DisplayName,
    DateOnly? BirthDate,
    DateOnly? DeathDate,
    string? LegacyNumber,
    CoupleRelationshipType RelationshipType,
    DateOnly? StartDate,
    DateOnly? EndDate,
    string Notes);

public sealed record AuditHistoryItem(
    Guid Id,
    DateTimeOffset OccurredUtc,
    string Action,
    string Actor,
    string Summary,
    string? Reason,
    string? Source);

public sealed record AdjacentPerson(Guid Id, string DisplayName);
