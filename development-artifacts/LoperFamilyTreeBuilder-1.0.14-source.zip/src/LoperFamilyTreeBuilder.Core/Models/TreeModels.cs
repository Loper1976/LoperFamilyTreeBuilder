using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed record TreePersonNode(
    Guid PersonId,
    string DisplayName,
    string? LegacyNumber,
    DateOnly? BirthDate,
    DateOnly? DeathDate,
    int Generation,
    Guid? ConnectedFromPersonId,
    string RelationshipLabel);

public sealed record TreeChartResult(
    Guid StartPersonId,
    string StartPersonName,
    int GenerationDepth,
    IReadOnlyList<TreePersonNode> Nodes);

public sealed record RelationshipPathStep(
    Guid PersonId,
    string DisplayName,
    string? LegacyNumber,
    string ConnectionFromPrevious);

public sealed record RelationshipPathResult(
    bool Found,
    string Description,
    IReadOnlyList<RelationshipPathStep> Steps);

public sealed record TreeReportSummary(
    int People,
    int ParentChildRelationships,
    int CoupleRelationships,
    int PeopleWithLegacyNumbers,
    int Living,
    int Deceased,
    int FamilyBranches);
