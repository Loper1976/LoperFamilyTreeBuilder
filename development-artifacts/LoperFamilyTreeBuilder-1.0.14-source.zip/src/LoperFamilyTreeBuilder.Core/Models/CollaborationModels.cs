using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed record FamilyUserListItem(Guid Id, string Email, string DisplayName, bool IsActive, bool IsLocked,
    IReadOnlyList<FamilyRole> Roles, DateTimeOffset? LastLoginUtc, DateTimeOffset CreatedUtc);

public sealed record AuthenticatedFamilyUser(Guid Id, string Email, string DisplayName, IReadOnlyList<FamilyRole> Roles);

public sealed record InvitationResult(Guid InvitationId, string Email, FamilyRole IntendedRole, string OneTimeToken, DateTimeOffset ExpiresUtc);

public sealed record InvitationListItem(Guid Id, string Email, FamilyRole IntendedRole, DateTimeOffset ExpiresUtc,
    DateTimeOffset? AcceptedUtc, DateTimeOffset? RevokedUtc, bool IsOpen);

public sealed class CreateFamilySubmissionRequest
{
    public Guid SubmittedByUserId { get; set; }
    public Guid? TargetPersonId { get; set; }
    public FamilySubmissionType SubmissionType { get; set; } = FamilySubmissionType.ResearchLead;
    public string Subject { get; set; } = string.Empty;
    public string Details { get; set; } = string.Empty;
    public bool RightsAndPrivacyAccepted { get; set; }
}

public sealed record FamilySubmissionListItem(Guid Id, Guid SubmittedByUserId, string SubmitterName,
    Guid? TargetPersonId, string? TargetPersonName, FamilySubmissionType SubmissionType, string Subject,
    string Details, string OriginalFileName, string Sha256, long FileSizeBytes, bool RightsAndPrivacyAccepted,
    FamilySubmissionStatus Status, string ReviewNotes, DateTimeOffset SubmittedUtc, DateTimeOffset? ReviewedUtc);

public sealed record CollaborationDashboardSummary(int Users, int OpenInvitations, int PendingSubmissions,
    int NeedsClarification, int ApprovedSubmissions);
