namespace LoperFamilyTreeBuilder.Core.Models;

public enum BackupReason
{
    Manual = 1,
    Daily = 2,
    Weekly = 3,
    Monthly = 4,
    BeforeGedcomImport = 5,
    BeforeSoftwareUpdate = 6,
    BeforeStorageMove = 7,
    BeforeRestore = 8,
    ArchivalExport = 9
}

public sealed record BackupManifestEntry(
    string RelativePath,
    string Category,
    long SizeBytes,
    string Sha256);

public sealed class BackupManifest
{
    public string Application { get; set; } = "Loper Family Tree Builder";
    public string ApplicationVersion { get; set; } = string.Empty;
    public BackupReason Reason { get; set; }
    public DateTimeOffset CreatedUtc { get; set; }
    public string DatabaseBackupFile { get; set; } = string.Empty;
    public string ConfigurationFile { get; set; } = string.Empty;
    public bool IncludesArchiveFiles { get; set; }
    public List<BackupManifestEntry> Entries { get; set; } = [];
}

public sealed record BackupCatalogItem(
    string BackupDirectory,
    BackupReason Reason,
    DateTimeOffset CreatedUtc,
    bool IncludesArchiveFiles,
    int FileCount,
    long TotalBytes,
    bool ManifestAvailable);

public sealed record BackupVerificationResult(
    bool IsValid,
    int FilesChecked,
    int MissingFiles,
    int HashMismatches,
    string Message);
