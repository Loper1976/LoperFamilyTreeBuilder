namespace LoperFamilyTreeBuilder.Core.Models;

public sealed record HostingReadinessCheck(
    string Name,
    bool Passed,
    string Detail,
    bool Required);

public sealed record HostingReadinessReport(
    bool HostedMode,
    bool IsReady,
    string PublicBaseUrl,
    IReadOnlyList<HostingReadinessCheck> Checks);
