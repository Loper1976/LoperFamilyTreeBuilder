using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed class MediaUploadRequest
{
    public Guid PersonId { get; set; }
    public ArchiveMediaType MediaType { get; set; }
    public PersonMediaRole Role { get; set; }
    public string OriginalFileName { get; set; } = string.Empty;
    public string MimeType { get; set; } = "application/octet-stream";
    public string Caption { get; set; } = string.Empty;
    public DateTimeOffset? CaptureDateTime { get; set; }
    public bool CaptureDateIsApproximate { get; set; }
    public string DeviceOrCamera { get; set; } = string.Empty;
    public string Orientation { get; set; } = string.Empty;
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public string MetadataSource { get; set; } = "User entered";
    public string Photographer { get; set; } = string.Empty;
    public string Owner { get; set; } = string.Empty;
    public string Rights { get; set; } = string.Empty;
    public string DocumentType { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public sealed record ArchiveMediaListItem(
    Guid Id,
    ArchiveMediaType MediaType,
    PersonMediaRole Role,
    string OriginalFileName,
    string Caption,
    string MimeType,
    long FileSizeBytes,
    string Sha256,
    DateTimeOffset? CaptureDateTime,
    bool CaptureDateIsApproximate,
    string DeviceOrCamera,
    decimal? Latitude,
    decimal? Longitude,
    string Photographer,
    string Owner,
    string Rights,
    string DocumentType,
    DateTimeOffset CreatedUtc,
    bool HasTranscription);

public sealed class CreateSourceRequest
{
    public string Title { get; set; } = string.Empty;
    public string Repository { get; set; } = string.Empty;
    public string CallNumber { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public DateOnly? AccessDate { get; set; }
    public SourceClassification Classification { get; set; } = SourceClassification.Original;
    public EvidenceQuality EvidenceQuality { get; set; } = EvidenceQuality.Unknown;
    public string Confidence { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public Guid? OriginalDocumentMediaFileId { get; set; }
}

public sealed record SourceRecordListItem(
    Guid Id,
    string Title,
    string Repository,
    string CallNumber,
    string Url,
    DateOnly? AccessDate,
    SourceClassification Classification,
    EvidenceQuality EvidenceQuality,
    string Confidence,
    string Notes,
    Guid? OriginalDocumentMediaFileId);

public sealed class CreateCitationRequest
{
    public Guid PersonId { get; set; }
    public Guid SourceRecordId { get; set; }
    public Guid? MediaFileId { get; set; }
    public string FactOrSubject { get; set; } = string.Empty;
    public CitationPosition Position { get; set; } = CitationPosition.Supporting;
    public string PageOrCallNumber { get; set; } = string.Empty;
    public string CitationText { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public sealed record CitationListItem(
    Guid Id,
    Guid SourceRecordId,
    string SourceTitle,
    string Repository,
    string FactOrSubject,
    CitationPosition Position,
    string PageOrCallNumber,
    string CitationText,
    string Notes,
    Guid? MediaFileId,
    DateTimeOffset CreatedUtc);

public sealed record DocumentTranscriptionModel(
    Guid MediaFileId,
    string OriginalFileName,
    string MimeType,
    string Caption,
    string Text,
    TranscriptionOrigin Origin,
    bool IsApproved,
    string Actor,
    DateTimeOffset? ModifiedUtc);

public sealed record ArchiveDashboardCounts(int Photos, int Documents, int Sources);
