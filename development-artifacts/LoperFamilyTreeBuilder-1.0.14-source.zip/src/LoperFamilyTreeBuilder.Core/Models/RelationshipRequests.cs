using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed class AddParentChildRelationshipRequest
{
    public Guid ParentPersonId { get; set; }

    public Guid ChildPersonId { get; set; }

    public ParentChildRelationshipType RelationshipType { get; set; } =
        ParentChildRelationshipType.Biological;

    public string Reason { get; set; } = string.Empty;
}

public sealed class AddCoupleRelationshipRequest
{
    public Guid FirstPersonId { get; set; }

    public Guid SecondPersonId { get; set; }

    public CoupleRelationshipType RelationshipType { get; set; } =
        CoupleRelationshipType.Spouse;

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }

    public string Notes { get; set; } = string.Empty;

    public string Reason { get; set; } = string.Empty;
}

public sealed record PersonLookupItem(
    Guid Id,
    string DisplayName,
    DateOnly? BirthDate,
    DateOnly? DeathDate,
    string? LegacyNumber,
    string? PrimaryBranchName);
