using LoperFamilyTreeBuilder.Core.Entities;

namespace LoperFamilyTreeBuilder.Core.Models;

public sealed class CreateResearchTaskRequest
{
    public Guid? PersonId { get; set; }
    public Guid? FamilyBranchId { get; set; }
    public string ResearchQuestion { get; set; } = string.Empty;
    public string AssignedResearcher { get; set; } = string.Empty;
    public ResearchStatus Status { get; set; } = ResearchStatus.NeedsResearch;
    public string RepositorySearched { get; set; } = string.Empty;
    public DateOnly? SearchDate { get; set; }
    public string SearchResults { get; set; } = string.Empty;
    public string NegativeSearches { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string Sources { get; set; } = string.Empty;
    public string FollowUpAction { get; set; } = string.Empty;
}

public sealed record ResearchTaskListItem(
    Guid Id,
    Guid? PersonId,
    string? PersonName,
    string? LegacyNumber,
    Guid? FamilyBranchId,
    string? FamilyBranchName,
    string ResearchQuestion,
    string AssignedResearcher,
    ResearchStatus Status,
    string RepositorySearched,
    DateOnly? SearchDate,
    string SearchResults,
    string NegativeSearches,
    string Notes,
    string Sources,
    string FollowUpAction,
    DateTimeOffset ModifiedUtc);

public sealed record AiSuggestionListItem(
    Guid Id,
    Guid? PersonId,
    string? PersonName,
    string? LegacyNumber,
    AiSuggestionType SuggestionType,
    string Prompt,
    string Result,
    string SourcesUsed,
    string Confidence,
    string ProposedChange,
    AiSuggestionStatus Status,
    string ReviewNotes,
    DateTimeOffset CreatedUtc,
    DateTimeOffset? ReviewedUtc);

public sealed record ResearchDashboardSummary(
    int OpenResearchTasks,
    int PendingAiSuggestions,
    int ConflictingEvidenceTasks,
    int ArchivedTasks);

public sealed class CreateAiSuggestionRequest
{
    public Guid? PersonId { get; set; }
    public Guid? FamilyBranchId { get; set; }
    public AiSuggestionType SuggestionType { get; set; } = AiSuggestionType.ResearchTarget;
    public string Prompt { get; set; } = string.Empty;
    public string Result { get; set; } = string.Empty;
    public string SourcesUsed { get; set; } = string.Empty;
    public string Confidence { get; set; } = string.Empty;
    public string ProposedChange { get; set; } = string.Empty;
}
