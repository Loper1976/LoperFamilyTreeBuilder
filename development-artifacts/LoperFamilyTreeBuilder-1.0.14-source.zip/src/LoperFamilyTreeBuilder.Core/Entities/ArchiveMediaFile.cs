namespace LoperFamilyTreeBuilder.Core.Entities;

public sealed class ArchiveMediaFile
{
    private ArchiveMediaFile() { }

    public ArchiveMediaFile(
        ArchiveMediaType mediaType,
        string originalFileName,
        string storedRelativePath,
        string mimeType,
        long fileSizeBytes,
        string sha256)
    {
        if (string.IsNullOrWhiteSpace(originalFileName))
            throw new ArgumentException("Original filename is required.", nameof(originalFileName));
        if (string.IsNullOrWhiteSpace(storedRelativePath))
            throw new ArgumentException("Stored archive path is required.", nameof(storedRelativePath));
        if (string.IsNullOrWhiteSpace(sha256))
            throw new ArgumentException("SHA-256 checksum is required.", nameof(sha256));

        Id = Guid.NewGuid();
        MediaType = mediaType;
        OriginalFileName = originalFileName;
        StoredRelativePath = storedRelativePath;
        MimeType = mimeType ?? "application/octet-stream";
        FileSizeBytes = fileSizeBytes;
        Sha256 = sha256;
        IsOriginal = true;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public ArchiveMediaType MediaType { get; private set; }
    public string OriginalFileName { get; private set; } = string.Empty;
    public string StoredRelativePath { get; private set; } = string.Empty;
    public string MimeType { get; private set; } = string.Empty;
    public long FileSizeBytes { get; private set; }
    public string Sha256 { get; private set; } = string.Empty;
    public bool IsOriginal { get; private set; }
    public Guid? DerivativeOfMediaFileId { get; private set; }
    public string Caption { get; private set; } = string.Empty;
    public DateTimeOffset? CaptureDateTime { get; private set; }
    public bool CaptureDateIsApproximate { get; private set; }
    public string DeviceOrCamera { get; private set; } = string.Empty;
    public string Orientation { get; private set; } = string.Empty;
    public decimal? Latitude { get; private set; }
    public decimal? Longitude { get; private set; }
    public string MetadataSource { get; private set; } = string.Empty;
    public string Photographer { get; private set; } = string.Empty;
    public string Owner { get; private set; } = string.Empty;
    public string Rights { get; private set; } = string.Empty;
    public string DocumentType { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }

    public void SetDescriptiveMetadata(
        string caption,
        DateTimeOffset? captureDateTime,
        bool captureDateIsApproximate,
        string deviceOrCamera,
        string orientation,
        decimal? latitude,
        decimal? longitude,
        string metadataSource,
        string photographer,
        string owner,
        string rights,
        string documentType)
    {
        Caption = caption ?? string.Empty;
        CaptureDateTime = captureDateTime;
        CaptureDateIsApproximate = captureDateIsApproximate;
        DeviceOrCamera = deviceOrCamera ?? string.Empty;
        Orientation = orientation ?? string.Empty;
        Latitude = latitude;
        Longitude = longitude;
        MetadataSource = metadataSource ?? string.Empty;
        Photographer = photographer ?? string.Empty;
        Owner = owner ?? string.Empty;
        Rights = rights ?? string.Empty;
        DocumentType = documentType ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}
