namespace LoperFamilyTreeBuilder.Core.Entities;

public sealed class DocumentTranscription
{
    private DocumentTranscription() { }

    public DocumentTranscription(Guid mediaFileId, string text, TranscriptionOrigin origin, string actor)
    {
        Id = Guid.NewGuid();
        MediaFileId = mediaFileId;
        Text = text ?? string.Empty;
        Origin = origin;
        Actor = string.IsNullOrWhiteSpace(actor) ? "Local Application" : actor;
        IsApproved = origin == TranscriptionOrigin.Human;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid MediaFileId { get; private set; }
    public string Text { get; private set; } = string.Empty;
    public TranscriptionOrigin Origin { get; private set; }
    public string Actor { get; private set; } = string.Empty;
    public bool IsApproved { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }

    public void Revise(string text, TranscriptionOrigin origin, string actor, bool approved)
    {
        Text = text ?? string.Empty;
        Origin = origin;
        Actor = string.IsNullOrWhiteSpace(actor) ? "Local Application" : actor;
        IsApproved = approved;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}
