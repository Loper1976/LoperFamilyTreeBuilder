namespace LoperFamilyTreeBuilder.Core.Entities;

public sealed class PersonMediaLink
{
    private PersonMediaLink() { }

    public PersonMediaLink(Guid personId, Guid mediaFileId, PersonMediaRole role, string notes = "")
    {
        Id = Guid.NewGuid();
        PersonId = personId;
        MediaFileId = mediaFileId;
        Role = role;
        Notes = notes ?? string.Empty;
        CreatedUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public Guid MediaFileId { get; private set; }
    public PersonMediaRole Role { get; private set; }
    public string Notes { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public Person Person { get; private set; } = null!;
    public ArchiveMediaFile MediaFile { get; private set; } = null!;
}
