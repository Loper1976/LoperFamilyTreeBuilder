namespace LoperFamilyTreeBuilder.Core.Entities;

public enum SourceClassification
{
    Original = 1,
    Derivative = 2,
    AuthoredNarrative = 3,
    FamilyRecord = 4,
    OnlineDatabase = 5,
    Other = 99
}

public enum EvidenceQuality
{
    Unknown = 0,
    Low = 1,
    Moderate = 2,
    High = 3,
    Primary = 4
}

public enum CitationPosition
{
    Supporting = 1,
    Contradicting = 2,
    Neutral = 3
}
