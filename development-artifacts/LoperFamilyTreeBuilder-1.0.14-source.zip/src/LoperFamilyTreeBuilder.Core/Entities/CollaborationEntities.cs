namespace LoperFamilyTreeBuilder.Core.Entities;

public enum FamilyRole
{
    ProjectOwner = 1,
    Administrator = 2,
    GenealogyEditor = 3,
    Reviewer = 4,
    Contributor = 5,
    Researcher = 6,
    FamilyMember = 7,
    ReadOnlyGuest = 8,
    ServiceAccount = 9
}

public enum FamilySubmissionType
{
    Photo = 1,
    Document = 2,
    Story = 3,
    Correction = 4,
    NewPerson = 5,
    CemeteryInformation = 6,
    GravePhoto = 7,
    Memory = 8,
    ResearchLead = 9
}

public enum FamilySubmissionStatus
{
    Pending = 1,
    Approved = 2,
    Rejected = 3,
    NeedsClarification = 4,
    Deferred = 5
}

public sealed class FamilyUser
{
    private FamilyUser() { }

    public FamilyUser(string email, string displayName, string passwordHash)
    {
        if (string.IsNullOrWhiteSpace(email))
            throw new ArgumentException("Email is required.", nameof(email));
        if (string.IsNullOrWhiteSpace(displayName))
            throw new ArgumentException("Display name is required.", nameof(displayName));
        if (string.IsNullOrWhiteSpace(passwordHash))
            throw new ArgumentException("Password hash is required.", nameof(passwordHash));

        Id = Guid.NewGuid();
        Email = email.Trim();
        NormalizedEmail = Email.ToUpperInvariant();
        DisplayName = displayName.Trim();
        PasswordHash = passwordHash;
        IsActive = true;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public string Email { get; private set; } = string.Empty;
    public string NormalizedEmail { get; private set; } = string.Empty;
    public string DisplayName { get; private set; } = string.Empty;
    public string PasswordHash { get; private set; } = string.Empty;
    public bool IsActive { get; private set; }
    public bool IsLocked { get; private set; }
    public DateTimeOffset? LastLoginUtc { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }

    public void RecordLogin() { LastLoginUtc = DateTimeOffset.UtcNow; ModifiedUtc = LastLoginUtc.Value; }
    public void SetLocked(bool locked) { IsLocked = locked; ModifiedUtc = DateTimeOffset.UtcNow; }
    public void SetActive(bool active) { IsActive = active; ModifiedUtc = DateTimeOffset.UtcNow; }
    public void ChangePasswordHash(string passwordHash) { PasswordHash = passwordHash; ModifiedUtc = DateTimeOffset.UtcNow; }
}

public sealed class UserRoleMembership
{
    private UserRoleMembership() { }
    public UserRoleMembership(Guid familyUserId, FamilyRole role)
    {
        Id = Guid.NewGuid(); FamilyUserId = familyUserId; Role = role; CreatedUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid FamilyUserId { get; private set; }
    public FamilyRole Role { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public FamilyUser FamilyUser { get; private set; } = null!;
}

public sealed class UserInvitation
{
    private UserInvitation() { }
    public UserInvitation(string email, FamilyRole intendedRole, string tokenHash, DateTimeOffset expiresUtc)
    {
        Id = Guid.NewGuid(); Email = email.Trim(); NormalizedEmail = Email.ToUpperInvariant(); IntendedRole = intendedRole;
        TokenHash = tokenHash; ExpiresUtc = expiresUtc; CreatedUtc = DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public string Email { get; private set; } = string.Empty;
    public string NormalizedEmail { get; private set; } = string.Empty;
    public FamilyRole IntendedRole { get; private set; }
    public string TokenHash { get; private set; } = string.Empty;
    public DateTimeOffset ExpiresUtc { get; private set; }
    public DateTimeOffset? AcceptedUtc { get; private set; }
    public DateTimeOffset? RevokedUtc { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public bool IsOpen => !AcceptedUtc.HasValue && !RevokedUtc.HasValue && ExpiresUtc > DateTimeOffset.UtcNow;
    public void MarkAccepted() => AcceptedUtc = DateTimeOffset.UtcNow;
    public void Revoke() => RevokedUtc = DateTimeOffset.UtcNow;
}

public sealed class BranchPermission
{
    private BranchPermission() { }
    public BranchPermission(Guid familyUserId, Guid familyBranchId)
    {
        Id = Guid.NewGuid(); FamilyUserId = familyUserId; FamilyBranchId = familyBranchId; CreatedUtc = DateTimeOffset.UtcNow; ModifiedUtc = CreatedUtc;
    }
    public Guid Id { get; private set; }
    public Guid FamilyUserId { get; private set; }
    public Guid FamilyBranchId { get; private set; }
    public bool CanViewLivingPeople { get; private set; }
    public bool CanEditGenealogy { get; private set; }
    public bool CanViewMedical { get; private set; }
    public bool CanReviewSubmissions { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public FamilyUser FamilyUser { get; private set; } = null!;
    public FamilyBranch FamilyBranch { get; private set; } = null!;
    public void Update(bool canViewLiving, bool canEdit, bool canViewMedical, bool canReview)
    { CanViewLivingPeople=canViewLiving; CanEditGenealogy=canEdit; CanViewMedical=canViewMedical; CanReviewSubmissions=canReview; ModifiedUtc=DateTimeOffset.UtcNow; }
}

public sealed class FamilySubmission
{
    private FamilySubmission() { }
    public FamilySubmission(Guid submittedByUserId, FamilySubmissionType type, string subject, string details)
    {
        if (string.IsNullOrWhiteSpace(subject)) throw new ArgumentException("Submission subject is required.", nameof(subject));
        Id=Guid.NewGuid(); SubmittedByUserId=submittedByUserId; SubmissionType=type; Subject=subject.Trim(); Details=details??string.Empty;
        Status=FamilySubmissionStatus.Pending; SubmittedUtc=DateTimeOffset.UtcNow;
    }
    public Guid Id { get; private set; }
    public Guid SubmittedByUserId { get; private set; }
    public Guid? TargetPersonId { get; private set; }
    public FamilySubmissionType SubmissionType { get; private set; }
    public string Subject { get; private set; } = string.Empty;
    public string Details { get; private set; } = string.Empty;
    public string OriginalFileName { get; private set; } = string.Empty;
    public string StoredRelativePath { get; private set; } = string.Empty;
    public string Sha256 { get; private set; } = string.Empty;
    public long FileSizeBytes { get; private set; }
    public bool RightsAndPrivacyAccepted { get; private set; }
    public FamilySubmissionStatus Status { get; private set; }
    public string ReviewNotes { get; private set; } = string.Empty;
    public Guid? ReviewedByUserId { get; private set; }
    public DateTimeOffset SubmittedUtc { get; private set; }
    public DateTimeOffset? ReviewedUtc { get; private set; }
    public FamilyUser SubmittedByUser { get; private set; } = null!;
    public Person? TargetPerson { get; private set; }

    public void SetTargetPerson(Guid? personId) => TargetPersonId = personId;
    public void SetRightsAccepted(bool accepted) => RightsAndPrivacyAccepted = accepted;
    public void AttachFile(string originalFileName, string relativePath, string sha256, long fileSizeBytes)
    { OriginalFileName=originalFileName??string.Empty; StoredRelativePath=relativePath??string.Empty; Sha256=sha256??string.Empty; FileSizeBytes=fileSizeBytes; }
    public void Review(FamilySubmissionStatus status, Guid reviewerId, string notes)
    { Status=status; ReviewedByUserId=reviewerId; ReviewNotes=notes??string.Empty; ReviewedUtc=DateTimeOffset.UtcNow; }
}
