namespace LoperFamilyTreeBuilder.Core.Entities;

public sealed class SourceRecord
{
    private SourceRecord() { }

    public SourceRecord(string title, SourceClassification classification)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Source title is required.", nameof(title));

        Id = Guid.NewGuid();
        Title = title.Trim();
        Classification = classification;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public string Repository { get; private set; } = string.Empty;
    public string CallNumber { get; private set; } = string.Empty;
    public string Url { get; private set; } = string.Empty;
    public DateOnly? AccessDate { get; private set; }
    public SourceClassification Classification { get; private set; }
    public EvidenceQuality EvidenceQuality { get; private set; }
    public string Confidence { get; private set; } = string.Empty;
    public string Notes { get; private set; } = string.Empty;
    public Guid? OriginalDocumentMediaFileId { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }

    public void SetDetails(
        string repository,
        string callNumber,
        string url,
        DateOnly? accessDate,
        EvidenceQuality evidenceQuality,
        string confidence,
        string notes,
        Guid? originalDocumentMediaFileId)
    {
        Repository = repository ?? string.Empty;
        CallNumber = callNumber ?? string.Empty;
        Url = url ?? string.Empty;
        AccessDate = accessDate;
        EvidenceQuality = evidenceQuality;
        Confidence = confidence ?? string.Empty;
        Notes = notes ?? string.Empty;
        OriginalDocumentMediaFileId = originalDocumentMediaFileId;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}
