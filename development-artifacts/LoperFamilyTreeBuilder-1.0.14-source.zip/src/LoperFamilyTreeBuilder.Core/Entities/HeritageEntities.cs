namespace LoperFamilyTreeBuilder.Core.Entities;

public sealed class CemeteryRecord
{
    private CemeteryRecord() { }

    public CemeteryRecord(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Cemetery name is required.", nameof(name));

        Id = Guid.NewGuid();
        Name = name.Trim();
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public string Address { get; private set; } = string.Empty;
    public string City { get; private set; } = string.Empty;
    public string StateRegion { get; private set; } = string.Empty;
    public string Country { get; private set; } = string.Empty;
    public decimal? Latitude { get; private set; }
    public decimal? Longitude { get; private set; }
    public string BoundaryNotes { get; private set; } = string.Empty;
    public string Notes { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }

    public void Update(string address, string city, string stateRegion, string country,
        decimal? latitude, decimal? longitude, string boundaryNotes, string notes)
    {
        Address = address ?? string.Empty;
        City = city ?? string.Empty;
        StateRegion = stateRegion ?? string.Empty;
        Country = country ?? string.Empty;
        Latitude = latitude;
        Longitude = longitude;
        BoundaryNotes = boundaryNotes ?? string.Empty;
        Notes = notes ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class BurialRecord
{
    private BurialRecord() { }

    public BurialRecord(Guid personId, Guid cemeteryId)
    {
        Id = Guid.NewGuid();
        PersonId = personId;
        CemeteryId = cemeteryId;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public Guid CemeteryId { get; private set; }
    public DateOnly? BurialDate { get; private set; }
    public string Section { get; private set; } = string.Empty;
    public string Plot { get; private set; } = string.Empty;
    public string Row { get; private set; } = string.Empty;
    public string Grave { get; private set; } = string.Empty;
    public string MarkerInscription { get; private set; } = string.Empty;
    public decimal? Latitude { get; private set; }
    public decimal? Longitude { get; private set; }
    public bool NeedsMarkerPhoto { get; private set; }
    public string VisitStatus { get; private set; } = string.Empty;
    public string Notes { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public Person Person { get; private set; } = null!;
    public CemeteryRecord Cemetery { get; private set; } = null!;

    public void Update(DateOnly? burialDate, string section, string plot, string row, string grave,
        string markerInscription, decimal? latitude, decimal? longitude, bool needsMarkerPhoto,
        string visitStatus, string notes)
    {
        BurialDate = burialDate;
        Section = section ?? string.Empty;
        Plot = plot ?? string.Empty;
        Row = row ?? string.Empty;
        Grave = grave ?? string.Empty;
        MarkerInscription = markerInscription ?? string.Empty;
        Latitude = latitude;
        Longitude = longitude;
        NeedsMarkerPhoto = needsMarkerPhoto;
        VisitStatus = visitStatus ?? string.Empty;
        Notes = notes ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class MilitaryServiceRecord
{
    private MilitaryServiceRecord() { }

    public MilitaryServiceRecord(Guid personId, string branch)
    {
        if (string.IsNullOrWhiteSpace(branch))
            throw new ArgumentException("Military branch is required.", nameof(branch));
        Id = Guid.NewGuid();
        PersonId = personId;
        Branch = branch.Trim();
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public string Branch { get; private set; } = string.Empty;
    public string Component { get; private set; } = string.Empty;
    public string RankRating { get; private set; } = string.Empty;
    public string Specialty { get; private set; } = string.Empty;
    public string ServiceNumber { get; private set; } = string.Empty;
    public DateOnly? StartDate { get; private set; }
    public DateOnly? EndDate { get; private set; }
    public string UnitsShipsDutyStations { get; private set; } = string.Empty;
    public string WarsCampaignsDeployments { get; private set; } = string.Empty;
    public string AwardsQualifications { get; private set; } = string.Empty;
    public string Discharge { get; private set; } = string.Empty;
    public string Notes { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public Person Person { get; private set; } = null!;

    public void Update(string component, string rankRating, string specialty, string serviceNumber,
        DateOnly? startDate, DateOnly? endDate, string unitsShipsDutyStations,
        string warsCampaignsDeployments, string awardsQualifications, string discharge, string notes)
    {
        Component = component ?? string.Empty;
        RankRating = rankRating ?? string.Empty;
        Specialty = specialty ?? string.Empty;
        ServiceNumber = serviceNumber ?? string.Empty;
        StartDate = startDate;
        EndDate = endDate;
        UnitsShipsDutyStations = unitsShipsDutyStations ?? string.Empty;
        WarsCampaignsDeployments = warsCampaignsDeployments ?? string.Empty;
        AwardsQualifications = awardsQualifications ?? string.Empty;
        Discharge = discharge ?? string.Empty;
        Notes = notes ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class FamilyStoryRecord
{
    private FamilyStoryRecord() { }

    public FamilyStoryRecord(string title, string originalText)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Story title is required.", nameof(title));
        Id = Guid.NewGuid();
        Title = title.Trim();
        OriginalText = originalText ?? string.Empty;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid? PersonId { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public string OriginalText { get; private set; } = string.Empty;
    public string EditedPublicationText { get; private set; } = string.Empty;
    public string Contributor { get; private set; } = string.Empty;
    public DateOnly? RecordedDate { get; private set; }
    public string Notes { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public Person? Person { get; private set; }

    public void Update(Guid? personId, string editedPublicationText, string contributor,
        DateOnly? recordedDate, string notes)
    {
        PersonId = personId;
        EditedPublicationText = editedPublicationText ?? string.Empty;
        Contributor = contributor ?? string.Empty;
        RecordedDate = recordedDate;
        Notes = notes ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class TimelineEventRecord
{
    private TimelineEventRecord() { }

    public TimelineEventRecord(Guid personId, string eventType, string title)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Timeline title is required.", nameof(title));
        Id = Guid.NewGuid();
        PersonId = personId;
        EventType = string.IsNullOrWhiteSpace(eventType) ? "Life Event" : eventType.Trim();
        Title = title.Trim();
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public string EventType { get; private set; } = string.Empty;
    public string Title { get; private set; } = string.Empty;
    public DateOnly? EventDate { get; private set; }
    public int? ApproximateYear { get; private set; }
    public string PlaceName { get; private set; } = string.Empty;
    public decimal? Latitude { get; private set; }
    public decimal? Longitude { get; private set; }
    public string Description { get; private set; } = string.Empty;
    public string SourceSummary { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public Person Person { get; private set; } = null!;

    public void Update(DateOnly? eventDate, int? approximateYear, string placeName,
        decimal? latitude, decimal? longitude, string description, string sourceSummary)
    {
        EventDate = eventDate;
        ApproximateYear = approximateYear;
        PlaceName = placeName ?? string.Empty;
        Latitude = latitude;
        Longitude = longitude;
        Description = description ?? string.Empty;
        SourceSummary = sourceSummary ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}
