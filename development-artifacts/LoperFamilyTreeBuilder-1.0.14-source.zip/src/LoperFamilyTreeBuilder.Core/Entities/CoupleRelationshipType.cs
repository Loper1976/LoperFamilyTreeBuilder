namespace LoperFamilyTreeBuilder.Core.Entities;

public enum CoupleRelationshipType
{
    Spouse = 1,
    Partner = 2,
    FormerSpouse = 3,
    FormerPartner = 4,
    Engaged = 5,
    Other = 99
}
