namespace LoperFamilyTreeBuilder.Core.Entities;

public enum ArchiveMediaType
{
    Photo = 1,
    Document = 2,
    Audio = 3,
    Video = 4,
    Other = 99
}
