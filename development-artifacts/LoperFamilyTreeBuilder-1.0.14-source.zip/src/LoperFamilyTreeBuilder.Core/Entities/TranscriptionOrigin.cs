namespace LoperFamilyTreeBuilder.Core.Entities;

public enum TranscriptionOrigin
{
    Human = 1,
    OCR = 2,
    AI = 3
}
