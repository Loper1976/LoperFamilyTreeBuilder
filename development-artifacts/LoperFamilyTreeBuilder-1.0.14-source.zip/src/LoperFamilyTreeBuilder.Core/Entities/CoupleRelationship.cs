namespace LoperFamilyTreeBuilder.Core.Entities;

public sealed class CoupleRelationship
{
    private CoupleRelationship()
    {
    }

    public CoupleRelationship(
        Guid firstPersonId,
        Guid secondPersonId,
        CoupleRelationshipType relationshipType)
    {
        if (firstPersonId == secondPersonId)
        {
            throw new InvalidOperationException(
                "A person cannot be connected to themselves as a spouse or partner.");
        }

        Id = Guid.NewGuid();

        if (firstPersonId.CompareTo(secondPersonId) < 0)
        {
            PersonAId = firstPersonId;
            PersonBId = secondPersonId;
        }
        else
        {
            PersonAId = secondPersonId;
            PersonBId = firstPersonId;
        }

        RelationshipType = relationshipType;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }

    public Guid PersonAId { get; private set; }

    public Guid PersonBId { get; private set; }

    public CoupleRelationshipType RelationshipType { get; private set; }

    public DateOnly? StartDate { get; private set; }

    public DateOnly? EndDate { get; private set; }

    public string Notes { get; private set; } = string.Empty;

    public DateTimeOffset CreatedUtc { get; private set; }

    public DateTimeOffset ModifiedUtc { get; private set; }

    public Person PersonA { get; private set; } = null!;

    public Person PersonB { get; private set; } = null!;

    public void Update(
        CoupleRelationshipType relationshipType,
        DateOnly? startDate,
        DateOnly? endDate,
        string notes)
    {
        RelationshipType = relationshipType;
        StartDate = startDate;
        EndDate = endDate;
        Notes = notes ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}
