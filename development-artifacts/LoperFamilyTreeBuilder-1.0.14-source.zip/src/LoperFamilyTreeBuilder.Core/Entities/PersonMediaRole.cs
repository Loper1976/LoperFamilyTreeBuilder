namespace LoperFamilyTreeBuilder.Core.Entities;

public enum PersonMediaRole
{
    Photo = 1,
    PrimaryPhoto = 2,
    Document = 3,
    Headstone = 4,
    Evidence = 5,
    Other = 99
}
