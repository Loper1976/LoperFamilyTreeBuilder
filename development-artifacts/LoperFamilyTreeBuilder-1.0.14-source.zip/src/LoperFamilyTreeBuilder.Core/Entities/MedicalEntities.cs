namespace LoperFamilyTreeBuilder.Core.Entities;

public enum MedicalConditionStatus
{
    Active = 1,
    Resolved = 2,
    Historical = 3,
    Unknown = 4
}

public enum MedicalEvidenceStatus
{
    Confirmed = 1,
    Probable = 2,
    Suspected = 3,
    FamilyReported = 4,
    Unknown = 5
}

public enum MedicalPrivacyLevel
{
    Private = 1,
    Restricted = 2,
    AuthorizedFamily = 3
}

public enum MedicalEventType
{
    Hospitalization = 1,
    Surgery = 2,
    Injury = 3,
    HeartAttack = 4,
    Stroke = 5,
    CancerDiagnosis = 6,
    Hospice = 7,
    LongTermCare = 8,
    Recovery = 9,
    Custom = 99
}

public enum MedicalRecordType
{
    Condition = 1,
    Event = 2,
    CauseOfDeath = 3
}

public sealed class MedicalConditionRecord
{
    private MedicalConditionRecord() { }

    public MedicalConditionRecord(Guid personId, string conditionName)
    {
        if (string.IsNullOrWhiteSpace(conditionName))
            throw new ArgumentException("Condition name is required.", nameof(conditionName));
        Id = Guid.NewGuid();
        PersonId = personId;
        ConditionName = conditionName.Trim();
        Status = MedicalConditionStatus.Unknown;
        EvidenceStatus = MedicalEvidenceStatus.Unknown;
        PrivacyLevel = MedicalPrivacyLevel.Private;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public string ConditionName { get; private set; } = string.Empty;
    public DateOnly? DiagnosisDate { get; private set; }
    public int? ApproximateDiagnosisYear { get; private set; }
    public int? AgeAtOnset { get; private set; }
    public MedicalConditionStatus Status { get; private set; }
    public MedicalEvidenceStatus EvidenceStatus { get; private set; }
    public string Severity { get; private set; } = string.Empty;
    public bool PotentialHereditaryRelevance { get; private set; }
    public string TreatingProvider { get; private set; } = string.Empty;
    public string TreatingFacility { get; private set; } = string.Empty;
    public string PrivateNotes { get; private set; } = string.Empty;
    public MedicalPrivacyLevel PrivacyLevel { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public Person Person { get; private set; } = null!;

    public void Update(
        DateOnly? diagnosisDate,
        int? approximateDiagnosisYear,
        int? ageAtOnset,
        MedicalConditionStatus status,
        MedicalEvidenceStatus evidenceStatus,
        string severity,
        bool potentialHereditaryRelevance,
        string treatingProvider,
        string treatingFacility,
        string privateNotes,
        MedicalPrivacyLevel privacyLevel)
    {
        DiagnosisDate = diagnosisDate;
        ApproximateDiagnosisYear = approximateDiagnosisYear;
        AgeAtOnset = ageAtOnset;
        Status = status;
        EvidenceStatus = evidenceStatus;
        Severity = severity ?? string.Empty;
        PotentialHereditaryRelevance = potentialHereditaryRelevance;
        TreatingProvider = treatingProvider ?? string.Empty;
        TreatingFacility = treatingFacility ?? string.Empty;
        PrivateNotes = privateNotes ?? string.Empty;
        PrivacyLevel = privacyLevel;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class MedicalEventRecord
{
    private MedicalEventRecord() { }

    public MedicalEventRecord(Guid personId, MedicalEventType eventType, string title)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new ArgumentException("Medical event title is required.", nameof(title));
        Id = Guid.NewGuid();
        PersonId = personId;
        EventType = eventType;
        Title = title.Trim();
        PrivacyLevel = MedicalPrivacyLevel.Private;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public MedicalEventType EventType { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public DateOnly? EventDate { get; private set; }
    public int? ApproximateYear { get; private set; }
    public string Description { get; private set; } = string.Empty;
    public string TreatingProvider { get; private set; } = string.Empty;
    public string TreatingFacility { get; private set; } = string.Empty;
    public MedicalEvidenceStatus EvidenceStatus { get; private set; } = MedicalEvidenceStatus.Unknown;
    public string PrivateNotes { get; private set; } = string.Empty;
    public MedicalPrivacyLevel PrivacyLevel { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public Person Person { get; private set; } = null!;

    public void Update(DateOnly? eventDate, int? approximateYear, string description,
        string provider, string facility, MedicalEvidenceStatus evidenceStatus,
        string privateNotes, MedicalPrivacyLevel privacyLevel)
    {
        EventDate = eventDate;
        ApproximateYear = approximateYear;
        Description = description ?? string.Empty;
        TreatingProvider = provider ?? string.Empty;
        TreatingFacility = facility ?? string.Empty;
        EvidenceStatus = evidenceStatus;
        PrivateNotes = privateNotes ?? string.Empty;
        PrivacyLevel = privacyLevel;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class CauseOfDeathRecord
{
    private CauseOfDeathRecord() { }

    public CauseOfDeathRecord(Guid personId, string primaryCause)
    {
        Id = Guid.NewGuid();
        PersonId = personId;
        PrimaryCause = primaryCause?.Trim() ?? string.Empty;
        PrivacyLevel = MedicalPrivacyLevel.Private;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public string PrimaryCause { get; private set; } = string.Empty;
    public string SecondaryCauses { get; private set; } = string.Empty;
    public string ContributingConditions { get; private set; } = string.Empty;
    public MedicalEvidenceStatus EvidenceStatus { get; private set; } = MedicalEvidenceStatus.Unknown;
    public string PrivateNotes { get; private set; } = string.Empty;
    public MedicalPrivacyLevel PrivacyLevel { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }
    public Person Person { get; private set; } = null!;

    public void Update(string primaryCause, string secondaryCauses, string contributingConditions,
        MedicalEvidenceStatus evidenceStatus, string privateNotes, MedicalPrivacyLevel privacyLevel)
    {
        PrimaryCause = primaryCause?.Trim() ?? string.Empty;
        SecondaryCauses = secondaryCauses ?? string.Empty;
        ContributingConditions = contributingConditions ?? string.Empty;
        EvidenceStatus = evidenceStatus;
        PrivateNotes = privateNotes ?? string.Empty;
        PrivacyLevel = privacyLevel;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class MedicalEvidenceLink
{
    private MedicalEvidenceLink() { }

    public MedicalEvidenceLink(Guid personId, MedicalRecordType recordType, Guid recordId, Guid? citationRecordId, Guid? mediaFileId)
    {
        if (!citationRecordId.HasValue && !mediaFileId.HasValue)
            throw new InvalidOperationException("A medical evidence link requires a citation or archived document.");
        Id = Guid.NewGuid();
        PersonId = personId;
        RecordType = recordType;
        RecordId = recordId;
        CitationRecordId = citationRecordId;
        MediaFileId = mediaFileId;
        CreatedUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public MedicalRecordType RecordType { get; private set; }
    public Guid RecordId { get; private set; }
    public Guid? CitationRecordId { get; private set; }
    public Guid? MediaFileId { get; private set; }
    public DateTimeOffset CreatedUtc { get; private set; }
}
