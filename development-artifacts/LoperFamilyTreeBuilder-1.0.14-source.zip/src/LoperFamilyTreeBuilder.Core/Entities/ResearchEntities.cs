namespace LoperFamilyTreeBuilder.Core.Entities;

public enum ResearchStatus
{
    Verified = 1,
    Probable = 2,
    Draft = 3,
    UnderReview = 4,
    NeedsResearch = 5,
    Disputed = 6,
    ConflictingEvidence = 7,
    FamilyTradition = 8,
    Unverified = 9,
    AiResearchLead = 10,
    Archived = 11
}

public enum AiSuggestionType
{
    MissingInformation = 1,
    SourceSummary = 2,
    ResearchTarget = 3,
    Contradiction = 4,
    DuplicateCandidate = 5,
    RelationshipExplanation = 6,
    TimelineDraft = 7,
    BiographyDraft = 8,
    DocumentTranscription = 9,
    CemeteryResearch = 10,
    SourceGap = 11,
    FamilyHealthPattern = 12
}

public enum AiSuggestionStatus
{
    PendingReview = 1,
    Approved = 2,
    Rejected = 3,
    Edited = 4,
    SavedAsResearchLead = 5
}

public sealed class ResearchTaskRecord
{
    private ResearchTaskRecord() { }

    public ResearchTaskRecord(string researchQuestion)
    {
        if (string.IsNullOrWhiteSpace(researchQuestion))
            throw new ArgumentException("Research question is required.", nameof(researchQuestion));

        Id = Guid.NewGuid();
        ResearchQuestion = researchQuestion.Trim();
        Status = ResearchStatus.NeedsResearch;
        CreatedUtc = DateTimeOffset.UtcNow;
        ModifiedUtc = CreatedUtc;
    }

    public Guid Id { get; private set; }
    public Guid? PersonId { get; private set; }
    public Guid? FamilyBranchId { get; private set; }
    public string ResearchQuestion { get; private set; } = string.Empty;
    public string AssignedResearcher { get; private set; } = string.Empty;
    public ResearchStatus Status { get; private set; }
    public string RepositorySearched { get; private set; } = string.Empty;
    public DateOnly? SearchDate { get; private set; }
    public string SearchResults { get; private set; } = string.Empty;
    public string NegativeSearches { get; private set; } = string.Empty;
    public string Notes { get; private set; } = string.Empty;
    public string Sources { get; private set; } = string.Empty;
    public string FollowUpAction { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset ModifiedUtc { get; private set; }

    public Person? Person { get; private set; }
    public FamilyBranch? FamilyBranch { get; private set; }

    public void Update(
        Guid? personId,
        Guid? familyBranchId,
        string assignedResearcher,
        ResearchStatus status,
        string repositorySearched,
        DateOnly? searchDate,
        string searchResults,
        string negativeSearches,
        string notes,
        string sources,
        string followUpAction)
    {
        PersonId = personId;
        FamilyBranchId = familyBranchId;
        AssignedResearcher = assignedResearcher ?? string.Empty;
        Status = status;
        RepositorySearched = repositorySearched ?? string.Empty;
        SearchDate = searchDate;
        SearchResults = searchResults ?? string.Empty;
        NegativeSearches = negativeSearches ?? string.Empty;
        Notes = notes ?? string.Empty;
        Sources = sources ?? string.Empty;
        FollowUpAction = followUpAction ?? string.Empty;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }

    public void SetStatus(ResearchStatus status)
    {
        Status = status;
        ModifiedUtc = DateTimeOffset.UtcNow;
    }
}

public sealed class AiResearchSuggestion
{
    private AiResearchSuggestion() { }

    public AiResearchSuggestion(
        AiSuggestionType suggestionType,
        string prompt,
        string result,
        string sourceLabel)
    {
        if (string.IsNullOrWhiteSpace(prompt))
            throw new ArgumentException("AI/research prompt is required.", nameof(prompt));

        Id = Guid.NewGuid();
        SuggestionType = suggestionType;
        Prompt = prompt.Trim();
        Result = result?.Trim() ?? string.Empty;
        SourcesUsed = sourceLabel?.Trim() ?? string.Empty;
        Status = AiSuggestionStatus.PendingReview;
        CreatedUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid? PersonId { get; private set; }
    public Guid? FamilyBranchId { get; private set; }
    public AiSuggestionType SuggestionType { get; private set; }
    public string Prompt { get; private set; } = string.Empty;
    public string Result { get; private set; } = string.Empty;
    public string SourcesUsed { get; private set; } = string.Empty;
    public string Confidence { get; private set; } = string.Empty;
    public string ProposedChange { get; private set; } = string.Empty;
    public AiSuggestionStatus Status { get; private set; }
    public Guid? ReviewedByUserId { get; private set; }
    public string ReviewNotes { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public DateTimeOffset? ReviewedUtc { get; private set; }

    public Person? Person { get; private set; }
    public FamilyBranch? FamilyBranch { get; private set; }

    public void SetContext(Guid? personId, Guid? familyBranchId)
    {
        PersonId = personId;
        FamilyBranchId = familyBranchId;
    }

    public void SetProposal(string result, string sourcesUsed, string confidence, string proposedChange)
    {
        Result = result?.Trim() ?? string.Empty;
        SourcesUsed = sourcesUsed?.Trim() ?? string.Empty;
        Confidence = confidence?.Trim() ?? string.Empty;
        ProposedChange = proposedChange?.Trim() ?? string.Empty;
    }

    public void Review(AiSuggestionStatus status, Guid? reviewerUserId, string reviewNotes)
    {
        Status = status;
        ReviewedByUserId = reviewerUserId;
        ReviewNotes = reviewNotes?.Trim() ?? string.Empty;
        ReviewedUtc = DateTimeOffset.UtcNow;
    }
}
