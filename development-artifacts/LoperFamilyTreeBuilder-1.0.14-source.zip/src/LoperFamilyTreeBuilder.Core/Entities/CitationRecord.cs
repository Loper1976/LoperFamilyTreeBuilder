namespace LoperFamilyTreeBuilder.Core.Entities;

public sealed class CitationRecord
{
    private CitationRecord() { }

    public CitationRecord(
        Guid personId,
        Guid sourceRecordId,
        string factOrSubject,
        CitationPosition position)
    {
        Id = Guid.NewGuid();
        PersonId = personId;
        SourceRecordId = sourceRecordId;
        FactOrSubject = string.IsNullOrWhiteSpace(factOrSubject)
            ? "General person evidence"
            : factOrSubject.Trim();
        Position = position;
        CreatedUtc = DateTimeOffset.UtcNow;
    }

    public Guid Id { get; private set; }
    public Guid PersonId { get; private set; }
    public Guid SourceRecordId { get; private set; }
    public Guid? MediaFileId { get; private set; }
    public string FactOrSubject { get; private set; } = string.Empty;
    public CitationPosition Position { get; private set; }
    public string PageOrCallNumber { get; private set; } = string.Empty;
    public string CitationText { get; private set; } = string.Empty;
    public string Notes { get; private set; } = string.Empty;
    public DateTimeOffset CreatedUtc { get; private set; }
    public Person Person { get; private set; } = null!;
    public SourceRecord SourceRecord { get; private set; } = null!;

    public void SetDetails(Guid? mediaFileId, string pageOrCallNumber, string citationText, string notes)
    {
        MediaFileId = mediaFileId;
        PageOrCallNumber = pageOrCallNumber ?? string.Empty;
        CitationText = citationText ?? string.Empty;
        Notes = notes ?? string.Empty;
    }
}
